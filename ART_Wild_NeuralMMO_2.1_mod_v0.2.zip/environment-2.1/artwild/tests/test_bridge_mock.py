"""Dependency-free bridge contract checks; NOT a real NMMO integration test."""
import importlib.util
import sys
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))


class FakeObs:
    def reset(self, *args):
        self.reset_called = True

    def to_gym(self):
        return {'ok': True}


class FakeTile:
    habitable = True
    occupied = False


class FakeMap:
    habitable_tiles = None
    def __init__(self):
        self.tiles = {(r, c): FakeTile() for r in range(20) for c in range(20)}


class FakePlayer:
    def __init__(self, pos):
        self.pos = pos


class FakePlayers:
    def __init__(self):
        self.entities = {1: FakePlayer((10, 10)), 2: FakePlayer((10, 12))}

    def __iter__(self):
        return iter(self.entities)

    def __getitem__(self, key):
        return self.entities[key]

    def spawn_artwild(self, slot, pos):
        obj = FakePlayer(pos)
        self.entities[slot] = obj
        return obj


class FakeEnv:
    def __init__(self, config, seed):
        self.config = config
        self.realm = types.SimpleNamespace(players=FakePlayers(), tick=0, map=FakeMap())
        self.possible_agents = [1, 2, 3]
        self._dummy_task_embedding = None
        self.obs = {x: FakeObs() for x in self.possible_agents}
        self._alive_agents = [1, 2]
        self._current_agents = [1, 2]
        self._dead_this_tick = {}
        self._np_random = types.SimpleNamespace(integers=lambda n: 0)

    def reset(self, *args, **kwargs):
        self.realm.players = FakePlayers()
        self.realm.tick = 0
        self._alive_agents = [1, 2]
        self._current_agents = [1, 2]
        return {1: {}, 2: {}}, {1: {}, 2: {}}

    def _compute_observations(self):
        pass

    def step(self, actions):
        self.realm.tick += 1
        dead = actions.get('kill_slot')
        self._dead_this_tick = {dead: object()} if dead else {}
        if dead:
            self.realm.players.entities.pop(dead)
        self._alive_agents = list(self.realm.players)
        self._current_agents = sorted(set(self._alive_agents) | set(self._dead_this_tick))
        return ({x: {} for x in self._current_agents}, {},
                {x: x == dead for x in self._current_agents},
                {x: False for x in self._current_agents},
                {x: {} for x in self._current_agents})


# Load the actual bridge while substituting only the upstream interface.
original_nmmo = sys.modules.get('nmmo')
sys.modules['nmmo'] = types.SimpleNamespace(Env=FakeEnv, config=types.SimpleNamespace(Default=object))
try:
    spec = importlib.util.spec_from_file_location('artwild_test_bridge', ROOT / 'artwild' / 'nmmo_env.py')
    bridge = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bridge)
finally:
    if original_nmmo is None:
        del sys.modules['nmmo']
    else:
        sys.modules['nmmo'] = original_nmmo


class TestBridge(unittest.TestCase):
    def make_env(self):
        config = types.SimpleNamespace(MAP_SIZE=20, HORIZON=30)
        env = bridge.ArtWildEnv(config=config, artwild_seed=8)
        env.reset()
        return env

    def test_founders_have_permanent_ids(self):
        env = self.make_env()
        self.assertEqual(len(env.population.living()), 2)
        self.assertEqual(env.slot_to_bio_id, {1: 1, 2: 2})

    def test_death_then_newborn_reuses_slot_but_not_identity(self):
        env = self.make_env()
        env.request_birth(1, 2)
        env.step({'kill_slot': 2})
        # The queued reproduction is cancelled if a parent dies before birth.
        self.assertEqual(len(env.population.living()), 1)
        self.assertEqual(env._pending_births, [])
        env = self.make_env()
        # First kill an unrelated agent and then reproduce with the two parents.
        env.realm.players.entities[3] = FakePlayer((11, 11))
        individual = env.population.founder(0, 0)
        env._register(3, individual.id)
        env.step({'kill_slot': 3})
        env.request_birth(1, 2)
        ob, rewards, dones, trunc, info = env.step({})
        self.assertIn(3, ob)
        self.assertEqual(info[3]['artwild_bio_id'], 4)
        self.assertEqual(env.population.agents[4].parent_ids, (1, 2))
        self.assertTrue(env.population.agents[4].alive)
        self.assertIsNone(env.population.agents[4].memory)
        self.assertTrue(dones.get(3) is False)

    def test_no_birth_after_horizon(self):
        env = self.make_env()
        env.config.HORIZON = 1
        env.request_birth(1, 2)
        env.step({})
        self.assertEqual(len(env.population.living()), 2)
        self.assertEqual(len(env._pending_births), 1)


if __name__ == '__main__':
    unittest.main()
