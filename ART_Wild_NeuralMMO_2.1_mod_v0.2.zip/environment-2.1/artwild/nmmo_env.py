"""Opt-in Neural MMO 2.1 bridge; baseline nmmo.Env stays unchanged.

IMPORTANT: This is a *manual-birth foundation*, not autonomously learned
reproduction. Preallocated PLAYER_N is still a hard concurrency ceiling.
The default NMMO horizon and episode reset still apply.
"""
from __future__ import annotations

import nmmo
from artwild.core import Population


class ArtWildEnv(nmmo.Env):
    """PettingZoo wrapper with permanent biological IDs and dynamic slot reuse.

    Usage:
      env = ArtWildEnv(config, artwild_seed=10)
      observations, info = env.reset(seed=10)
      # after a player dies, request_birth(parent_slot_a, parent_slot_b)
      # then the next env.step(...) will create a newborn in the vacant slot.

    A slot may be reused after death: RNN trainers MUST treat a new permanent
    biological ID as a new episode and reset its individual hidden state.
    """

    def __init__(self, config=None, seed=None, artwild_seed=0,
                 ticks_per_year=100, genetic_mutation_rate=0.0001):
        if config is None:
            config = nmmo.config.Default()
        super().__init__(config=config, seed=seed)
        self._aw_seed = artwild_seed
        self._aw_tpy = ticks_per_year
        self._aw_mutation = genetic_mutation_rate
        self.population = None
        self.slot_to_bio_id = {}
        self.bio_id_to_slot = {}
        self._pending_births = []
        self._aw_cycle = 0

    def reset(self, *args, **kwargs):
        observations, infos = super().reset(*args, **kwargs)
        self._aw_cycle += 1
        self.population = Population(seed=self._aw_seed + self._aw_cycle - 1,
                                    ticks_per_year=self._aw_tpy,
                                    mutation_rate=self._aw_mutation)
        self.slot_to_bio_id.clear()
        self.bio_id_to_slot.clear()
        self._pending_births.clear()
        self.population.add_lineage(0)
        for slot in self.realm.players:
            individual = self.population.founder(self.realm.tick, 0)
            self._register(slot, individual.id)
            infos.setdefault(slot, {})['artwild_bio_id'] = individual.id
            infos[slot]['artwild_lineage_id'] = individual.lineage_id
        return observations, infos

    def _register(self, slot, biological_id):
        self.slot_to_bio_id[slot] = biological_id
        self.bio_id_to_slot[biological_id] = slot

    def request_birth(self, parent_slot_a: int, parent_slot_b: int):
        """Queue a reproductive event for the NEXT step (external API only).

        The actual reproduction action, maturity, pregnancy, and partner
        agreement are not implemented here. Parentage is evaluated at birth.
        """
        if parent_slot_a == parent_slot_b:
            raise ValueError('Parents must be different individuals')
        for slot in (parent_slot_a, parent_slot_b):
            if slot not in self.realm.players or slot not in self.slot_to_bio_id:
                raise ValueError('Parent is not a living registered player')
        # Store permanent IDs, not reusable slot IDs, to prevent identity mixups.
        self._pending_births.append((self.slot_to_bio_id[parent_slot_a],
                                     self.slot_to_bio_id[parent_slot_b]))

    def _find_spawn_pos(self, parent_pos):
        r, c = parent_pos
        # Look nearby, but not on top of either parent or another entity.
        for radius in range(1, 6):
            options = []
            for dr in range(-radius, radius + 1):
                for dc in range(-radius, radius + 1):
                    if max(abs(dr), abs(dc)) != radius:
                        continue
                    pos = (r + dr, c + dc)
                    if not (0 <= pos[0] < self.config.MAP_SIZE and
                            0 <= pos[1] < self.config.MAP_SIZE):
                        continue
                    tile = self.realm.map.tiles[pos]
                    if tile.habitable and not tile.occupied:
                        options.append(pos)
            if options:
                return options[int(self._np_random.integers(len(options)))]
        return None

    def _produce_newborn(self, parent_a_id, parent_b_id):
        a = self.population.agents[parent_a_id]
        b = self.population.agents[parent_b_id]
        if not a.alive or not b.alive:
            return None
        if parent_a_id not in self.bio_id_to_slot or parent_b_id not in self.bio_id_to_slot:
            return None
        vacant = sorted(set(self.possible_agents) - set(self.realm.players.entities))
        if not vacant:
            return None  # queued for future steps, not silently dropped
        parent = self.realm.players[self.bio_id_to_slot[parent_a_id]]
        pos = self._find_spawn_pos(parent.pos)
        if pos is None:
            return None
        slot = vacant[0]
        # Physical spawn first: avoid creating a phantom biological birth if it fails.
        player = self.realm.players.spawn_artwild(slot, pos)
        newborn = self.population.birth(parent_a_id, parent_b_id, self.realm.tick)
        player.artwild_bio_id = newborn.id
        self._register(slot, newborn.id)
        self.obs[slot].reset(self.realm.map.habitable_tiles,
                             self._dummy_task_embedding)
        return slot, newborn

    def step(self, actions):
        # Underlying Neural MMO handles damage, death, and original game mechanics.
        observations, rewards, terminated, truncated, infos = super().step(actions)
        for slot in self._dead_this_tick:
            biological_id = self.slot_to_bio_id.pop(slot, None)
            if biological_id is not None:
                self.bio_id_to_slot.pop(biological_id, None)
                self.population.death(biological_id, self.realm.tick,
                                      reason='nmmo_death')
                infos.setdefault(slot, {})['artwild_bio_id'] = biological_id
        # Do not create newborns if NMMO has reached its episode horizon.
        if self.realm.tick >= self.config.HORIZON:
            return observations, rewards, terminated, truncated, infos
        remain = []
        births = []
        for parent_a_id, parent_b_id in self._pending_births:
            if not (self.population.agents[parent_a_id].alive and
                    self.population.agents[parent_b_id].alive):
                continue
            born = self._produce_newborn(parent_a_id, parent_b_id)
            if born is None:
                remain.append((parent_a_id, parent_b_id))
            else:
                births.append(born)
        self._pending_births = remain
        if births:
            # The original Env caches observations and tracks active slots.
            # Refresh both so newborns appear in the returned PettingZoo step.
            newborn_slots = {slot for slot, _ in births}
            self._alive_agents = sorted(set(self._alive_agents) | newborn_slots)
            self._current_agents = sorted(set(self._current_agents) | newborn_slots)
            self._compute_observations()
            for slot, newborn in births:
                observations[slot] = self.obs[slot].to_gym()
                rewards[slot] = 0
                terminated[slot] = False
                truncated[slot] = False
                infos[slot] = {'artwild_bio_id': newborn.id,
                               'artwild_lineage_id': newborn.lineage_id,
                               'artwild_newborn': True,
                               'task': {}}
        # Expose permanent identity to the policy driver on every observation.
        for slot in self._alive_agents:
            if slot in self.slot_to_bio_id:
                infos.setdefault(slot, {})['artwild_bio_id'] = self.slot_to_bio_id[slot]
                infos[slot]['artwild_lineage_id'] = self.population.agents[
                    self.slot_to_bio_id[slot]].lineage_id
        return observations, rewards, terminated, truncated, infos
