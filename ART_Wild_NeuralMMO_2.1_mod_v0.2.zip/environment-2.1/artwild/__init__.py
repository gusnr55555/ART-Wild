"""ART-Wild extension for Neural MMO 2.1.

Use `from artwild.nmmo_env import ArtWildEnv` for the opt-in wrapper.
The genome and population models are independent of Neural MMO.
"""
from artwild.core import Genome, Population, AgentRecord, PolicyLineage
__all__ = ['Genome', 'Population', 'AgentRecord', 'PolicyLineage']
