# ART-Wild × Neural MMO 2.1 (experimental v0.2)

This ZIP includes the **original Neural MMO 2.1 source tree**, with one
`PlayerManager.spawn_artwild()` extension and a new `artwild/` Python package.
The default `nmmo.Env` behavior remains unchanged.

## Usage (on a compatible machine)

The upstream project specifies Python >=3.7,<3.11 and pins older NumPy / Gym
versions. Use a Python 3.10 virtual environment and install dependencies as
specified by `setup.py` (they are NOT included in this archive).

```python
import nmmo
from artwild.nmmo_env import ArtWildEnv

config = nmmo.config.Default()
env = ArtWildEnv(config, seed=13)
obs, info = env.reset(seed=13)
print('founders', env.slot_to_bio_id)
# After one or more player slots are vacated by death:
env.request_birth(1, 2)  # external research/test hook; NOT an RL action
obs, rewards, terminated, truncated, info = env.step({})
print('current population', len(env.population.living()))
```

## What is truly implemented

- Stable biological IDs in a sidecar `Population` (distinct from reused NMMO slots).
- Founder records at reset, genome and recessive trait model, parent genealogy.
- Record deaths, discard biological memory, reuse vacant NMMO player slots.
- Explicit `request_birth` API, baby placed near a living parent where passable.
- Reinitialize the observation cache and expose new agent ID after birth.
- Genome/lineage details are **not added to agent observations** automatically.
- Birth is queued while no slot is free (hard PLAYER_N cap).

## Not implemented / known constraints

- **No learned mating action**, pregnancy, maturity validation, parental care,
  physical expression of disease penalties, or policy weights / PPO integration.
- Base NMMO `HORIZON` still terminates episodes; the world is NOT endless.
- `PLAYER_N` is a fixed *simultaneous* player capacity. This is NOT an
  unlimited population implementation.
- Reusing a slot means trainers must use `artwild_bio_id` to reset GRU
  state and segregate experiences; standard PettingZoo helpers may assume
  that a dead agent ID never reappears during the same episode. The current
  prototype breaks that assumption and therefore is **not general PettingZoo
  compliant for standard training pipelines** yet. This is a research bridge.
- Original NMMO default per-slot tasks are not automatically re-assigned to
  newborns; a custom task/reward system will be needed.
- `nmmo.Env` retains original game winners/task/horizon logic.
- Code has been syntax-checked and headless core tests run. **Full NMMO
  environment integration test cannot run in this environment** because
  upstream pinned dependencies and Cython extension are unavailable.

## Recommended follow-up

1. Validate `ArtWildEnv` against Python 3.10 + NMMO installed.
2. Replace NMMO episode identity semantics with a stable lifetime-safe
   observer/runner API so policy trainers can handle player replacement.
3. Implement physical stat expression and a reproductive interaction.
4. Build fixed-length AI rollouts that preserve world state across updates.
