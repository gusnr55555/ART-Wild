# ART-Wild v0.6: dual cycle architecture

This retains upstream Neural MMO 2.1 plus the experimental v0.5 modifications.

## Key distinction

**Inner loop:** one persistent *finite-run* world, simultaneous actions, birth/death,
non-reusable lifetime IDs, individual memory, event logging, transitions.

**Outer loop:** analyze adult offspring and lineage frequencies and issue a **plan**
for the next simulation cycle. A planner is not a gradient trainer or distiller.

## Added files
- `artwild/cycle.py`: modular cycle contract and orchestration
- `artwild/toy_world.py`: deterministic headless contract-test environment
- `artwild/tests/test_cycle.py`: no-Neural-MMO-dependency tests

## Run headless smoke test

```bash
python -m unittest discover -s artwild/tests -p 'test_cycle.py' -v
python -m artwild.demo_cycle
```

## Boundaries and limitations

- **Neural MMO is NOT yet wired to this cycle engine**. The `ArtWildEnv` bridge
  still has its original finite horizon. The toy world demonstrates the intended
  control flow using the v0.5 genome and population logic.
- `SilenceAndForage` is hand-scripted for tests, NOT a learned policy.
- `CountingLearner` counts transitions, DOES NOT run PPO/GRU.
- `CyclePlanner` creates a next-cycle selection/distillation/mutation REQUEST,
  DOES NOT modify weight tensors. Scientific training remains future work.
- ToyWorld has no full ecology, feeding needs, carrying capacity, pregnancy,
  realistic death model, or learned social behavior. Offspring may be born
  instantly after reciprocal proposals for integration testing.
- Real-world save/load, incremental world streaming, and full NMMO integration
  remain unimplemented.

## ART layer (v0.7-art)

See `ARTWILD_ART_SPEC.md` for the new `artwild/art/` package (ART 1, Fuzzy ART,
Fuzzy ARTMAP, lifetime-isolated store). It is not yet connected to this cycle engine.
