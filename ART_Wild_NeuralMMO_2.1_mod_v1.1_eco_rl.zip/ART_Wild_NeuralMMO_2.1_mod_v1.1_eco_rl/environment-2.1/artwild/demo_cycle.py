"""Demonstrate finite-run ART-Wild cycle accounting (not PPO training)."""
from artwild.cycle import CycleEngine,CycleConfig,CyclePlanner
from artwild.toy_world import ToyWorld,SilenceAndForage

if __name__=='__main__':
    run=CycleEngine(ToyWorld(founders=12),SilenceAndForage()).run(
        cycle_id=1,seed=42,lineages=(0,1,2,3),config=CycleConfig(max_ticks=80,training=False))
    plan=CyclePlanner().plan(run,use_distillation=True,request_mutations=True)
    print('cycle',run.cycle_id,'ticks',run.ticks,'end',run.end_reason,
          'founders',run.founder_count,'births',run.births,'deaths',run.deaths,
          'alive',run.alive)
    print('next cycle (proposal only)',plan)
