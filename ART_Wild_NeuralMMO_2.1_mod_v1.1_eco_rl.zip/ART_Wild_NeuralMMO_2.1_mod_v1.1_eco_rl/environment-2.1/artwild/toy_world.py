"""Deterministic, headless smoke-test world for the ART-Wild cycle contract.

NOT Neural MMO, NOT ecological realism, and NOT an RL baseline. Uses the actual
ART-Wild Population genome, inherited lineage, and reproduction bookkeeping.
"""
from __future__ import annotations
from random import Random
from artwild.core import Population, Genome
from artwild.cycle import WorldStep

class ToyWorld:
    def __init__(self, *, founders: int = 8, ticks_per_year: int = 4,
                 founder_age: int = 20, max_age: int = 30, food: float = 2000.,
                 seed_variation: bool = True):
        if founders < 2 or ticks_per_year < 1 or max_age <= founder_age:
            raise ValueError('invalid toy world parameters')
        self.founders, self.tpy, self.founder_age, self.max_age = founders, ticks_per_year, founder_age, max_age
        self.initial_food, self.seed_variation = food, seed_variation

    def reset(self, seed: int, lineage_ids: tuple[int, ...]):
        self.population = Population(seed=seed, ticks_per_year=self.tpy)
        self.rng = Random(seed)
        self.tick = 0
        self.food = self.initial_food
        self.locations = {}
        for lineage in lineage_ids:
            self.population.add_lineage(lineage)
        for i in range(self.founders):
            # Alternate genders to make reciprocal reproduction testable.
            genome = Genome.random(self.rng)
            genome = Genome(genome.homolog_a,genome.homolog_b,'XX' if i%2==0 else 'XY')
            a = self.population.founder(0,lineage_ids[i%len(lineage_ids)],genome, self.founder_age)
            self.locations[str(a.id)] = i%2
        return self._obs()

    def _obs(self):
        return {str(a.id): {'age':self.population.age(a.id,self.tick),
                            'sex':a.genome.sex, 'food':self.food,
                            'neighbors':tuple(str(b.id) for b in self.population.living()
                                               if b.id != a.id and abs(self.locations[str(b.id)] - self.locations[str(a.id)]) <= 1)}
                for a in self.population.living()}

    def step(self, actions):
        old=self._obs()
        if set(actions)!=set(old): raise ValueError('invalid action identities')
        events=[]; rewards={k:0. for k in old}; terminated={k:False for k in old}
        # 1. Resource budget. Foraging yields food only if enough stock remains.
        for k in sorted(actions,key=int):
            if actions[k].get('forage') and self.food >= 1:
                self.food -= 1
                rewards[k] += 1
        # 2. Simultaneous proposals, paired once. No predefined preferences.
        matched=set()
        for k in sorted(actions,key=int):
            mate = str(actions[k].get('mate',''))
            if not mate or mate not in actions or k in matched or mate in matched:
                continue
            if str(actions[mate].get('mate','')) != k: continue
            a,b=int(k),int(mate)
            if self.population.can_reproduce(a,b,self.tick,cooldown_ticks=self.tpy*2):
                # Birth is not dependent on the neural policy's success score.
                newborn=self.population.birth(a,b,self.tick)
                self.population.register_reproduction(a,b,self.tick)
                self.locations[str(newborn.id)]=self.locations[k]
                matched.update((k,mate))
                events.append({'type':'birth','identity':str(newborn.id), 'parents':[k,mate],
                               'lineage':newborn.lineage_id})
        self.tick += 1
        # 3. Ageing and finite lifespan. Toy rule only.
        for a in list(self.population.living()):
            if self.population.age(a.id,self.tick) >= self.max_age:
                self.population.death(a.id,self.tick,'age_limit')
                terminated[str(a.id)]=True
                events.append({'type':'death','identity':str(a.id),'reason':'age_limit'})
        return WorldStep(self._obs(),rewards,terminated,events)

    def snapshot(self):
        agents=self.population.agents
        # Count only matured children; still-young ones are censored.
        matured={}
        for a in agents.values():
            if a.parent_ids and self.population.age(a.id,self.tick) >= a.genome.phenotype(self.population.age(a.id,self.tick))['MAT']:
                for p in a.parent_ids:
                    lineage=agents[p].lineage_id
                    matured[lineage]=matured.get(lineage,0)+1
        return {'tick':self.tick,'food':self.food,
                'lineage_by_identity':{str(a.id):a.lineage_id for a in agents.values()},
                'alive':len(self.population.living()),
                'mature_offspring_by_lineage':matured}


class SilenceAndForage:
    """Scripted policy for contract tests; this is NOT reinforcement learning."""
    def act(self, observations, memories, lineage_ids):
        actions={}
        next_memories={}
        for k,obs in observations.items():
            partners=[n for n in obs['neighbors'] if
                      n in observations and observations[n]['sex'] != obs['sex']]
            # Deterministic mutual pairing in the tiny test world.
            target = min(partners,key=int) if partners else None
            actions[k]={'forage':True,'mate':target,'emit':False}
            next_memories[k]=int(memories.get(k,0))+1
        return actions,next_memories

class CountingLearner:
    """Counts trajectories. Deliberately DOES NOT implement gradient updates."""
    def __init__(self): self.transitions=0; self.terminals=0
    def observe(self,transitions):
        self.transitions+=len(transitions)
        self.terminals+=sum(x.terminated for x in transitions)
    def finish_cycle(self):
        return {'transitions_collected':self.transitions,'terminal_transitions':self.terminals,
                'weights_updated':False}
