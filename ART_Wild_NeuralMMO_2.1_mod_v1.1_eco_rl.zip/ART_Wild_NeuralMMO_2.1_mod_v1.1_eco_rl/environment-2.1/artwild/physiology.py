"""Opt-in ART-Wild physiology hooks for Neural MMO players.

The upstream env does not attach a physiology profile, so all changes remain
inactive in vanilla nmmo.Env. Only integer-valued health/food/water APIs are
used; fractional metabolic costs accumulate separately per living individual.
These are simulation tuning rules, NOT biological calibrations.
"""
from __future__ import annotations
from dataclasses import dataclass


def clamp(value, low, high):
    return max(low, min(high, value))


@dataclass
class Physiology:
    genome: object
    born_tick: int
    ticks_per_year: int
    food_debt: float = 0.0
    senescence_debt: float = 0.0

    def age(self, tick):
        return max(0.0, (tick - self.born_tick) / self.ticks_per_year)

    def traits(self, tick):
        return self.genome.phenotype(self.age(tick))


def outgoing_melee_bonus(profile, tick):
    """Small flat STR modifier, applied only to melee strikes."""
    if profile is None:
        return 0
    strength = profile.traits(tick)['STR']
    # Age has a gradual functional cost after 55; mutation and disorders matter.
    old_age = max(0, profile.age(tick) - 55)
    strength = max(1.0, strength - old_age * profile.traits(tick)['aging_rate'] * 0.12)
    return int(round(clamp((strength - 10) * 0.35, -3, 4)))


def incoming_damage(profile, tick, damage):
    """CON reduces/increases damage by a modest amount, without changing HP max."""
    if profile is None or damage <= 0:
        return damage
    constitution = profile.traits(tick)['CON']
    age_penalty = max(0, profile.age(tick) - 60) * profile.traits(tick)['aging_rate'] * 0.1
    effective = max(1.0, constitution - age_penalty)
    multiplier = clamp(1.0 - 0.025 * (effective - 10), 0.75, 1.35)
    return max(1, int(round(damage * multiplier)))


def metabolic_cost(profile, tick):
    """Additional food demand per tick above base NMMO depletion."""
    values = profile.traits(tick)
    growth = values['growth_rate']
    age = profile.age(tick)
    # Growth disorders reduce biomass growth but still have a small resource cost.
    juvenile_cost = 0.05 * growth if age < values['MAT'] else 0.0
    return clamp(0.10 * values['energy_cost'] + juvenile_cost, 0.0, 3.0)


def senescence_cost(profile, tick):
    """Slow continuous vitality cost from old age, not a hard life cutoff."""
    age = profile.age(tick)
    if age <= 65:
        return 0.0
    return clamp((age - 65) * profile.traits(tick)['aging_rate'] * 0.006, 0.0, 5.0)


def apply_lifecycle(player, tick):
    """Apply optional physiology after vanilla resources update, before realm cull.

    Food and aging costs accumulate so fractional daily effects are not rounded
    into zero. NMMO's own starvation and dehydration remain unchanged.
    """
    profile = getattr(player, 'artwild_physiology', None)
    if profile is None or not player.alive:
        return
    if getattr(player, 'immortal', False):
        return
    if player.config.RESOURCE_SYSTEM_ENABLED:
        profile.food_debt += metabolic_cost(profile, tick)
        whole = int(profile.food_debt)
        if whole:
            player.resources.food.decrement(whole)
            profile.food_debt -= whole
    profile.senescence_debt += senescence_cost(profile, tick)
    whole = int(profile.senescence_debt)
    if whole:
        player.receive_damage(None, whole)
        profile.senescence_debt -= whole
