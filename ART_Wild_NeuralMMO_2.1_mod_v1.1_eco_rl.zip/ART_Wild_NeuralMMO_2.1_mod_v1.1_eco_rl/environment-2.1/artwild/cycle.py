"""ART-Wild's two-loop orchestration: lifetime simulation and inter-cycle planning.

This module is independent of Neural MMO, neural-network implementations, and
special-purpose RL libraries. It never pretends to train weights: trainers and
distillers are injected via explicit protocols. An observation-only evaluation
cycle can run with frozen policies and no external updates.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from collections import Counter
from typing import Any, Protocol


class World(Protocol):
    def reset(self, seed: int, lineage_ids: tuple[int, ...]) -> dict[str, Any]: ...
    def step(self, actions: dict[str, Any]) -> "WorldStep": ...
    def snapshot(self) -> dict[str, Any]: ...


class Policy(Protocol):
    def act(self, observations: dict[str, Any], memories: dict[str, Any],
            lineage_ids: dict[str, int]) -> tuple[dict[str, Any], dict[str, Any]]: ...


class Learner(Protocol):
    def observe(self, transitions: list["Transition"]) -> None: ...
    def finish_cycle(self) -> dict[str, Any]: ...


@dataclass
class WorldStep:
    observations: dict[str, Any]
    rewards: dict[str, float]
    terminated: dict[str, bool]
    events: list[dict[str, Any]] = field(default_factory=list)


@dataclass(frozen=True)
class Transition:
    identity: str
    lineage_id: int
    observation: Any
    action: Any
    reward: float
    next_observation: Any | None
    terminated: bool


@dataclass(frozen=True)
class CycleConfig:
    max_ticks: int = 1000
    training: bool = True
    stop_on_extinction: bool = True

    def __post_init__(self):
        if self.max_ticks < 1:
            raise ValueError('max_ticks must be positive')


@dataclass
class CycleResult:
    cycle_id: int
    ticks: int
    end_reason: str
    births: int
    deaths: int
    founder_count: int
    alive: int
    mature_offspring_by_lineage: dict[int, int]
    lineage_living: dict[int, int]
    event_log: list[dict[str, Any]]
    world_snapshot: dict[str, Any]
    learner_report: dict[str, Any] | None


class CycleEngine:
    """One world run. It does NOT reset the world between ticks.

    Lifetime keys are globally unique within a cycle and never recycled.
    Newborns receive *fresh* memory from Policy.act; old memories are dropped.
    Agent identities must never be re-used by the World adapter.
    """
    def __init__(self, world: World, policy: Policy, *, learner: Learner | None = None):
        self.world, self.policy, self.learner = world, policy, learner

    def run(self, cycle_id: int, seed: int, lineages: tuple[int, ...],
            config: CycleConfig) -> CycleResult:
        if cycle_id < 1 or not lineages:
            raise ValueError('cycle_id must be positive and at least one lineage is required')
        if config.training and self.learner is None:
            raise ValueError('training=True requires an explicit Learner')
        observations = self.world.reset(seed, lineages)
        memories: dict[str, Any] = {}
        log: list[dict[str, Any]] = []
        seen: set[str] = set(observations)
        founders = len(observations)
        births = deaths = ticks = 0
        reason = 'tick_limit'
        for t in range(config.max_ticks):
            if not observations and config.stop_on_extinction:
                reason = 'extinction'
                break
            ids = self.world.snapshot()['lineage_by_identity']
            if not set(observations).issubset(ids):
                raise RuntimeError('world missing lineage for active agent')
            actions, proposed_memories = self.policy.act(observations, dict(memories),
                                                        {k: ids[k] for k in observations})
            if set(actions) != set(observations):
                raise RuntimeError('policy must return exactly one action per living agent')
            if not set(proposed_memories).issubset(observations):
                raise RuntimeError('policy returned memory for an unknown lifetime')
            step = self.world.step(actions)
            previous = set(observations)
            now = set(step.observations)
            if previous & now != (previous - {k for k in previous if step.terminated.get(k, False)}):
                raise RuntimeError('departing agents must receive terminated=True')
            if any(k in seen for k in now - previous):
                raise RuntimeError('world recycled a lifetime identity')
            newborns = now - previous
            seen.update(newborns)
            births += len(newborns)
            deaths += sum(bool(step.terminated.get(k, False)) for k in previous)
            if config.training:
                transitions = [Transition(k, ids[k], observations[k], actions[k],
                                          float(step.rewards.get(k, 0.)), step.observations.get(k),
                                          bool(step.terminated.get(k, False))) for k in previous]
                self.learner.observe(transitions)
            # Crucial: no memory carryover into newborn IDs, ever.
            memories = {k: proposed_memories[k] for k in now & previous if k in proposed_memories}
            observations = step.observations
            for event in step.events:
                log.append({'cycle_id': cycle_id, 'tick': t + 1, **event})
            ticks = t + 1
            if not now and config.stop_on_extinction:
                reason = 'extinction'
                break
        snapshot = self.world.snapshot()
        alive_lineages = Counter(snapshot['lineage_by_identity'][k] for k in observations)
        # Only offspring that reached adulthood count. The world is responsible
        # for supplying that non-leaky metric; zero is not inferred as failure.
        matured = dict(snapshot.get('mature_offspring_by_lineage', {}))
        report = self.learner.finish_cycle() if config.training else None
        return CycleResult(cycle_id, ticks, reason, births, deaths, founders,
                           len(observations), matured, dict(alive_lineages),
                           log, snapshot, report)


@dataclass(frozen=True)
class NextCyclePlan:
    parent_cycle: int
    selected_lineages: tuple[int, ...]
    distilled: bool
    mutation_requested: bool
    note: str


class CyclePlanner:
    """Plan next experiment. NO network weights are modified here.

    Success can be approximated from adult offspring, with a fallback to
    living lineages when no offspring matured yet. This is bookkeeping, not
    a trained distiller or a claim about biological fitness.
    """
    def plan(self, result: CycleResult, *, use_distillation: bool = False,
             request_mutations: bool = False) -> NextCyclePlan:
        counts = result.mature_offspring_by_lineage or result.lineage_living
        selected = tuple(sorted((k for k,v in counts.items() if v > 0),
                                key=lambda k: (-counts[k],k)))
        return NextCyclePlan(result.cycle_id, selected, use_distillation,
                             request_mutations,
                             'Distillation and mutation are requests only; '
                             'a separate weight-transforming component must execute them.')
