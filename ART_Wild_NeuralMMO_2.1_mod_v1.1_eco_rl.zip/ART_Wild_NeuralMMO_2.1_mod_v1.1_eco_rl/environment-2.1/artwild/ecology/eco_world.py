"""CycleEngine-compatible survival world backed by EcologyEngine v1.0.

Uses SpeciesRegistry, PlantPatch, AnimalPopulation, and ClimateState.
Never exposes hidden physiological traits of plants or animals in observations.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import numpy as np
from artwild.art.encoder import MAT_GRASS, MAT_STONE, MAT_WATER
from artwild.cycle import WorldStep
from artwild.ecology.engine import EcologyEngine
from artwild.ecology.species import SpeciesRegistry
from artwild.rl.survival_env import ACTION_DELTAS, NUM_ACTIONS, _AgentState


@dataclass(frozen=True)
class EcoConfig:
    grid_size: int = 16
    chunk_size: int = 8
    view_radius: int = 4
    n_agents: int = 4
    n_water: int = 8
    n_stones: int = 10
    n_plant_species: int = 4
    n_animal_species: int = 3
    n_initial_plants: int = 24
    n_initial_herbivores: int = 8
    n_initial_carnivores: int = 3
    max_ticks_per_life: int = 180
    respawn_on_death: bool = True
    food_decay: float = 2.0
    water_decay: float = 2.0


class EcoSurvivalWorld:
    """Connects EcologyEngine v1.0 to CycleEngine's World protocol."""

    def __init__(self, config: EcoConfig | None = None):
        self.cfg = config or EcoConfig()
        self.rng = np.random.default_rng(0)
        self.tick = 0
        self._next_bio_id = 1
        self.grid = np.full((self.cfg.grid_size, self.cfg.grid_size), MAT_GRASS, dtype=int)
        self.registry: SpeciesRegistry | None = None
        self.eco: EcologyEngine | None = None
        self.agents: dict[str, _AgentState] = {}
        self._lineage_by_identity: dict[str, int] = {}
        self._lineages: tuple[int, ...] = (0,)

    @property
    def raw_obs_dim(self) -> int:
        return 12

    def _active_chunks(self) -> set[tuple[int, int]]:
        if self.eco is None:
            return set()
        vr = self.cfg.view_radius
        S = self.cfg.grid_size
        chunks: set[tuple[int, int]] = set()
        for ag in self.agents.values():
            r0, r1 = max(0, ag.r - vr), min(S - 1, ag.r + vr)
            c0, c1 = max(0, ag.c - vr), min(S - 1, ag.c + vr)
            for rr in (r0, r1):
                for cc in (c0, c1):
                    chunks.add(self.eco.animals.chunk_of(rr, cc))
        return chunks

    def reset(self, seed: int, lineage_ids: tuple[int, ...]) -> dict[str, Any]:
        if not lineage_ids:
            raise ValueError('at least one lineage_id is required')
        self.rng = np.random.default_rng(seed)
        self.tick = 0
        self._next_bio_id = 1
        self._lineages = tuple(lineage_ids)
        self.agents.clear()
        self._lineage_by_identity.clear()

        S = self.cfg.grid_size
        self.grid = np.full((S, S), MAT_GRASS, dtype=int)
        coords = [(r, c) for r in range(S) for c in range(S)]
        self.rng.shuffle(coords)
        idx = 0
        for _ in range(self.cfg.n_stones):
            r, c = coords[idx]; idx += 1
            self.grid[r, c] = MAT_STONE
        for _ in range(self.cfg.n_water):
            r, c = coords[idx]; idx += 1
            self.grid[r, c] = MAT_WATER

        self.registry = SpeciesRegistry(seed=seed + 500)
        self.registry.populate(
            n_plants=self.cfg.n_plant_species,
            n_animals=self.cfg.n_animal_species,
        )
        self.eco = EcologyEngine(
            self.grid,
            self.registry,
            chunk_size=self.cfg.chunk_size,
            seed=seed + 1000,
        )

        # Place plants from generated species
        plant_ids = list(self.registry.plants.keys())
        habitable = [(r, c) for r in range(S) for c in range(S) if self.grid[r, c] == MAT_GRASS]
        self.rng.shuffle(habitable)
        for i in range(min(self.cfg.n_initial_plants, len(habitable))):
            pr, pc = habitable[i]
            self.eco.plants.place_plant(pr, pc, plant_ids[i % len(plant_ids)], mature=True)

        # Spawn herbivores & carnivores
        herb_ids = [sid for sid, sp in self.registry.animals.items() if sp.diet in ('herbivore', 'omnivore')]
        carn_ids = [sid for sid, sp in self.registry.animals.items() if sp.diet == 'carnivore']
        if not herb_ids:
            herb_ids = [self.registry.add_animal(diet='herbivore').species_id]
        if not carn_ids:
            carn_ids = [self.registry.add_animal(diet='carnivore').species_id]

        for i in range(self.cfg.n_initial_herbivores):
            hr, hc = habitable[int(self.rng.integers(len(habitable)))]
            self.eco.animals.spawn_active(herb_ids[i % len(herb_ids)], hr, hc, energy=65.0)
        for i in range(self.cfg.n_initial_carnivores):
            cr, cc = habitable[int(self.rng.integers(len(habitable)))]
            self.eco.animals.spawn_active(carn_ids[i % len(carn_ids)], cr, cc, energy=70.0)

        for i in range(self.cfg.n_agents):
            self._spawn_agent(self._lineages[i % len(self._lineages)])

        self.eco.animals.sync_active_chunks(self._active_chunks())
        return self._all_obs()

    def _spawn_agent(self, lineage_id: int) -> str:
        S = self.cfg.grid_size
        habitable = [(r, c) for r in range(S) for c in range(S)
                     if self.grid[r, c] not in (MAT_STONE, MAT_WATER)]
        r, c = habitable[int(self.rng.integers(len(habitable)))]
        bio_id = self._next_bio_id
        self._next_bio_id += 1
        key = str(bio_id)
        self.agents[key] = _AgentState(bio_id=bio_id, lineage_id=lineage_id, r=r, c=c)
        self._lineage_by_identity[key] = lineage_id
        return key

    def _local_tiles(self, r: int, c: int) -> np.ndarray:
        vr = self.cfg.view_radius
        S = self.cfg.grid_size
        patch = np.full((2 * vr + 1, 2 * vr + 1), MAT_STONE, dtype=int)
        for dr in range(-vr, vr + 1):
            for dc in range(-vr, vr + 1):
                rr, cc = r + dr, c + dc
                if 0 <= rr < S and 0 <= cc < S:
                    patch[dr + vr, dc + vr] = self.grid[rr, cc]
        return patch

    def _obs_for(self, key: str) -> dict[str, Any]:
        """Public observations only — NEVER exposes hidden plant/animal physiological traits."""
        ag = self.agents[key]
        vr = self.cfg.view_radius
        S = float(max(1, self.cfg.grid_size))
        entities = []
        for ok, oag in self.agents.items():
            if ok != key and abs(oag.r - ag.r) <= vr and abs(oag.c - ag.c) <= vr:
                entities.append((oag.r - ag.r, oag.c - ag.c, False))
        for anim in self.eco.animals.active_animals.values():
            if abs(anim.r - ag.r) <= vr and abs(anim.c - ag.c) <= vr:
                entities.append((anim.r - ag.r, anim.c - ag.c, True))

        raw = np.zeros(12, dtype=np.float32)
        raw[0] = ag.health / 100.0
        raw[1] = ag.food / 100.0
        raw[2] = ag.water / 100.0
        raw[11] = ag.age / float(max(1, self.cfg.max_ticks_per_life))

        # Nearest visible plant & water tile deltas (public spatial cues only)
        plant_pts = np.argwhere(self.eco.plants.yield_biomass > 0.0)
        if len(plant_pts) > 0:
            dists = np.abs(plant_pts[:, 0] - ag.r) + np.abs(plant_pts[:, 1] - ag.c)
            best = plant_pts[int(np.argmin(dists))]
            raw[3] = float(best[0] - ag.r) / S
            raw[4] = float(best[1] - ag.c) / S
        water_pts = np.argwhere(self.grid == MAT_WATER)
        if len(water_pts) > 0:
            dists = np.abs(water_pts[:, 0] - ag.r) + np.abs(water_pts[:, 1] - ag.c)
            best = water_pts[int(np.argmin(dists))]
            raw[5] = float(best[0] - ag.r) / S
            raw[6] = float(best[1] - ag.c) / S
        if self.eco.animals.active_animals:
            nearest = min(
                self.eco.animals.active_animals.values(),
                key=lambda a: abs(a.r - ag.r) + abs(a.c - ag.c),
            )
            raw[7] = (nearest.r - ag.r) / S
            raw[8] = (nearest.c - ag.c) / S

        return {
            'health': ag.health,
            'food': ag.food,
            'water': ag.water,
            'age': float(ag.age),
            'tile_materials': self._local_tiles(ag.r, ag.c),
            'entities': entities,
            'inventory_count': ag.inventory_count,
            'raw_obs': raw,
        }

    def _all_obs(self) -> dict[str, Any]:
        return {k: self._obs_for(k) for k in self.agents}

    def step(self, actions: dict[str, Any]) -> WorldStep:
        if set(actions) != set(self.agents):
            raise ValueError('actions keys must match living agents')
        S = self.cfg.grid_size
        rewards = {k: 0.1 for k in self.agents}
        terminated = {k: False for k in self.agents}
        events: list[dict[str, Any]] = []

        for k in sorted(self.agents, key=int):
            ag = self.agents[k]
            act = actions[k]
            act_idx = int(act['move'] if isinstance(act, dict) else act)
            if not 0 <= act_idx < NUM_ACTIONS:
                act_idx = 0
            dr, dc = ACTION_DELTAS[act_idx]
            nr, nc = ag.r + dr, ag.c + dc
            if 0 <= nr < S and 0 <= nc < S and self.grid[nr, nc] not in (MAT_STONE, MAT_WATER):
                ag.r, ag.c = nr, nc

            # Harvest plant yield via PlantPatch (fruit trees keep structural biomass)
            gained, _ = self.eco.plants.harvest(ag.r, ag.c, amount=0.6)
            if gained > 0.0:
                ag.food = min(100.0, ag.food + gained)
                ag.inventory_count = min(12, ag.inventory_count + 1)
                rewards[k] += 0.5

            # Drink adjacent water
            for wr, wc in ACTION_DELTAS[1:]:
                rr, cc = ag.r + wr, ag.c + wc
                if 0 <= rr < S and 0 <= cc < S and self.grid[rr, cc] == MAT_WATER:
                    ag.water = min(100.0, ag.water + 25.0)
                    rewards[k] += 0.4
                    break

        agent_dmg = self.eco.step(
            self._active_chunks(),
            {k: (ag.r, ag.c) for k, ag in self.agents.items()},
        )

        self.tick += 1
        departed: list[tuple[str, int, str]] = []
        for k in list(self.agents):
            ag = self.agents[k]
            ag.age += 1
            ag.food = max(0.0, ag.food - self.cfg.food_decay)
            ag.water = max(0.0, ag.water - self.cfg.water_decay)
            if ag.food <= 0.0 or ag.water <= 0.0:
                ag.health -= 10.0
                rewards[k] -= 0.4
            else:
                ag.health = min(100.0, ag.health + 1.0)

            if k in agent_dmg:
                ag.health -= agent_dmg[k]
                rewards[k] -= 1.0

            if ag.health <= 0.0:
                terminated[k] = True
                rewards[k] -= 2.0
                departed.append((k, ag.lineage_id, 'health_zero'))
            elif ag.age >= self.cfg.max_ticks_per_life:
                terminated[k] = True
                departed.append((k, ag.lineage_id, 'max_age'))

        for k, lin, reason in departed:
            self.agents.pop(k)
            events.append({'type': 'death', 'identity': k, 'lineage': lin, 'reason': reason})
            if self.cfg.respawn_on_death:
                nk = self._spawn_agent(lin)
                events.append({'type': 'birth', 'identity': nk, 'lineage': lin})

        return WorldStep(self._all_obs(), rewards, terminated, events)

    def snapshot(self) -> dict[str, Any]:
        eco_summary = None
        if self.eco is not None:
            eco_summary = {
                'plant_tiles': int(np.sum(self.eco.plants.species_id > 0)),
                'total_yield_biomass': float(np.sum(self.eco.plants.yield_biomass)),
                'animals_total': self.eco.animals.total_count(),
                'animals_active': len(self.eco.animals.active_animals),
                'active_chunks': len(self.eco.animals.active_chunks),
                'temperature': self.eco.climate.temperature,
                'births': self.eco.animals.births,
                'deaths': self.eco.animals.deaths,
                'predations': self.eco.animals.predations,
            }
        return {
            'tick': self.tick,
            'alive': len(self.agents),
            'lineage_by_identity': dict(self._lineage_by_identity),
            'eco_stats': eco_summary,
        }
