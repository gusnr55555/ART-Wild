"""Lightweight rule-based ecosystem: plant growth/spread, herbivores, carnivores, and food chain.

Pure Python + NumPy (no PyTorch or Neural MMO dependency).
Animals use fast rule-based behaviour (forage/hunt, flee, reproduce) so compute
remains focused on intelligent ART-Wild agents.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from artwild.art.encoder import MAT_FOILAGE, MAT_GRASS, MAT_STONE, MAT_WATER


@dataclass(frozen=True)
class PlantSpecies:
    name: str
    growth_rate: float      # biomass added per tick when alive
    max_biomass: float
    nutrition: float        # energy/food gained per unit biomass eaten
    spread_prob: float      # probability per tick to seed an adjacent empty grass tile


@dataclass(frozen=True)
class AnimalSpecies:
    name: str
    diet: str               # 'herbivore' or 'carnivore'
    sense_radius: int
    energy_decay: float
    reproduce_threshold: float
    reproduce_cost: float
    max_age: int
    attack_damage: float    # damage dealt to prey/agents per tick when adjacent
    meat_nutrition: float   # energy gained by predator when killed


DEFAULT_PLANT_SPECIES: dict[str, PlantSpecies] = {
    'forage_grass': PlantSpecies('forage_grass', growth_rate=0.12, max_biomass=1.0, nutrition=22.0, spread_prob=0.06),
    'berry_bush': PlantSpecies('berry_bush', growth_rate=0.08, max_biomass=1.5, nutrition=32.0, spread_prob=0.03),
}

DEFAULT_ANIMAL_SPECIES: dict[str, AnimalSpecies] = {
    'rabbit': AnimalSpecies(
        name='rabbit',
        diet='herbivore',
        sense_radius=4,
        energy_decay=1.6,
        reproduce_threshold=75.0,
        reproduce_cost=35.0,
        max_age=120,
        attack_damage=0.0,
        meat_nutrition=45.0,
    ),
    'wolf': AnimalSpecies(
        name='wolf',
        diet='carnivore',
        sense_radius=5,
        energy_decay=1.8,
        reproduce_threshold=85.0,
        reproduce_cost=40.0,
        max_age=150,
        attack_damage=20.0,
        meat_nutrition=55.0,
    ),
}

_DIRS: tuple[tuple[int, int], ...] = ((-1, 0), (1, 0), (0, -1), (0, 1))


@dataclass
class Animal:
    animal_id: int
    species: str
    r: int
    c: int
    energy: float = 55.0
    age: int = 0


@dataclass
class EcoStats:
    plant_tiles: int = 0
    total_biomass: float = 0.0
    herbivores: int = 0
    carnivores: int = 0
    plant_spreads: int = 0
    animal_births: int = 0
    animal_deaths: int = 0
    predations: int = 0


class Ecosystem:
    """Manages grid flora and rule-based fauna on a 2-D tile map."""

    def __init__(
        self,
        grid: np.ndarray,
        *,
        seed: int = 0,
        plant_species: dict[str, PlantSpecies] | None = None,
        animal_species: dict[str, AnimalSpecies] | None = None,
        max_animals: int = 64,
    ):
        self.grid = grid
        self.H, self.W = grid.shape
        self.rng = np.random.default_rng(seed)
        self.plant_species = plant_species or dict(DEFAULT_PLANT_SPECIES)
        self.animal_species = animal_species or dict(DEFAULT_ANIMAL_SPECIES)
        self.max_animals = int(max_animals)

        self.plant_kind: np.ndarray = np.full((self.H, self.W), '', dtype=object)
        self.biomass: np.ndarray = np.zeros((self.H, self.W), dtype=float)
        self.animals: dict[int, Animal] = {}
        self._next_animal_id = 1
        self.stats = EcoStats()

    def seed_plants(self, species_name: str, count: int, *, initial_biomass: float = 0.7) -> int:
        sp = self.plant_species[species_name]
        candidates = [
            (r, c) for r in range(self.H) for c in range(self.W)
            if self.grid[r, c] in (MAT_GRASS, MAT_FOILAGE) and self.plant_kind[r, c] == ''
        ]
        self.rng.shuffle(candidates)
        placed = 0
        for r, c in candidates[:count]:
            self.plant_kind[r, c] = species_name
            self.biomass[r, c] = min(sp.max_biomass, float(initial_biomass))
            self.grid[r, c] = MAT_FOILAGE
            placed += 1
        return placed

    def spawn_animal(self, species_name: str, *, r: int | None = None, c: int | None = None,
                     energy: float = 55.0) -> Animal | None:
        if species_name not in self.animal_species:
            raise ValueError(f'unknown animal species: {species_name}')
        if len(self.animals) >= self.max_animals:
            return None
        if r is None or c is None:
            habitable = [
                (rr, cc) for rr in range(self.H) for cc in range(self.W)
                if self.grid[rr, cc] not in (MAT_STONE, MAT_WATER)
            ]
            if not habitable:
                return None
            r, c = habitable[int(self.rng.integers(len(habitable)))]
        aid = self._next_animal_id
        self._next_animal_id += 1
        a = Animal(animal_id=aid, species=species_name, r=int(r), c=int(c), energy=float(energy))
        self.animals[aid] = a
        return a

    def harvest_plant(self, r: int, c: int, amount: float = 0.6) -> float:
        """Consume up to `amount` biomass at (r, c) and return nutrition gained."""
        sp_name = self.plant_kind[r, c]
        if not sp_name or self.biomass[r, c] <= 0.0:
            return 0.0
        sp = self.plant_species[sp_name]
        taken = min(self.biomass[r, c], float(amount))
        self.biomass[r, c] -= taken
        if self.biomass[r, c] <= 1e-6:
            self.biomass[r, c] = 0.0
            self.plant_kind[r, c] = ''
            if self.grid[r, c] == MAT_FOILAGE:
                self.grid[r, c] = MAT_GRASS
        return taken * sp.nutrition

    def _habitable(self, r: int, c: int) -> bool:
        return 0 <= r < self.H and 0 <= c < self.W and self.grid[r, c] not in (MAT_STONE, MAT_WATER)

    def _step_toward(self, r: int, c: int, tr: int, tc: int, *, away: bool = False) -> tuple[int, int]:
        best_pos = (r, c)
        best_dist = abs(tr - r) + abs(tc - c)
        for dr, dc in _DIRS:
            nr, nc = r + dr, c + dc
            if not self._habitable(nr, nc):
                continue
            d = abs(tr - nr) + abs(tc - nc)
            if (away and d > best_dist) or (not away and d < best_dist):
                best_dist = d
                best_pos = (nr, nc)
        return best_pos

    def _random_step(self, r: int, c: int) -> tuple[int, int]:
        opts = [(r, c)] + [(r + dr, c + dc) for dr, dc in _DIRS if self._habitable(r + dr, c + dc)]
        return opts[int(self.rng.integers(len(opts)))]

    def step(self, agent_positions: dict[str, tuple[int, int]] | None = None) -> dict[str, float]:
        """Advance flora & fauna by 1 tick. Returns damage dealt to external agents."""
        agent_damage: dict[str, float] = {}
        new_spreads = 0
        new_births = 0
        new_deaths = 0
        new_predations = 0

        # 1. Plant growth & spatial reproduction
        plant_coords = list(zip(*np.where(self.biomass > 0.0)))
        for r, c in plant_coords:
            sp_name = self.plant_kind[r, c]
            if not sp_name:
                continue
            sp = self.plant_species[sp_name]
            self.biomass[r, c] = min(sp.max_biomass, self.biomass[r, c] + sp.growth_rate)
            if self.biomass[r, c] >= 0.5 * sp.max_biomass and self.rng.random() < sp.spread_prob:
                adj = [
                    (r + dr, c + dc) for dr, dc in _DIRS
                    if 0 <= r + dr < self.H and 0 <= c + dc < self.W
                    and self.grid[r + dr, c + dc] == MAT_GRASS
                    and self.plant_kind[r + dr, c + dc] == ''
                ]
                if adj:
                    nr, nc = adj[int(self.rng.integers(len(adj)))]
                    self.plant_kind[nr, nc] = sp_name
                    self.biomass[nr, nc] = 0.25 * sp.max_biomass
                    self.grid[nr, nc] = MAT_FOILAGE
                    new_spreads += 1

        # 2. Rule-based animals (herbivores first, then carnivores)
        herbivores = [a for a in self.animals.values() if self.animal_species[a.species].diet == 'herbivore']
        carnivores = [a for a in self.animals.values() if self.animal_species[a.species].diet == 'carnivore']

        for a in herbivores:
            if a.animal_id not in self.animals:
                continue
            sp = self.animal_species[a.species]
            # Flee nearest carnivore within sense_radius
            near_pred = None
            best_pd = sp.sense_radius + 1
            for pred in carnivores:
                d = abs(pred.r - a.r) + abs(pred.c - a.c)
                if d <= sp.sense_radius and d < best_pd:
                    best_pd = d
                    near_pred = pred
            if near_pred is not None:
                a.r, a.c = self._step_toward(a.r, a.c, near_pred.r, near_pred.c, away=True)
            elif self.biomass[a.r, a.c] > 0.0:
                a.energy = min(100.0, a.energy + self.harvest_plant(a.r, a.c, amount=0.5))
            else:
                # Seek nearest plant within sense_radius
                best_plant = None
                best_d = sp.sense_radius + 1
                for pr in range(max(0, a.r - sp.sense_radius), min(self.H, a.r + sp.sense_radius + 1)):
                    for pc in range(max(0, a.c - sp.sense_radius), min(self.W, a.c + sp.sense_radius + 1)):
                        if self.biomass[pr, pc] > 0.0:
                            d = abs(pr - a.r) + abs(pc - a.c)
                            if d < best_d:
                                best_d = d
                                best_plant = (pr, pc)
                if best_plant is not None:
                    a.r, a.c = self._step_toward(a.r, a.c, best_plant[0], best_plant[1])
                else:
                    a.r, a.c = self._random_step(a.r, a.c)

        killed_ids: set[int] = set()
        for c_anim in carnivores:
            if c_anim.animal_id not in self.animals:
                continue
            sp = self.animal_species[c_anim.species]
            # Hunt nearest living herbivore (or attack adjacent intelligent agent if hungry)
            near_prey = None
            best_hd = sp.sense_radius + 1
            for h_anim in herbivores:
                if h_anim.animal_id in killed_ids:
                    continue
                d = abs(h_anim.r - c_anim.r) + abs(h_anim.c - c_anim.c)
                if d <= sp.sense_radius and d < best_hd:
                    best_hd = d
                    near_prey = h_anim

            if near_prey is not None:
                if best_hd <= 1:
                    prey_sp = self.animal_species[near_prey.species]
                    c_anim.energy = min(100.0, c_anim.energy + prey_sp.meat_nutrition)
                    killed_ids.add(near_prey.animal_id)
                    new_predations += 1
                else:
                    c_anim.r, c_anim.c = self._step_toward(c_anim.r, c_anim.c, near_prey.r, near_prey.c)
            elif agent_positions and c_anim.energy < 70.0:
                # Opportunistic attack on nearby intelligent agent
                near_ag = None
                best_ad = sp.sense_radius + 1
                for ak, (ar, ac) in agent_positions.items():
                    d = abs(ar - c_anim.r) + abs(ac - c_anim.c)
                    if d <= sp.sense_radius and d < best_ad:
                        best_ad = d
                        near_ag = (ak, ar, ac)
                if near_ag is not None:
                    if best_ad <= 1:
                        agent_damage[near_ag[0]] = agent_damage.get(near_ag[0], 0.0) + sp.attack_damage
                    else:
                        c_anim.r, c_anim.c = self._step_toward(c_anim.r, c_anim.c, near_ag[1], near_ag[2])
                else:
                    c_anim.r, c_anim.c = self._random_step(c_anim.r, c_anim.c)
            else:
                c_anim.r, c_anim.c = self._random_step(c_anim.r, c_anim.c)

        for kid in killed_ids:
            self.animals.pop(kid, None)
            new_deaths += 1

        # 3. Metabolism, aging, reproduction & starvation deaths
        to_spawn: list[tuple[str, int, int, float]] = []
        for aid in list(self.animals):
            a = self.animals[aid]
            sp = self.animal_species[a.species]
            a.age += 1
            a.energy -= sp.energy_decay
            if a.energy <= 0.0 or a.age >= sp.max_age:
                self.animals.pop(aid)
                new_deaths += 1
                continue
            if a.energy >= sp.reproduce_threshold and (len(self.animals) + len(to_spawn)) < self.max_animals:
                a.energy -= sp.reproduce_cost
                to_spawn.append((a.species, a.r, a.c, sp.reproduce_cost * 0.9))

        for sp_name, sr, sc, en in to_spawn:
            if self.spawn_animal(sp_name, r=sr, c=sc, energy=en) is not None:
                new_births += 1

        self.stats = EcoStats(
            plant_tiles=int(np.sum(self.biomass > 0.0)),
            total_biomass=float(np.sum(self.biomass)),
            herbivores=sum(1 for a in self.animals.values() if self.animal_species[a.species].diet == 'herbivore'),
            carnivores=sum(1 for a in self.animals.values() if self.animal_species[a.species].diet == 'carnivore'),
            plant_spreads=self.stats.plant_spreads + new_spreads,
            animal_births=self.stats.animal_births + new_births,
            animal_deaths=self.stats.animal_deaths + new_deaths,
            predations=self.stats.predations + new_predations,
        )
        return agent_damage
