"""Basic & v1.0 hybrid-resolution ecosystem for ART-Wild."""
from artwild.ecology.ecosystem import (
    Animal,
    AnimalSpecies,
    DEFAULT_ANIMAL_SPECIES,
    DEFAULT_PLANT_SPECIES,
    EcoStats,
    Ecosystem,
    PlantSpecies,
)
from artwild.ecology.eco_world import EcoConfig, EcoSurvivalWorld
from artwild.ecology.species import (
    AnimalSpeciesV1,
    PlantSpeciesV1,
    SpeciesRegistry,
    generate_animal_species,
    generate_plant_species,
)
from artwild.ecology.engine import (
    AnimalEntity,
    AnimalPopulation,
    ChunkSpeciesSummary,
    ClimateState,
    EcologyEngine,
    PlantPatch,
)

__all__ = [
    'Animal', 'AnimalSpecies', 'DEFAULT_ANIMAL_SPECIES', 'DEFAULT_PLANT_SPECIES',
    'EcoStats', 'Ecosystem', 'PlantSpecies', 'EcoConfig', 'EcoSurvivalWorld',
    'AnimalSpeciesV1', 'PlantSpeciesV1', 'SpeciesRegistry',
    'generate_animal_species', 'generate_plant_species',
    'AnimalEntity', 'AnimalPopulation', 'ChunkSpeciesSummary',
    'ClimateState', 'EcologyEngine', 'PlantPatch',
]
