"""Ecology v1.0 Engine: Hybrid-resolution flora, fauna, climate, and infectious disease.

Implements:
  - ClimateState: seasonal temperature & rainfall
  - PlantPatch: structural vs. yield biomass (non-destructive fruit-tree harvest),
    seed bank, soil/climate-gated germination, and primitive drop_seed()
  - AnimalPopulation: active individual entities vs. inactive 3-tier energy chunk
    summaries with 4 conservation rules (count, energy, spatial continuity, state)
  - Minimal SIR infectious disease (separate from core.py genetic diseases)
"""
from __future__ import annotations
from dataclasses import dataclass, field
import math
import numpy as np
from artwild.art.encoder import MAT_FOILAGE, MAT_GRASS, MAT_STONE, MAT_WATER
from artwild.ecology.species import AnimalSpeciesV1, PlantSpeciesV1, SpeciesRegistry

_DIRS: tuple[tuple[int, int], ...] = ((-1, 0), (1, 0), (0, -1), (0, 1))


@dataclass
class ClimateState:
    tick: int = 0
    base_temp: float = 20.0
    temp_amp: float = 10.0
    season_period: int = 200
    base_rainfall: float = 0.55
    rain_amp: float = 0.25

    @property
    def temperature(self) -> float:
        return self.base_temp + self.temp_amp * math.sin(2.0 * math.pi * self.tick / max(1, self.season_period))

    @property
    def rainfall(self) -> float:
        return float(np.clip(
            self.base_rainfall + self.rain_amp * math.cos(2.0 * math.pi * self.tick / max(1, self.season_period)),
            0.05, 1.0,
        ))

    def step(self) -> None:
        self.tick += 1


class PlantPatch:
    """Tile-level flora with structural vs. yield biomass and dormant seed bank."""

    def __init__(
        self,
        grid: np.ndarray,
        registry: SpeciesRegistry,
        *,
        seed: int = 0,
    ):
        self.grid = grid
        self.H, self.W = grid.shape
        self.registry = registry
        self.rng = np.random.default_rng(seed)

        self.species_id = np.zeros((self.H, self.W), dtype=int)
        self.structural_biomass = np.zeros((self.H, self.W), dtype=float)
        self.yield_biomass = np.zeros((self.H, self.W), dtype=float)
        self.age = np.zeros((self.H, self.W), dtype=int)
        self.soil_fertility = np.full((self.H, self.W), 0.65, dtype=float)
        self.moisture = np.full((self.H, self.W), 0.55, dtype=float)
        # Seed bank per tile: (r, c) -> {species_id: count}
        self.seed_bank: dict[tuple[int, int], dict[int, int]] = {}

    def _habitable_plant_tile(self, r: int, c: int) -> bool:
        return 0 <= r < self.H and 0 <= c < self.W and self.grid[r, c] in (MAT_GRASS, MAT_FOILAGE)

    def place_plant(self, r: int, c: int, species_id: int, *, mature: bool = True) -> bool:
        if not self._habitable_plant_tile(r, c):
            return False
        sp = self.registry.plants[species_id]
        self.species_id[r, c] = species_id
        frac = 0.75 if mature else 0.20
        total = sp.max_biomass * frac
        self.yield_biomass[r, c] = total * sp.edible_fraction
        self.structural_biomass[r, c] = total - self.yield_biomass[r, c]
        self.age[r, c] = sp.maturation_ticks if mature else 0
        self.grid[r, c] = MAT_FOILAGE
        return True

    def drop_seed(self, r: int, c: int, species_id: int, count: int = 1) -> bool:
        """Primitive seed-drop action (shared physics for natural dispersal & agent planting)."""
        if not self._habitable_plant_tile(r, c) or count < 1:
            return False
        bank = self.seed_bank.setdefault((r, c), {})
        bank[species_id] = bank.get(species_id, 0) + int(count)
        return True

    def harvest(self, r: int, c: int, amount: float = 1.0, *, uproot: bool = False) -> tuple[float, int]:
        """Harvest yield_biomass at (r, c). Returns (net_nutrition, species_id).

        Perennial/fruit-tree species (regrowth_rate > 0) keep their structural_biomass
        alive when uproot=False and regrow yield over subsequent ticks.
        """
        sid = int(self.species_id[r, c])
        if sid == 0 or self.yield_biomass[r, c] <= 0.0:
            return 0.0, 0
        sp = self.registry.plants[sid]
        taken = min(float(self.yield_biomass[r, c]), float(amount))
        self.yield_biomass[r, c] -= taken
        # Net nutrition penalized by toxicity/hardness (raw consumption)
        net = taken * sp.nutrition * max(0.05, 1.0 - 0.7 * sp.toxicity) * max(0.2, 1.0 - 0.4 * sp.hardness)

        if uproot or (sp.regrowth_rate <= 0.0 and self.yield_biomass[r, c] <= 1e-6):
            # Annual / uprooted plant dies and drops remaining seeds
            self.drop_seed(r, c, sid, max(1, sp.seed_output // 2))
            self.species_id[r, c] = 0
            self.structural_biomass[r, c] = 0.0
            self.yield_biomass[r, c] = 0.0
            self.age[r, c] = 0
            if self.grid[r, c] == MAT_FOILAGE:
                self.grid[r, c] = MAT_GRASS
        return net, sid

    def step(self, climate: ClimateState) -> int:
        """Advance plant growth, dispersal, and seed germination. Returns germination count."""
        temp = climate.temperature
        rain = climate.rainfall
        self.moisture = np.clip(0.85 * self.moisture + 0.15 * rain, 0.0, 1.0)
        germinations = 0

        # 1. Grow existing plants
        active_coords = list(zip(*np.where(self.species_id > 0)))
        for r, c in active_coords:
            sid = int(self.species_id[r, c])
            sp = self.registry.plants[sid]
            self.age[r, c] += 1
            temp_ok = abs(temp - sp.temp_opt) <= sp.temp_tol
            water_ok = self.moisture[r, c] >= 0.4 * sp.water_need
            soil_ok = self.soil_fertility[r, c] >= sp.soil_need

            if temp_ok and water_ok and soil_ok:
                max_struct = sp.max_biomass * (1.0 - sp.edible_fraction)
                max_yield = sp.max_biomass * sp.edible_fraction
                if self.structural_biomass[r, c] < max_struct:
                    self.structural_biomass[r, c] = min(
                        max_struct, self.structural_biomass[r, c] + sp.growth_rate * (1.0 - sp.edible_fraction)
                    )
                rate = sp.regrowth_rate if sp.regrowth_rate > 0.0 else sp.growth_rate
                self.yield_biomass[r, c] = min(
                    max_yield, self.yield_biomass[r, c] + rate * sp.edible_fraction
                )
                # Natural seed dispersal when mature
                if self.age[r, c] >= sp.maturation_ticks and self.yield_biomass[r, c] > 0.3 * max_yield:
                    if self.rng.random() < 0.08:
                        dr = int(self.rng.integers(-sp.dispersal_range, sp.dispersal_range + 1))
                        dc = int(self.rng.integers(-sp.dispersal_range, sp.dispersal_range + 1))
                        self.drop_seed(r + dr, c + dc, sid, 1)
            else:
                # Harsh conditions wither yield slowly
                self.yield_biomass[r, c] = max(0.0, self.yield_biomass[r, c] - 0.03)
                if not temp_ok and self.yield_biomass[r, c] <= 0.0:
                    self.structural_biomass[r, c] = max(0.0, self.structural_biomass[r, c] - 0.04)
                    if self.structural_biomass[r, c] <= 1e-6:
                        self.species_id[r, c] = 0
                        self.age[r, c] = 0
                        if self.grid[r, c] == MAT_FOILAGE:
                            self.grid[r, c] = MAT_GRASS

        # 2. Seed bank dormancy & germination on empty habitable tiles
        for pos in list(self.seed_bank):
            r, c = pos
            bank = self.seed_bank[pos]
            if not bank or not self._habitable_plant_tile(r, c):
                self.seed_bank.pop(pos, None)
                continue
            for sid in list(bank):
                sp = self.registry.plants[sid]
                if self.species_id[r, c] == 0:
                    if (abs(temp - sp.temp_opt) <= sp.temp_tol
                            and self.moisture[r, c] >= 0.4 * sp.water_need
                            and self.soil_fertility[r, c] >= sp.soil_need):
                        if self.place_plant(r, c, sid, mature=False):
                            bank[sid] -= 1
                            germinations += 1
                # Dormancy decay
                if bank[sid] > 0 and self.rng.random() > sp.seed_dormancy:
                    bank[sid] = max(0, bank[sid] - 1)
                if bank[sid] <= 0:
                    bank.pop(sid, None)
            if not bank:
                self.seed_bank.pop(pos, None)

        return germinations


@dataclass
class AnimalEntity:
    animal_id: int
    species_id: int
    r: int
    c: int
    energy: float = 60.0
    age: int = 0
    repro_cd: int = 0
    stress: float = 0.0
    disease_state: str = 'S'   # 'S'usceptible, 'I'nfectious, 'R'ecovered
    disease_timer: int = 0
    persistent: bool = False   # if True, never dehydrated to chunk summary


@dataclass
class ChunkSpeciesSummary:
    """3-tier energy + SIR summary for inactive chunks (exact integer count)."""
    low_n: int = 0
    mid_n: int = 0
    high_n: int = 0
    fractional_remainder: float = 0.0
    mean_age: float = 10.0
    s_n: int = 0
    i_n: int = 0
    r_n: int = 0

    @property
    def total(self) -> int:
        return self.low_n + self.mid_n + self.high_n


class AnimalPopulation:
    """Hybrid-resolution animal population with 4 conservation rules."""

    def __init__(
        self,
        grid: np.ndarray,
        registry: SpeciesRegistry,
        *,
        chunk_size: int = 8,
        seed: int = 0,
    ):
        self.grid = grid
        self.H, self.W = grid.shape
        self.registry = registry
        self.chunk_size = max(2, int(chunk_size))
        self.rng = np.random.default_rng(seed)

        self.active_chunks: set[tuple[int, int]] = set()
        self.active_animals: dict[int, AnimalEntity] = {}
        self.inactive_summaries: dict[tuple[int, int], dict[int, ChunkSpeciesSummary]] = {}
        self.dropped_food: dict[tuple[int, int], float] = {}  # primitive food piles on tiles
        self._next_id = 1
        self.births = 0
        self.deaths = 0
        self.predations = 0
        self.infections = 0

    def chunk_of(self, r: int, c: int) -> tuple[int, int]:
        return (r // self.chunk_size, c // self.chunk_size)

    def spawn_active(
        self,
        species_id: int,
        r: int,
        c: int,
        *,
        energy: float = 60.0,
        age: int = 0,
        disease_state: str = 'S',
        persistent: bool = False,
    ) -> AnimalEntity:
        aid = self._next_id
        self._next_id += 1
        ent = AnimalEntity(
            animal_id=aid,
            species_id=species_id,
            r=int(r),
            c=int(c),
            energy=float(energy),
            age=int(age),
            disease_state=disease_state,
            persistent=persistent,
        )
        self.active_animals[aid] = ent
        self.active_chunks.add(self.chunk_of(r, c))
        return ent

    def place_food(self, r: int, c: int, nutrition: float) -> None:
        """Primitive food-drop action (e.g. for attracting or feeding animals)."""
        if 0 <= r < self.H and 0 <= c < self.W and nutrition > 0.0:
            self.dropped_food[(r, c)] = self.dropped_food.get((r, c), 0.0) + float(nutrition)

    def total_count(self, species_id: int | None = None) -> int:
        active = sum(
            1 for a in self.active_animals.values()
            if species_id is None or a.species_id == species_id
        )
        inactive = 0
        for ch_map in self.inactive_summaries.values():
            for sid, summ in ch_map.items():
                if species_id is None or sid == species_id:
                    inactive += summ.total
        return active + inactive

    def _chunk_habitable_tiles(self, cr: int, cc: int) -> list[tuple[int, int]]:
        r0, r1 = cr * self.chunk_size, min(self.H, (cr + 1) * self.chunk_size)
        c0, c1 = cc * self.chunk_size, min(self.W, (cc + 1) * self.chunk_size)
        return [
            (r, c) for r in range(r0, r1) for c in range(c0, c1)
            if self.grid[r, c] not in (MAT_STONE, MAT_WATER)
        ]

    def sync_active_chunks(self, desired_active: set[tuple[int, int]]) -> None:
        """Rehydrate newly active chunks and dehydrate newly inactive chunks (conserving counts)."""
        # Dehydrate chunks leaving active set
        for ch in list(self.active_chunks - desired_active):
            to_remove = [
                a for a in self.active_animals.values()
                if not a.persistent and self.chunk_of(a.r, a.c) == ch
            ]
            if to_remove:
                ch_map = self.inactive_summaries.setdefault(ch, {})
                for a in to_remove:
                    self.active_animals.pop(a.animal_id)
                    summ = ch_map.setdefault(a.species_id, ChunkSpeciesSummary())
                    if a.energy < 35.0:
                        summ.low_n += 1
                    elif a.energy < 70.0:
                        summ.mid_n += 1
                    else:
                        summ.high_n += 1
                    n_prev = summ.total - 1
                    summ.mean_age = (summ.mean_age * n_prev + a.age) / max(1, summ.total)
                    if a.disease_state == 'S':
                        summ.s_n += 1
                    elif a.disease_state == 'I':
                        summ.i_n += 1
                    else:
                        summ.r_n += 1
            self.active_chunks.discard(ch)

        # Rehydrate chunks entering active set
        for ch in sorted(desired_active - self.active_chunks):
            self.active_chunks.add(ch)
            ch_map = self.inactive_summaries.pop(ch, None)
            if not ch_map:
                continue
            tiles = self._chunk_habitable_tiles(*ch)
            if not tiles:
                self.inactive_summaries[ch] = ch_map
                continue
            for sid, summ in list(ch_map.items()):
                energies = (
                    [25.0] * summ.low_n + [55.0] * summ.mid_n + [82.0] * summ.high_n
                )
                states = (
                    ['I'] * summ.i_n + ['R'] * summ.r_n + ['S'] * max(0, len(energies) - summ.i_n - summ.r_n)
                )
                for idx, en in enumerate(energies):
                    tr, tc = tiles[int(self.rng.integers(len(tiles)))]
                    st = states[idx] if idx < len(states) else 'S'
                    self.spawn_active(
                        sid, tr, tc,
                        energy=en, age=int(round(summ.mean_age)), disease_state=st,
                    )
                # Preserve fractional_remainder if non-zero
                if summ.fractional_remainder > 0.0:
                    rem_map = self.inactive_summaries.setdefault(ch, {})
                    rem_map[sid] = ChunkSpeciesSummary(fractional_remainder=summ.fractional_remainder)

    def _habitable(self, r: int, c: int) -> bool:
        return 0 <= r < self.H and 0 <= c < self.W and self.grid[r, c] not in (MAT_STONE, MAT_WATER)

    def _step_toward(self, r: int, c: int, tr: int, tc: int, *, away: bool = False) -> tuple[int, int]:
        best_pos = (r, c)
        best_dist = abs(tr - r) + abs(tc - c)
        for dr, dc in _DIRS:
            nr, nc = r + dr, c + dc
            if not self._habitable(nr, nc):
                continue
            d = abs(tr - nr) + abs(tc - nc)
            if (away and d > best_dist) or (not away and d < best_dist):
                best_dist = d
                best_pos = (nr, nc)
        return best_pos

    def step_active(
        self,
        plants: PlantPatch,
        climate: ClimateState,
        agent_positions: dict[str, tuple[int, int]] | None = None,
    ) -> dict[str, float]:
        """Step all active individual animals, disease transmission, and stress."""
        agent_damage: dict[str, float] = {}
        animals_list = list(self.active_animals.values())
        killed: set[int] = set()

        for a in animals_list:
            if a.animal_id in killed or a.animal_id not in self.active_animals:
                continue
            sp = self.registry.animals[a.species_id]

            # Crowding & threat stress
            nearby_same = sum(
                1 for o in animals_list
                if o.animal_id != a.animal_id and o.species_id == a.species_id
                and abs(o.r - a.r) + abs(o.c - a.c) <= 2
            )
            nearby_threat = any(
                abs(ar - a.r) + abs(ac - a.c) <= sp.flight_distance
                for ar, ac in (agent_positions or {}).values()
            )
            a.stress = float(np.clip(
                0.7 * a.stress + 0.3 * sp.panic_tendency * (0.3 * max(0, nearby_same - 2) + (0.8 if nearby_threat else 0.0)),
                0.0, 1.0,
            ))

            # Movement & foraging/hunting up to movement_speed
            for _ in range(sp.movement_speed):
                if sp.diet in ('herbivore', 'omnivore'):
                    # Eat dropped food first, else harvest plant
                    if self.dropped_food.get((a.r, a.c), 0.0) > 0.0:
                        gained = min(20.0, self.dropped_food[(a.r, a.c)])
                        self.dropped_food[(a.r, a.c)] -= gained
                        if self.dropped_food[(a.r, a.c)] <= 1e-6:
                            self.dropped_food.pop((a.r, a.c), None)
                        a.energy = min(100.0, a.energy + gained * sp.food_efficiency)
                        break
                    if plants.yield_biomass[a.r, a.c] > 0.0:
                        net, _ = plants.harvest(a.r, a.c, amount=0.4)
                        a.energy = min(100.0, a.energy + net * sp.food_efficiency)
                        break
                # Carnivores/omnivores hunt nearby herbivores
                if sp.diet in ('carnivore', 'omnivore'):
                    prey = [
                        o for o in animals_list
                        if o.animal_id != a.animal_id and o.animal_id not in killed
                        and self.registry.animals[o.species_id].diet == 'herbivore'
                        and abs(o.r - a.r) + abs(o.c - a.c) <= sp.sense_radius
                    ]
                    if prey:
                        target = min(prey, key=lambda o: abs(o.r - a.r) + abs(o.c - a.c))
                        d = abs(target.r - a.r) + abs(target.c - a.c)
                        if d <= 1:
                            a.energy = min(100.0, a.energy + 35.0 * sp.food_efficiency)
                            killed.add(target.animal_id)
                            self.predations += 1
                            break
                        a.r, a.c = self._step_toward(a.r, a.c, target.r, target.c)
                        continue
                    elif agent_positions and sp.diet == 'carnivore' and a.energy < 80.0:
                        near_ag = min(
                            agent_positions.items(),
                            key=lambda kv: abs(kv[1][0] - a.r) + abs(kv[1][1] - a.c),
                        )
                        ak, (ar, ac) = near_ag
                        d_ag = abs(ar - a.r) + abs(ac - a.c)
                        if d_ag <= 1:
                            agent_damage[ak] = agent_damage.get(ak, 0.0) + sp.attack_damage
                            break
                        if d_ag <= sp.sense_radius:
                            a.r, a.c = self._step_toward(a.r, a.c, ar, ac)
                            continue
                # Random step if no immediate target
                opts = [(a.r, a.c)] + [
                    (a.r + dr, a.c + dc) for dr, dc in _DIRS if self._habitable(a.r + dr, a.c + dc)
                ]
                a.r, a.c = opts[int(self.rng.integers(len(opts)))]

            # Disease transmission & progression (S -> I -> R -> S)
            if a.disease_state == 'I':
                a.disease_timer -= 1
                for o in animals_list:
                    if o.animal_id != a.animal_id and o.disease_state == 'S':
                        if abs(o.r - a.r) + abs(o.c - a.c) <= 1 and self.rng.random() < 0.25:
                            o.disease_state = 'I'
                            o.disease_timer = 15
                            self.infections += 1
                if a.disease_timer <= 0:
                    a.disease_state = 'R'
                    a.disease_timer = 30
            elif a.disease_state == 'R':
                a.disease_timer -= 1
                if a.disease_timer <= 0:
                    a.disease_state = 'S'

        for kid in killed:
            self.active_animals.pop(kid, None)
            self.deaths += 1

        # Metabolism, aging & stress-gated reproduction
        temp = climate.temperature
        cold_penalty = 0.3 if temp < 5.0 or temp > 38.0 else 0.0
        for aid in list(self.active_animals):
            a = self.active_animals[aid]
            sp = self.registry.animals[a.species_id]
            a.age += 1
            if a.repro_cd > 0:
                a.repro_cd -= 1
            disease_cost = 0.8 if a.disease_state == 'I' else 0.0
            a.energy -= sp.energy_decay + cold_penalty + disease_cost + 0.3 * a.stress
            if a.energy <= 0.0 or a.age >= sp.max_age:
                self.active_animals.pop(aid)
                self.deaths += 1
                continue
            if (a.age >= sp.maturity_age and a.repro_cd == 0
                    and a.energy >= sp.repro_threshold and a.stress < 0.65):
                a.energy -= 25.0
                a.repro_cd = sp.repro_cooldown
                for _ in range(sp.litter_size):
                    self.spawn_active(a.species_id, a.r, a.c, energy=45.0, persistent=a.persistent)
                    self.births += 1

        return agent_damage

    def step_inactive(self, plants: PlantPatch) -> None:
        """Low-frequency ecological update on inactive chunks (conserving energy & counts)."""
        for ch, ch_map in list(self.inactive_summaries.items()):
            r0, r1 = ch[0] * self.chunk_size, min(self.H, (ch[0] + 1) * self.chunk_size)
            c0, c1 = ch[1] * self.chunk_size, min(self.W, (ch[1] + 1) * self.chunk_size)
            for sid, summ in list(ch_map.items()):
                if summ.total == 0:
                    continue
                sp = self.registry.animals[sid]
                if sp.diet in ('herbivore', 'omnivore'):
                    # Conservation Rule 2: deduct actual plant yield_biomass in this chunk
                    avail = float(np.sum(plants.yield_biomass[r0:r1, c0:c1]))
                    demand = 0.25 * summ.total
                    if avail >= demand and avail > 0.0:
                        scale = max(0.0, 1.0 - demand / avail)
                        plants.yield_biomass[r0:r1, c0:c1] *= scale
                        # Healthy growth expectation
                        summ.fractional_remainder += 0.05 * summ.high_n
                    else:
                        # Starvation loss
                        if summ.low_n > 0:
                            summ.low_n -= 1
                            self.deaths += 1
                            if summ.s_n > 0:
                                summ.s_n -= 1
                if summ.fractional_remainder >= 1.0:
                    born = int(summ.fractional_remainder)
                    summ.fractional_remainder -= born
                    summ.mid_n += born
                    summ.s_n += born
                    self.births += born


class EcologyEngine:
    """Orchestrates ClimateState, PlantPatch, and hybrid AnimalPopulation."""

    def __init__(
        self,
        grid: np.ndarray,
        registry: SpeciesRegistry,
        *,
        chunk_size: int = 8,
        seed: int = 0,
    ):
        self.grid = grid
        self.registry = registry
        self.climate = ClimateState()
        self.plants = PlantPatch(grid, registry, seed=seed)
        self.animals = AnimalPopulation(grid, registry, chunk_size=chunk_size, seed=seed + 1)

    def step(
        self,
        active_chunks: set[tuple[int, int]],
        agent_positions: dict[str, tuple[int, int]] | None = None,
    ) -> dict[str, float]:
        self.climate.step()
        self.plants.step(self.climate)
        self.animals.sync_active_chunks(active_chunks)
        dmg = self.animals.step_active(self.plants, self.climate, agent_positions)
        if self.climate.tick % 4 == 0:
            self.animals.step_inactive(self.plants)
        return dmg
