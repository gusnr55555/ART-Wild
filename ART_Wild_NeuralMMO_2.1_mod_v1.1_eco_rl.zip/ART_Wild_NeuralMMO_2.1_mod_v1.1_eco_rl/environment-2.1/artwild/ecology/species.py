"""Ecology v1.0: Physiologically-constrained procedural species generation.

Separates species generation from world placement and survival.
No magic flags (e.g. cultivable, domesticable, is_fruit_tree) exist; utility,
perennial regrowth, and domestication practicality emerge from trait combinations.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class PlantSpeciesV1:
    """16 physiological plant traits + identity."""
    species_id: int
    name: str
    # Growth & metabolism
    growth_rate: float        # biomass gain per tick under optimal conditions
    max_biomass: float        # maximum total biomass (structure + yield)
    water_need: float         # [0, 1] optimal moisture requirement
    temp_opt: float           # optimal temperature (Celsius-like, e.g. 5..35)
    temp_tol: float           # tolerance half-width (> 0)
    # Nutrition & defense
    nutrition: float          # energy per unit harvested yield
    edible_fraction: float    # [0.05, 0.95] fraction of biomass that is harvestable yield
    toxicity: float           # [0, 1] toxin level (reduces net value unless processed)
    hardness: float           # [0, 1] physical toughness / digestion difficulty
    # Reproduction & seeds
    maturation_ticks: int     # ticks before producing seeds/yield
    seed_output: int          # seeds produced per reproductive event
    dispersal_range: int      # max Manhattan radius for natural seed dispersal
    seed_dormancy: float      # [0, 1] survival probability across harsh ticks
    # Soil, storage & regrowth
    soil_need: float          # [0, 1] minimum soil fertility required
    storage_decay: float      # [0, 1] per-tick spoilage rate of harvested yield
    regrowth_rate: float      # >= 0; >0 allows perennial/fruit-tree non-destructive harvest


@dataclass(frozen=True)
class AnimalSpeciesV1:
    """16 physiological & behavioral animal traits + identity."""
    species_id: int
    name: str
    # Body & metabolism
    body_mass: float          # kg-scale mass (e.g. 0.5 .. 200)
    diet: str                 # 'herbivore', 'carnivore', or 'omnivore'
    energy_decay: float       # per-tick basal + movement metabolic cost
    sense_radius: int         # perception range in tiles
    max_age: int              # maximum lifespan in ticks
    # Life history
    maturity_age: int         # ticks until capable of reproduction
    repro_cooldown: int       # minimum ticks between births
    litter_size: int          # offspring per birth
    repro_threshold: float    # energy required to reproduce
    # Temperament & movement (basis for emergent domestication practicality)
    flight_distance: int      # distance at which animal flees threats
    aggression: float         # [0, 1] propensity to attack vs flee
    attack_damage: float      # damage dealt per attack
    sociality: float          # [0, 1] tendency to approach conspecifics (not a herd command)
    panic_tendency: float     # [0, 1] stress sensitivity to crowding / threats
    movement_speed: int       # tiles per tick (1..3)
    food_efficiency: float    # [0.3, 1.0] energy conversion efficiency
    offspring_dependency: int # ticks offspring depend on proximity/care


def generate_plant_species(
    rng: np.random.Generator,
    species_id: int,
    name: str | None = None,
) -> PlantSpeciesV1:
    """Generate a plant species with loose resource-budget trade-offs."""
    # Perennial/woody vs herbaceous tendency (continuous, not a binary flag)
    woodiness = float(rng.uniform(0.0, 1.0))
    max_biomass = float(np.clip(0.6 + 4.0 * (woodiness ** 1.6) + rng.normal(0.0, 0.3), 0.4, 6.0))
    maturation_ticks = int(np.clip(8 + 35 * woodiness + rng.normal(0, 4), 5, 60))

    # Fast growth demands more water & soil fertility
    growth_rate = float(np.clip(rng.uniform(0.03, 0.22) * (1.2 - 0.5 * woodiness), 0.02, 0.25))
    water_need = float(np.clip(0.2 + 2.2 * growth_rate + rng.normal(0.0, 0.12), 0.05, 0.95))
    soil_need = float(np.clip(0.15 + 1.8 * growth_rate + rng.normal(0.0, 0.15), 0.05, 0.90))

    # Perennial regrowth: woody plants often regrow yield without dying; some herbs also regrow
    regrowth_rate = float(
        np.clip(growth_rate * (0.3 + 0.9 * woodiness) + rng.normal(0.0, 0.02), 0.0, 0.22)
    )
    if woodiness < 0.25 and rng.random() < 0.6:
        regrowth_rate = 0.0  # annual-like species

    # Nutrition, edibility, toxicity & hardness: NO forced inverse between nutrition and toxicity
    edible_fraction = float(np.clip(0.75 - 0.45 * woodiness + rng.normal(0.0, 0.12), 0.12, 0.92))
    nutrition = float(np.clip(rng.uniform(12.0, 42.0), 10.0, 45.0))
    defense_budget = float(rng.uniform(0.0, 1.0))
    toxicity = float(np.clip(defense_budget * rng.uniform(0.0, 0.95), 0.0, 0.95))
    hardness = float(np.clip((defense_budget * 0.6 + woodiness * 0.4) * rng.uniform(0.2, 1.0), 0.0, 0.95))

    # Seed trade-off: many seeds <-> smaller per-seed dormancy investment
    seed_output = int(np.clip(rng.integers(1, 7) + int(3 * (1.0 - woodiness)), 1, 10))
    seed_dormancy = float(np.clip(0.85 - 0.06 * seed_output + rng.normal(0.0, 0.1), 0.1, 0.95))
    dispersal_range = int(np.clip(rng.integers(1, 5), 1, 5))

    temp_opt = float(rng.uniform(8.0, 32.0))
    temp_tol = float(rng.uniform(6.0, 16.0))
    storage_decay = float(np.clip(0.02 + 0.12 * (1.0 - hardness) * rng.uniform(0.3, 1.2), 0.005, 0.25))

    return PlantSpeciesV1(
        species_id=species_id,
        name=name or f'plant_{species_id}',
        growth_rate=growth_rate,
        max_biomass=max_biomass,
        water_need=water_need,
        temp_opt=temp_opt,
        temp_tol=temp_tol,
        nutrition=nutrition,
        edible_fraction=edible_fraction,
        toxicity=toxicity,
        hardness=hardness,
        maturation_ticks=maturation_ticks,
        seed_output=seed_output,
        dispersal_range=dispersal_range,
        seed_dormancy=seed_dormancy,
        soil_need=soil_need,
        storage_decay=storage_decay,
        regrowth_rate=regrowth_rate,
    )


def generate_animal_species(
    rng: np.random.Generator,
    species_id: int,
    name: str | None = None,
    *,
    diet: str | None = None,
) -> AnimalSpeciesV1:
    """Generate an animal species with loose physiological trade-offs."""
    if diet is None:
        r = float(rng.random())
        diet = 'herbivore' if r < 0.60 else ('omnivore' if r < 0.80 else 'carnivore')

    log_mass = float(rng.uniform(-0.5, 4.5))
    body_mass = float(np.exp(log_mass))  # ~0.6 kg to ~90 kg
    movement_speed = int(np.clip(1 + int(rng.random() < 0.35) + int(rng.random() < 0.15), 1, 3))

    # Metabolic cost scales with mass^0.65 and speed, not rigidly
    energy_decay = float(np.clip(0.8 + 0.18 * (body_mass ** 0.55) + 0.35 * (movement_speed - 1) + rng.normal(0.0, 0.2), 0.7, 5.5))
    sense_radius = int(np.clip(3 + int(rng.integers(0, 4)), 2, 7))
    max_age = int(np.clip(80 + 25 * log_mass + rng.normal(0, 15), 60, 260))

    # Life history: tendencies with exceptions allowed
    maturity_age = int(np.clip(max_age * rng.uniform(0.12, 0.28), 8, max_age // 2))
    repro_cooldown = int(np.clip(8 + 4 * log_mass + rng.normal(0, 4), 5, 45))
    litter_size = int(np.clip(round(4.0 - 0.5 * log_mass + rng.normal(0, 1.0)), 1, 6))
    repro_threshold = float(np.clip(60.0 + 5.0 * log_mass + rng.normal(0, 5.0), 50.0, 95.0))
    offspring_dependency = int(np.clip(rng.integers(0, max(2, maturity_age // 2)), 0, 25))

    # Temperament & combat
    aggression = float(np.clip((0.55 if diet == 'carnivore' else 0.20) + rng.normal(0.0, 0.2), 0.0, 1.0))
    attack_damage = float(np.clip((4.0 + 3.5 * (body_mass ** 0.45)) * (0.4 + 0.9 * aggression), 1.0, 45.0))
    flight_distance = int(np.clip(round(4.0 * (1.0 - 0.6 * aggression) + rng.normal(0, 1)), 0, 6))
    sociality = float(np.clip(rng.uniform(0.0, 1.0), 0.0, 1.0))
    panic_tendency = float(np.clip((1.0 - 0.5 * aggression) * rng.uniform(0.2, 1.0), 0.05, 0.95))
    food_efficiency = float(np.clip(rng.uniform(0.45, 0.95), 0.35, 1.0))

    return AnimalSpeciesV1(
        species_id=species_id,
        name=name or f'{diet}_{species_id}',
        body_mass=body_mass,
        diet=diet,
        energy_decay=energy_decay,
        sense_radius=sense_radius,
        max_age=max_age,
        maturity_age=maturity_age,
        repro_cooldown=repro_cooldown,
        litter_size=litter_size,
        repro_threshold=repro_threshold,
        flight_distance=flight_distance,
        aggression=aggression,
        attack_damage=attack_damage,
        sociality=sociality,
        panic_tendency=panic_tendency,
        movement_speed=movement_speed,
        food_efficiency=food_efficiency,
        offspring_dependency=offspring_dependency,
    )


class SpeciesRegistry:
    """Generates and stores plant & animal species independently of world placement."""

    def __init__(self, seed: int = 0):
        self.rng = np.random.default_rng(seed)
        self.plants: dict[int, PlantSpeciesV1] = {}
        self.animals: dict[int, AnimalSpeciesV1] = {}
        self._next_plant_id = 1
        self._next_animal_id = 1

    def add_plant(self, sp: PlantSpeciesV1 | None = None, *, name: str | None = None) -> PlantSpeciesV1:
        if sp is None:
            sp = generate_plant_species(self.rng, self._next_plant_id, name=name)
        self._next_plant_id = max(self._next_plant_id + 1, sp.species_id + 1)
        self.plants[sp.species_id] = sp
        return sp

    def add_animal(self, sp: AnimalSpeciesV1 | None = None, *, name: str | None = None,
                   diet: str | None = None) -> AnimalSpeciesV1:
        if sp is None:
            sp = generate_animal_species(self.rng, self._next_animal_id, name=name, diet=diet)
        self._next_animal_id = max(self._next_animal_id + 1, sp.species_id + 1)
        self.animals[sp.species_id] = sp
        return sp

    def populate(self, n_plants: int = 6, n_animals: int = 5) -> None:
        for _ in range(n_plants):
            self.add_plant()
        # Ensure at least one herbivore and one carnivore when n_animals >= 2
        if n_animals >= 1:
            self.add_animal(diet='herbivore')
        if n_animals >= 2:
            self.add_animal(diet='carnivore')
        for _ in range(max(0, n_animals - 2)):
            self.add_animal()
