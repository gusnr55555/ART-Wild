"""v0.8 / v1.1 Experiment Runner: PPO+GRU ('none') vs +V0 ART ('v0') vs +V3 ART ('v3').

Supports both 'survival' (SmallSurvivalWorld) and 'eco' (EcoSurvivalWorld backed
by EcologyEngine v1.0) under identical interaction budgets and common eval seeds.

Usage (requires PyTorch):
    python -m artwild.rl.run_v08 --world eco --seeds 0 1 2 --budget 20000
"""
from __future__ import annotations
import argparse
import time
import numpy as np
from artwild.ecology.eco_world import EcoConfig, EcoSurvivalWorld
from artwild.rl.survival_env import SmallSurvivalWorld, SurvivalConfig
from artwild.rl.ppo_gru import (
    HAS_TORCH,
    ArtAdapter,
    PPOGruTrainer,
    RolloutBuffer,
    TransitionRecord,
)

if HAS_TORCH:
    import torch
    from artwild.rl.ppo_gru import GruActorCritic


def _make_world(world_kind: str):
    if world_kind == 'survival':
        cfg = SurvivalConfig()
        return SmallSurvivalWorld(cfg), cfg.view_radius
    if world_kind == 'eco':
        cfg = EcoConfig()
        return EcoSurvivalWorld(cfg), cfg.view_radius
    raise ValueError(f'unknown world_kind: {world_kind}')


def evaluate_policy(
    trainer: 'PPOGruTrainer',
    mode: str,
    eval_seeds: tuple[int, ...] = (100, 101, 102),
    max_ticks: int = 300,
    world_kind: str = 'survival',
) -> dict[str, float]:
    """Evaluate policy on common seeds with ART + GRU reset on every death."""
    life_rewards: list[float] = []
    life_ticks: list[int] = []

    for seed in eval_seeds:
        world, vr = _make_world(world_kind)
        art = ArtAdapter(mode=mode, view_radius=vr)
        obs = world.reset(seed, (0,))
        art.sync(obs.keys())
        h_states: dict[str, np.ndarray | None] = {k: None for k in obs}
        ep_rew: dict[str, float] = {k: 0.0 for k in obs}
        ep_len: dict[str, int] = {k: 0 for k in obs}

        for _ in range(max_ticks):
            actions = {}
            percepts = {}
            for k in sorted(obs, key=int):
                art_feat, pc = art.observe(k, obs[k])
                act, _, _, _, h_next = trainer.select_action(obs[k]['raw_obs'], art_feat, h_states.get(k))
                actions[k] = act
                percepts[k] = pc
                h_states[k] = h_next

            refs = {k: art.learn(k, percepts[k]) for k in actions}
            step = world.step(actions)

            for k in actions:
                r = float(step.rewards.get(k, 0.0))
                art.credit(k, refs[k], r)
                ep_rew[k] += r
                ep_len[k] += 1
                if step.terminated.get(k, False):
                    life_rewards.append(ep_rew.pop(k))
                    life_ticks.append(ep_len.pop(k))
                    h_states.pop(k, None)

            art.sync(step.observations.keys())
            for k in step.observations:
                if k not in ep_rew:
                    ep_rew[k] = 0.0
                    ep_len[k] = 0
                    h_states[k] = None
            obs = step.observations

        for k in ep_rew:
            life_rewards.append(ep_rew[k])
            life_ticks.append(ep_len[k])

    return {
        'mean_reward': float(np.mean(life_rewards)) if life_rewards else 0.0,
        'mean_survival_ticks': float(np.mean(life_ticks)) if life_ticks else 0.0,
    }


def run_condition(
    mode: str,
    seed: int,
    *,
    budget_steps: int = 20000,
    rollout_ticks: int = 64,
    eval_seeds: tuple[int, ...] = (100, 101, 102),
    world_kind: str = 'survival',
) -> dict[str, float]:
    if not HAS_TORCH:
        raise ImportError('PyTorch is required to run v0.8 PPO+GRU training')

    torch.manual_seed(seed)
    np.random.seed(seed)
    world, vr = _make_world(world_kind)
    art = ArtAdapter(mode=mode, view_radius=vr)
    model = GruActorCritic(raw_dim=world.raw_obs_dim, art_dim=art.feature_dim, hidden_dim=64)
    trainer = PPOGruTrainer(model)

    pre = evaluate_policy(trainer, mode, eval_seeds=eval_seeds, world_kind=world_kind)

    obs = world.reset(seed, (0,))
    art.sync(obs.keys())
    h_states: dict[str, np.ndarray | None] = {k: None for k in obs}
    buffer = RolloutBuffer()

    steps_done = 0
    t_start = time.perf_counter()
    while steps_done < budget_steps:
        buffer.clear()
        for _ in range(rollout_ticks):
            actions = {}
            percepts = {}
            cached = {}
            for k in sorted(obs, key=int):
                art_feat, pc = art.observe(k, obs[k])
                act, lp, val, h_in, h_next = trainer.select_action(
                    obs[k]['raw_obs'], art_feat, h_states.get(k)
                )
                actions[k] = act
                percepts[k] = pc
                cached[k] = (obs[k]['raw_obs'], art_feat, act, lp, val, h_in, h_next)

            refs = {k: art.learn(k, percepts[k]) for k in actions}
            step = world.step(actions)

            for k in actions:
                r = float(step.rewards.get(k, 0.0))
                done = bool(step.terminated.get(k, False))
                art.credit(k, refs[k], r)
                raw_o, art_f, act, lp, val, h_in, h_next = cached[k]
                buffer.add(TransitionRecord(
                    agent_id=k,
                    raw_obs=raw_o,
                    art_features=art_f,
                    action=act,
                    log_prob=lp,
                    value=val,
                    reward=r,
                    done=done,
                    h_in=h_in,
                ))
                steps_done += 1
                if done:
                    h_states.pop(k, None)
                else:
                    h_states[k] = h_next

            art.sync(step.observations.keys())
            for k in step.observations:
                if k not in h_states:
                    h_states[k] = None
            obs = step.observations
            if steps_done >= budget_steps:
                break

        last_vals = {}
        for k in obs:
            art_f, _ = art.observe(k, obs[k])
            last_vals[k] = trainer.estimate_value(obs[k]['raw_obs'], art_f, h_states.get(k))
        trainer.update(buffer, last_vals)

    elapsed = max(1e-6, time.perf_counter() - t_start)
    post = evaluate_policy(trainer, mode, eval_seeds=eval_seeds, world_kind=world_kind)
    return {
        'pre_reward': pre['mean_reward'],
        'post_reward': post['mean_reward'],
        'pre_ticks': pre['mean_survival_ticks'],
        'post_ticks': post['mean_survival_ticks'],
        'steps_per_sec': steps_done / elapsed,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--world', choices=('survival', 'eco'), default='survival')
    parser.add_argument('--seeds', type=int, nargs='+', default=[0, 1, 2])
    parser.add_argument('--budget', type=int, default=20000)
    args = parser.parse_args()

    print(f"World={args.world} | Budget={args.budget} | Seeds={args.seeds}")
    print(f"{'Mode':<8} | {'PreRew':>7} -> {'PostRew':>7} | {'PreTick':>7} -> {'PostTick':>8} | {'Steps/s':>8}")
    print('-' * 66)
    for mode in ('none', 'v0', 'v3'):
        rows = [run_condition(mode, s, budget_steps=args.budget, world_kind=args.world) for s in args.seeds]
        m = {k: float(np.mean([r[k] for r in rows])) for k in rows[0]}
        print(
            f"{mode:<8} | {m['pre_reward']:7.2f} -> {m['post_reward']:7.2f} | "
            f"{m['pre_ticks']:7.1f} -> {m['post_ticks']:8.1f} | {m['steps_per_sec']:8.1f}"
        )


if __name__ == '__main__':
    main()
