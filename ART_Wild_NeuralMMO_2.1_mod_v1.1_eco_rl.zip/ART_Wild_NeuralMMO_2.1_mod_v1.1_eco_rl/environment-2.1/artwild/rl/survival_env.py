"""Small CycleEngine-compatible spatial survival environment for v0.8 PPO+GRU tests.

Pure Python + NumPy (no Neural MMO or PyTorch dependency).
Agents forage food (MAT_FOILAGE) and water (MAT_WATER) on an 11x11 grid while
avoiding moving hazard NPCs. On death, terminated=True is emitted and a newborn
with a fresh monotonic identity spawns so CycleEngine / trainers can verify
per-lifetime GRU + ART memory resets.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import numpy as np
from artwild.art.encoder import MAT_FOILAGE, MAT_GRASS, MAT_STONE, MAT_WATER
from artwild.cycle import WorldStep

# Actions: 0=stay, 1=North, 2=South, 3=East, 4=West
ACTION_DELTAS: tuple[tuple[int, int], ...] = (
    (0, 0),
    (-1, 0),
    (1, 0),
    (0, 1),
    (0, -1),
)
NUM_ACTIONS = len(ACTION_DELTAS)


@dataclass(frozen=True)
class SurvivalConfig:
    grid_size: int = 11
    view_radius: int = 3
    n_agents: int = 4
    n_hazards: int = 2
    n_food: int = 8
    n_water: int = 6
    n_stones: int = 6
    max_ticks_per_life: int = 150
    respawn_on_death: bool = True
    food_decay: float = 2.5
    water_decay: float = 2.5
    hazard_damage: float = 25.0


@dataclass
class _AgentState:
    bio_id: int
    lineage_id: int
    r: int
    c: int
    health: float = 100.0
    food: float = 100.0
    water: float = 100.0
    age: int = 0
    inventory_count: int = 0


class SmallSurvivalWorld:
    """Implements the CycleEngine World protocol."""

    def __init__(self, config: SurvivalConfig | None = None):
        self.cfg = config or SurvivalConfig()
        self.rng = np.random.default_rng(0)
        self.tick = 0
        self._next_bio_id = 1
        self.grid = np.full((self.cfg.grid_size, self.cfg.grid_size), MAT_GRASS, dtype=int)
        self.agents: dict[str, _AgentState] = {}
        self.hazards: list[list[int]] = []
        self._lineage_by_identity: dict[str, int] = {}
        self._lineages: tuple[int, ...] = (0,)

    @property
    def raw_obs_dim(self) -> int:
        # 3 vitals + 4 nearest resource/hazard deltas + 4 adjacent blocked flags + age_frac = 12
        return 12

    def reset(self, seed: int, lineage_ids: tuple[int, ...]) -> dict[str, Any]:
        if not lineage_ids:
            raise ValueError('at least one lineage_id is required')
        self.rng = np.random.default_rng(seed)
        self.tick = 0
        self._next_bio_id = 1
        self._lineages = tuple(lineage_ids)
        self.agents.clear()
        self._lineage_by_identity.clear()

        S = self.cfg.grid_size
        self.grid = np.full((S, S), MAT_GRASS, dtype=int)
        coords = [(r, c) for r in range(S) for c in range(S)]
        self.rng.shuffle(coords)
        idx = 0
        for _ in range(self.cfg.n_stones):
            r, c = coords[idx]; idx += 1
            self.grid[r, c] = MAT_STONE
        for _ in range(self.cfg.n_water):
            r, c = coords[idx]; idx += 1
            self.grid[r, c] = MAT_WATER
        for _ in range(self.cfg.n_food):
            r, c = coords[idx]; idx += 1
            self.grid[r, c] = MAT_FOILAGE

        habitable = [(r, c) for r in range(S) for c in range(S)
                     if self.grid[r, c] in (MAT_GRASS, MAT_FOILAGE)]
        self.hazards = []
        for _ in range(self.cfg.n_hazards):
            hr, hc = habitable[int(self.rng.integers(len(habitable)))]
            self.hazards.append([hr, hc])

        for i in range(self.cfg.n_agents):
            lin = self._lineages[i % len(self._lineages)]
            self._spawn_agent(lin)

        return self._all_obs()

    def _spawn_agent(self, lineage_id: int) -> str:
        S = self.cfg.grid_size
        habitable = [(r, c) for r in range(S) for c in range(S)
                     if self.grid[r, c] in (MAT_GRASS, MAT_FOILAGE)]
        r, c = habitable[int(self.rng.integers(len(habitable)))]
        bio_id = self._next_bio_id
        self._next_bio_id += 1
        key = str(bio_id)
        self.agents[key] = _AgentState(bio_id=bio_id, lineage_id=lineage_id, r=r, c=c)
        self._lineage_by_identity[key] = lineage_id
        return key

    def _local_tiles(self, r: int, c: int) -> np.ndarray:
        vr = self.cfg.view_radius
        S = self.cfg.grid_size
        patch = np.full((2 * vr + 1, 2 * vr + 1), MAT_STONE, dtype=int)
        for dr in range(-vr, vr + 1):
            for dc in range(-vr, vr + 1):
                rr, cc = r + dr, c + dc
                if 0 <= rr < S and 0 <= cc < S:
                    patch[dr + vr, dc + vr] = self.grid[rr, cc]
        return patch

    def _nearest_delta(self, r: int, c: int, target_mat: int) -> tuple[float, float]:
        pts = np.argwhere(self.grid == target_mat)
        if len(pts) == 0:
            return 0.0, 0.0
        dists = np.abs(pts[:, 0] - r) + np.abs(pts[:, 1] - c)
        best = pts[int(np.argmin(dists))]
        S = float(max(1, self.cfg.grid_size))
        return float(best[0] - r) / S, float(best[1] - c) / S

    def _nearest_hazard_delta(self, r: int, c: int) -> tuple[float, float]:
        if not self.hazards:
            return 0.0, 0.0
        dists = [abs(hr - r) + abs(hc - c) for hr, hc in self.hazards]
        hr, hc = self.hazards[int(np.argmin(dists))]
        S = float(max(1, self.cfg.grid_size))
        return float(hr - r) / S, float(hc - c) / S

    def _obs_for(self, key: str) -> dict[str, Any]:
        ag = self.agents[key]
        S = self.cfg.grid_size
        vr = self.cfg.view_radius
        entities = []
        for ok, oag in self.agents.items():
            if ok == key:
                continue
            dr, dc = oag.r - ag.r, oag.c - ag.c
            if abs(dr) <= vr and abs(dc) <= vr:
                entities.append((dr, dc, False))
        for hr, hc in self.hazards:
            dr, dc = hr - ag.r, hc - ag.c
            if abs(dr) <= vr and abs(dc) <= vr:
                entities.append((dr, dc, True))

        f_dr, f_dc = self._nearest_delta(ag.r, ag.c, MAT_FOILAGE)
        w_dr, w_dc = self._nearest_delta(ag.r, ag.c, MAT_WATER)
        h_dr, h_dc = self._nearest_hazard_delta(ag.r, ag.c)

        blocked = []
        for dr, dc in ACTION_DELTAS[1:]:
            rr, cc = ag.r + dr, ag.c + dc
            is_blk = not (0 <= rr < S and 0 <= cc < S) or self.grid[rr, cc] in (MAT_STONE, MAT_WATER)
            blocked.append(1.0 if is_blk else 0.0)

        raw = np.array([
            ag.health / 100.0,
            ag.food / 100.0,
            ag.water / 100.0,
            f_dr, f_dc,
            w_dr, w_dc,
            h_dr, h_dc,
            blocked[0], blocked[1],
            ag.age / float(max(1, self.cfg.max_ticks_per_life)),
        ], dtype=np.float32)

        return {
            'health': ag.health,
            'food': ag.food,
            'water': ag.water,
            'age': float(ag.age),
            'tile_materials': self._local_tiles(ag.r, ag.c),
            'entities': entities,
            'inventory_count': ag.inventory_count,
            'raw_obs': raw,
        }

    def _all_obs(self) -> dict[str, Any]:
        return {k: self._obs_for(k) for k in self.agents}

    def step(self, actions: dict[str, Any]) -> WorldStep:
        if set(actions) != set(self.agents):
            raise ValueError('actions keys must match living agents')

        S = self.cfg.grid_size
        rewards: dict[str, float] = {k: 0.1 for k in self.agents}
        terminated: dict[str, bool] = {k: False for k in self.agents}
        events: list[dict[str, Any]] = []

        # 1. Agent movement & foraging/drinking
        for k in sorted(self.agents, key=int):
            ag = self.agents[k]
            act = actions[k]
            act_idx = int(act['move'] if isinstance(act, dict) else act)
            if not 0 <= act_idx < NUM_ACTIONS:
                act_idx = 0
            dr, dc = ACTION_DELTAS[act_idx]
            nr, nc = ag.r + dr, ag.c + dc
            if 0 <= nr < S and 0 <= nc < S and self.grid[nr, nc] not in (MAT_STONE, MAT_WATER):
                ag.r, ag.c = nr, nc

            # Eat if standing on food
            if self.grid[ag.r, ag.c] == MAT_FOILAGE:
                ag.food = min(100.0, ag.food + 25.0)
                ag.inventory_count = min(12, ag.inventory_count + 1)
                rewards[k] += 0.5
                self.grid[ag.r, ag.c] = MAT_GRASS
                # Respawn food elsewhere to keep world sustainable
                grass = np.argwhere(self.grid == MAT_GRASS)
                if len(grass) > 0:
                    gr, gc = grass[int(self.rng.integers(len(grass)))]
                    self.grid[gr, gc] = MAT_FOILAGE

            # Drink if adjacent to water
            for wr, wc in ACTION_DELTAS[1:]:
                rr, cc = ag.r + wr, ag.c + wc
                if 0 <= rr < S and 0 <= cc < S and self.grid[rr, cc] == MAT_WATER:
                    ag.water = min(100.0, ag.water + 25.0)
                    rewards[k] += 0.4
                    break

        # 2. Hazard NPCs random walk + damage
        for hz in self.hazards:
            dr, dc = ACTION_DELTAS[int(self.rng.integers(NUM_ACTIONS))]
            nr, nc = hz[0] + dr, hz[1] + dc
            if 0 <= nr < S and 0 <= nc < S and self.grid[nr, nc] not in (MAT_STONE, MAT_WATER):
                hz[0], hz[1] = nr, nc

        # 3. Metabolism, hazard damage, aging & death
        self.tick += 1
        departed: list[tuple[str, int, str]] = []
        for k in list(self.agents):
            ag = self.agents[k]
            ag.age += 1
            ag.food = max(0.0, ag.food - self.cfg.food_decay)
            ag.water = max(0.0, ag.water - self.cfg.water_decay)
            if ag.food <= 0.0 or ag.water <= 0.0:
                ag.health -= 10.0
                rewards[k] -= 0.4
            else:
                ag.health = min(100.0, ag.health + 1.0)

            for hr, hc in self.hazards:
                if abs(ag.r - hr) + abs(ag.c - hc) <= 1:
                    ag.health -= self.cfg.hazard_damage
                    rewards[k] -= 1.0

            if ag.health <= 0.0:
                terminated[k] = True
                rewards[k] -= 2.0
                departed.append((k, ag.lineage_id, 'health_zero'))
            elif ag.age >= self.cfg.max_ticks_per_life:
                terminated[k] = True
                departed.append((k, ag.lineage_id, 'max_age'))

        for k, lin, reason in departed:
            self.agents.pop(k)
            events.append({'type': 'death', 'identity': k, 'lineage': lin, 'reason': reason})
            if self.cfg.respawn_on_death:
                nk = self._spawn_agent(lin)
                events.append({'type': 'birth', 'identity': nk, 'lineage': lin})

        return WorldStep(self._all_obs(), rewards, terminated, events)

    def snapshot(self) -> dict[str, Any]:
        return {
            'tick': self.tick,
            'alive': len(self.agents),
            'lineage_by_identity': dict(self._lineage_by_identity),
        }
