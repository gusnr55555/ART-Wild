"""PPO+GRU + ART rollout adapter, buffer, and PyTorch trainer for v0.8.

Pure-NumPy components (`ArtAdapter`, `RolloutBuffer`, `ArtRolloutPolicy`) run
without PyTorch so contract tests execute in any NumPy environment.
`GruActorCritic` and `PPOGruTrainer` require PyTorch (`torch`).
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable
import numpy as np
from artwild.art import ArtLifetimeStore, ArtPerceiver, ExperienceRef, Percept, SensoryEncoder28
from artwild.art.encoder import EncoderConfig
from artwild.rl.survival_env import NUM_ACTIONS

try:
    import torch
    import torch.nn as nn
    from torch.distributions import Categorical
    HAS_TORCH = True
except ImportError:
    torch = None
    nn = None
    Categorical = None
    HAS_TORCH = False


def _replicate_phys_vec(v28: np.ndarray, copies: int = 5) -> np.ndarray:
    if copies <= 1:
        return v28
    extra = np.tile(v28[:3], copies - 1)
    return np.concatenate([v28, extra], axis=0)


class ArtAdapter:
    """Manages per-lifetime SensoryEncoder28 + ArtPerceiver under the v0.7.3 contract."""

    def __init__(self, mode: str = 'none', *, rho: float = 0.90, phys_copies: int = 5, view_radius: int = 3):
        if mode not in ('none', 'v0', 'v3'):
            raise ValueError(f'unknown ART mode: {mode}')
        self.mode = mode
        self.rho = float(rho)
        self.phys_copies = int(phys_copies)
        self._enc_cfg = EncoderConfig(view_radius=view_radius)
        if mode == 'none':
            self._store = None
            self._encoders: dict[str, SensoryEncoder28] = {}
        elif mode == 'v0':
            self._store = ArtLifetimeStore(lambda: ArtPerceiver(28, rho=self.rho))
            self._encoders = {}
        else:
            dim = 28 + 3 * max(0, self.phys_copies - 1)
            self._store = ArtLifetimeStore(lambda: ArtPerceiver(dim, rho=self.rho))
            self._encoders = {}

    @property
    def feature_dim(self) -> int:
        if self.mode == 'none':
            return 0
        if self.mode == 'v0':
            return 6 + 28
        return 6 + 28 + 3 * max(0, self.phys_copies - 1)

    def sync(self, alive_keys) -> list[str]:
        if self._store is None:
            return []
        alive = set(alive_keys)
        gone = self._store.sync(alive)
        for k in gone:
            self._encoders.pop(k, None)
        return gone

    def observe(self, key: str, obs: dict[str, Any]) -> tuple[np.ndarray, Percept | None]:
        if self._store is None:
            return np.zeros(0, dtype=np.float32), None
        if key not in self._encoders:
            self._encoders[key] = SensoryEncoder28(self._enc_cfg)
        v28 = self._encoders[key].encode(obs)
        x = v28 if self.mode == 'v0' else _replicate_phys_vec(v28, self.phys_copies)
        percept = self._store.get(key).observe(x)
        return percept.features.astype(np.float32), percept

    def learn(self, key: str, percept: Percept | None) -> ExperienceRef | None:
        if self._store is None or percept is None:
            return None
        return self._store.get(key).learn(percept)

    def credit(self, key: str, ref: ExperienceRef | None, reward: float) -> bool:
        if self._store is None or ref is None:
            return False
        if key not in self._store.keys():
            return False
        return self._store.get(key).credit(ref, reward)


@dataclass
class TransitionRecord:
    agent_id: str
    raw_obs: np.ndarray
    art_features: np.ndarray   # stored AT COLLECTION TIME, never recomputed
    action: int
    log_prob: float
    value: float
    reward: float
    done: bool
    h_in: np.ndarray


class RolloutBuffer:
    """Stores collection-time transitions and computes per-agent GAE respecting done."""

    def __init__(self):
        self.records: list[TransitionRecord] = []

    def add(self, rec: TransitionRecord) -> None:
        self.records.append(rec)

    def clear(self) -> None:
        self.records.clear()

    def __len__(self) -> int:
        return len(self.records)

    def compute_gae(
        self,
        last_values: dict[str, float],
        *,
        gamma: float = 0.99,
        lam: float = 0.95,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Compute advantages and returns per agent trajectory without leaking across deaths."""
        n = len(self.records)
        advantages = np.zeros(n, dtype=np.float32)
        returns = np.zeros(n, dtype=np.float32)

        by_agent: dict[str, list[int]] = {}
        for i, rec in enumerate(self.records):
            by_agent.setdefault(rec.agent_id, []).append(i)

        for aid, idxs in by_agent.items():
            gae = 0.0
            next_val = float(last_values.get(aid, 0.0))
            for pos in range(len(idxs) - 1, -1, -1):
                i = idxs[pos]
                rec = self.records[i]
                nonterminal = 0.0 if rec.done else 1.0
                delta = rec.reward + gamma * next_val * nonterminal - rec.value
                gae = delta + gamma * lam * nonterminal * gae
                advantages[i] = gae
                returns[i] = gae + rec.value
                next_val = rec.value

        return advantages, returns


class ArtRolloutPolicy:
    """CycleEngine-compatible Policy wrapping ArtAdapter + optional action function."""

    def __init__(
        self,
        art: ArtAdapter,
        act_fn: Callable[[np.ndarray, np.ndarray, np.ndarray | None], tuple[int, np.ndarray | None]],
    ):
        self.art = art
        self.act_fn = act_fn
        self.last_percepts: dict[str, Percept | None] = {}
        self.last_art_features: dict[str, np.ndarray] = {}

    def act(self, observations: dict[str, Any], memories: dict[str, Any], lineage_ids: dict[str, int]):
        self.art.sync(observations.keys())
        actions: dict[str, int] = {}
        next_memories: dict[str, Any] = {}
        self.last_percepts.clear()
        self.last_art_features.clear()

        for k in sorted(observations, key=int):
            obs = observations[k]
            art_feat, percept = self.art.observe(k, obs)
            self.last_percepts[k] = percept
            self.last_art_features[k] = art_feat
            h_in = memories.get(k)
            act_idx, h_out = self.act_fn(obs['raw_obs'], art_feat, h_in)
            actions[k] = int(act_idx)
            if h_out is not None:
                next_memories[k] = h_out
        return actions, next_memories


if HAS_TORCH:
    class GruActorCritic(nn.Module):
        def __init__(self, raw_dim: int, art_dim: int, hidden_dim: int = 64, num_actions: int = NUM_ACTIONS):
            super().__init__()
            self.raw_dim = raw_dim
            self.art_dim = art_dim
            self.hidden_dim = hidden_dim
            in_dim = raw_dim + art_dim
            self.encoder = nn.Sequential(
                nn.Linear(in_dim, hidden_dim),
                nn.Tanh(),
            )
            self.gru = nn.GRUCell(hidden_dim, hidden_dim)
            self.actor = nn.Linear(hidden_dim, num_actions)
            self.critic = nn.Linear(hidden_dim, 1)

        def forward_step(self, x: torch.Tensor, h: torch.Tensor):
            z = self.encoder(x)
            h_next = self.gru(z, h)
            logits = self.actor(h_next)
            value = self.critic(h_next).squeeze(-1)
            return logits, value, h_next


    class PPOGruTrainer:
        """Trains GruActorCritic with collection-time stored ART features."""

        def __init__(
            self,
            model: GruActorCritic,
            *,
            lr: float = 3e-4,
            gamma: float = 0.99,
            lam: float = 0.95,
            clip_eps: float = 0.2,
            vf_coef: float = 0.5,
            ent_coef: float = 0.01,
            epochs: int = 4,
            batch_size: int = 128,
            device: str = 'cpu',
        ):
            self.model = model.to(device)
            self.device = device
            self.opt = torch.optim.Adam(self.model.parameters(), lr=lr)
            self.gamma = gamma
            self.lam = lam
            self.clip_eps = clip_eps
            self.vf_coef = vf_coef
            self.ent_coef = ent_coef
            self.epochs = epochs
            self.batch_size = batch_size

        @torch.no_grad()
        def select_action(self, raw_obs: np.ndarray, art_feat: np.ndarray, h_in: np.ndarray | None):
            if h_in is None:
                h_t = torch.zeros(1, self.model.hidden_dim, device=self.device)
            else:
                h_t = torch.as_tensor(h_in, dtype=torch.float32, device=self.device).unsqueeze(0)
            x_np = np.concatenate([raw_obs, art_feat], axis=0) if art_feat.size else raw_obs
            x_t = torch.as_tensor(x_np, dtype=torch.float32, device=self.device).unsqueeze(0)
            logits, value, h_next = self.model.forward_step(x_t, h_t)
            dist = Categorical(logits=logits)
            act = dist.sample()
            return (
                int(act.item()),
                float(dist.log_prob(act).item()),
                float(value.item()),
                h_t.squeeze(0).cpu().numpy(),
                h_next.squeeze(0).cpu().numpy(),
            )

        @torch.no_grad()
        def estimate_value(self, raw_obs: np.ndarray, art_feat: np.ndarray, h_in: np.ndarray | None) -> float:
            if h_in is None:
                h_t = torch.zeros(1, self.model.hidden_dim, device=self.device)
            else:
                h_t = torch.as_tensor(h_in, dtype=torch.float32, device=self.device).unsqueeze(0)
            x_np = np.concatenate([raw_obs, art_feat], axis=0) if art_feat.size else raw_obs
            x_t = torch.as_tensor(x_np, dtype=torch.float32, device=self.device).unsqueeze(0)
            _, value, _ = self.model.forward_step(x_t, h_t)
            return float(value.item())

        def update(self, buffer: RolloutBuffer, last_values: dict[str, float]) -> dict[str, float]:
            advantages, returns = buffer.compute_gae(last_values, gamma=self.gamma, lam=self.lam)
            if len(advantages) > 1:
                advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

            # Use STORED art_features from collection time — never recompute from ART.
            xs = []
            for r in buffer.records:
                xs.append(np.concatenate([r.raw_obs, r.art_features], axis=0) if r.art_features.size else r.raw_obs)
            x_t = torch.as_tensor(np.asarray(xs, dtype=np.float32), device=self.device)
            h_t = torch.as_tensor(np.asarray([r.h_in for r in buffer.records], dtype=np.float32), device=self.device)
            act_t = torch.as_tensor([r.action for r in buffer.records], dtype=torch.long, device=self.device)
            old_lp_t = torch.as_tensor([r.log_prob for r in buffer.records], dtype=torch.float32, device=self.device)
            adv_t = torch.as_tensor(advantages, dtype=torch.float32, device=self.device)
            ret_t = torch.as_tensor(returns, dtype=torch.float32, device=self.device)

            n = len(buffer)
            total_loss = 0.0
            n_updates = 0
            for _ in range(self.epochs):
                perm = torch.randperm(n, device=self.device)
                for start in range(0, n, self.batch_size):
                    idx = perm[start:start + self.batch_size]
                    logits, values, _ = self.model.forward_step(x_t[idx], h_t[idx])
                    dist = Categorical(logits=logits)
                    new_lp = dist.log_prob(act_t[idx])
                    entropy = dist.entropy().mean()

                    ratio = torch.exp(new_lp - old_lp_t[idx])
                    s1 = ratio * adv_t[idx]
                    s2 = torch.clamp(ratio, 1.0 - self.clip_eps, 1.0 + self.clip_eps) * adv_t[idx]
                    pi_loss = -torch.min(s1, s2).mean()
                    vf_loss = 0.5 * ((values - ret_t[idx]) ** 2).mean()
                    loss = pi_loss + self.vf_coef * vf_loss - self.ent_coef * entropy

                    self.opt.zero_grad()
                    loss.backward()
                    nn.utils.clip_grad_norm_(self.model.parameters(), 0.5)
                    self.opt.step()
                    total_loss += float(loss.item())
                    n_updates += 1

            return {'loss': total_loss / max(1, n_updates)}
