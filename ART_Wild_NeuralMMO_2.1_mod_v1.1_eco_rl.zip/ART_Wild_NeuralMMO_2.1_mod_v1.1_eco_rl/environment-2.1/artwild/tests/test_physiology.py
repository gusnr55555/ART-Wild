"""Dependency-free physiology tests."""
import unittest
from types import SimpleNamespace
from artwild.physiology import Physiology, apply_lifecycle, incoming_damage, outgoing_melee_bonus, metabolic_cost, senescence_cost

class FakeGenome:
    def __init__(self, **values):
        self.values = dict(STR=10, CON=10, MAT=15, growth_rate=1, energy_cost=1, aging_rate=1)
        self.values.update(values)
    def phenotype(self, age): return self.values.copy()

class Resource:
    def __init__(self, amount): self.val = amount
    def decrement(self, n): self.val = max(0, self.val-n)

class FakePlayer:
    def __init__(self, genome, age=20, tpy=100, resources=True):
        self.artwild_physiology=Physiology(genome,-age*tpy,tpy)
        self.resources=SimpleNamespace(food=Resource(1000), health=Resource(1000))
        self.config=SimpleNamespace(RESOURCE_SYSTEM_ENABLED=resources)
        self.immortal=False
        self.damage_events=[]
    @property
    def alive(self): return self.resources.health.val > 0
    def receive_damage(self, source, damage):
        self.resources.health.decrement(damage)
        self.damage_events.append(damage)

class TestPhysiology(unittest.TestCase):
    def test_str_melee_damage(self):
        strong=Physiology(FakeGenome(STR=14),-2000,100)
        weak=Physiology(FakeGenome(STR=6),-2000,100)
        self.assertGreater(outgoing_melee_bonus(strong,0),outgoing_melee_bonus(weak,0))
        self.assertEqual(outgoing_melee_bonus(None,0),0)
    def test_con_damage(self):
        strong=Physiology(FakeGenome(CON=14),-2000,100)
        weak=Physiology(FakeGenome(CON=6),-2000,100)
        self.assertLess(incoming_damage(strong,0,20),incoming_damage(weak,0,20))
    def test_metabolism_fractional_accumulates(self):
        player=FakePlayer(FakeGenome(energy_cost=1.25))
        for _ in range(20): apply_lifecycle(player,0)
        self.assertEqual(player.resources.food.val,998)
    def test_no_effect_on_vanilla_player(self):
        player=FakePlayer(FakeGenome())
        del player.artwild_physiology
        apply_lifecycle(player,0)
        self.assertEqual(player.resources.food.val,1000)
    def test_old_age_causes_damage(self):
        player=FakePlayer(FakeGenome(aging_rate=1.3),age=90)
        for _ in range(20): apply_lifecycle(player,0)
        self.assertLess(player.resources.health.val,1000)
    def test_young_has_no_senescence(self):
        profile=Physiology(FakeGenome(),-2000,100)
        self.assertEqual(senescence_cost(profile,0),0)
    def test_metabolism_responds_to_disease(self):
        low=Physiology(FakeGenome(energy_cost=1),-2000,100)
        high=Physiology(FakeGenome(energy_cost=1.5),-2000,100)
        self.assertGreater(metabolic_cost(high,0),metabolic_cost(low,0))
    def test_immortal_no_cost(self):
        p=FakePlayer(FakeGenome(),age=90)
        p.immortal=True
        apply_lifecycle(p,0)
        self.assertEqual(p.resources.food.val,1000)
        self.assertEqual(p.resources.health.val,1000)
    def test_when_resource_system_disabled(self):
        p=FakePlayer(FakeGenome(),resources=False)
        for _ in range(50): apply_lifecycle(p,0)
        self.assertEqual(p.resources.food.val,1000)
    def test_high_con_damage_bound(self):
        p=Physiology(FakeGenome(CON=18),-2000,100)
        self.assertGreaterEqual(incoming_damage(p,0,1),1)

if __name__ == '__main__': unittest.main()
