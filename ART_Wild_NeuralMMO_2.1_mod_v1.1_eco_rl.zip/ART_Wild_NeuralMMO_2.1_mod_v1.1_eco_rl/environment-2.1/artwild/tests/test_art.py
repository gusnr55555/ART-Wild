"""Paper-property regression tests for artwild.art.

All of these RUN against real code (numpy only, no mocks). They check
properties stated in Carpenter & Grossberg (1987), Carpenter, Grossberg &
Rosen (1991) and Carpenter et al. (1992) at the algorithmic level; none of them
demonstrates that ART helps agents in the ART-Wild world.
"""
import unittest
import numpy as np
from artwild.art import (FuzzyART, ART1, FuzzyARTMAP, ArtLifetimeStore,
                         ArtPerceiver, complement_code)
from artwild.cycle import CycleEngine, CycleConfig
from artwild.toy_world import ToyWorld, SilenceAndForage


def rng(seed=0):
    return np.random.default_rng(seed)


class FuzzyARTTests(unittest.TestCase):
    def test_complement_coding_has_constant_norm(self):
        for a in rng().random((50, 5)):
            I = complement_code(a)
            self.assertEqual(I.shape, (10,))
            self.assertAlmostEqual(I.sum(), 5.0, places=12)
        with self.assertRaises(ValueError):
            complement_code([0.2, 1.2])

    def test_first_input_commits_node_equal_to_input(self):
        f = FuzzyART(2, rho=0.8)
        r = f.present([0.2, 0.7])
        self.assertTrue(r.committed_new and r.category == 0 and f.n == 1)
        np.testing.assert_allclose(f.weights[0], complement_code([0.2, 0.7]))

    def test_weights_never_increase(self):
        for beta in (1.0, 0.4):
            f = FuzzyART(3, rho=0.7, beta=beta)
            seen = {}
            for x in rng(1).random((300, 3)):
                f.present(x)
                for j in range(f.n):
                    if j in seen:
                        self.assertTrue(np.all(f.weights[j] <= seen[j] + 1e-15))
                    seen[j] = f.weights[j].copy()

    def test_fast_learning_box_is_min_max_of_members(self):
        f = FuzzyART(2, rho=0.6)
        members = {}
        for x in rng(2).random((200, 2)):
            r = f.present(x)
            members.setdefault(r.category, []).append(x)
        for j, xs in members.items():
            xs = np.array(xs)
            u, v = f.box(j)
            np.testing.assert_allclose(u, xs.min(axis=0), atol=1e-12)
            np.testing.assert_allclose(v, xs.max(axis=0), atol=1e-12)

    def test_vigilance_bounds_box_size(self):
        for rho in (0.3, 0.6, 0.9):
            f = FuzzyART(4, rho=rho)
            for x in rng(3).random((300, 4)):
                f.present(x)
            for j in range(f.n):
                u, v = f.box(j)
                self.assertLessEqual((v - u).sum(), 4 * (1 - rho) + 1e-9)

    def test_rho_one_separates_distinct_and_merges_identical(self):
        f = FuzzyART(2, rho=1.0)
        a = f.present([0.1, 0.1]).category
        b = f.present([0.9, 0.9]).category
        a2 = f.present([0.1, 0.1]).category
        self.assertNotEqual(a, b)
        self.assertEqual(a, a2)
        self.assertEqual(f.n, 2)

    def test_learning_stabilises_in_finite_epochs_and_gives_direct_access(self):
        X = rng(4).random((150, 3))
        f = FuzzyART(3, rho=0.75)
        for epoch in range(1, 40):
            before = f.weights.copy(), f.n
            for x in X:
                f.present(x)
            if f.n == before[1] and np.array_equal(f.weights, before[0]):
                break
        else:
            self.fail('learning did not stabilise within 39 epochs')
        # After stabilisation each training input is accepted with no reset.
        for x in X:
            r = f.classify(x)
            self.assertTrue(r.resonated)
            self.assertEqual(r.resets, 0)

    def test_classify_does_not_change_network_and_flags_novelty(self):
        f = FuzzyART(2, rho=0.9)
        f.present([0.1, 0.1])
        snap = f.to_dict()
        r = f.classify([0.9, 0.9])
        self.assertEqual((r.category, r.reason), (None, 'novel'))
        self.assertEqual(f.to_dict(), snap)

    def test_capacity_exhaustion_is_explicit_and_non_destructive(self):
        f = FuzzyART(2, rho=1.0, max_categories=2)
        f.present([0.1, 0.1]); f.present([0.9, 0.9])
        snap = f.to_dict()
        r = f.present([0.5, 0.5])
        self.assertEqual((r.category, r.reason), (None, 'capacity_exhausted'))
        self.assertEqual(f.to_dict(), snap)

    def test_ties_go_to_lowest_index(self):
        f = FuzzyART.from_dict({'kind': 'fuzzy_art', 'input_dim': 1, 'alpha': 1e-3, 'beta': 1.0,
                                'rho': 0.0, 'complement_coding': True, 'fast_commit': True,
                                'max_categories': None,
                                'weights': [[0.5, 0.5], [0.5, 0.5]]})
        self.assertEqual(f.classify([0.5]).category, 0)

    def test_slow_recode_after_fast_commit(self):
        f = FuzzyART(1, rho=0.0, beta=0.5)
        f.present([0.8])
        np.testing.assert_allclose(f.weights[0], [0.8, 0.2])     # fast commit
        f.present([0.4])                                          # slow recode
        np.testing.assert_allclose(f.weights[0], 0.5 * np.array([0.4, 0.2]) + 0.5 * np.array([0.8, 0.2]))

    def test_roundtrip_serialisation_preserves_behaviour(self):
        f = FuzzyART(3, rho=0.7, beta=0.6)
        X = rng(5).random((100, 3))
        for x in X[:60]:
            f.present(x)
        g = FuzzyART.from_dict(f.to_dict())
        for x in X[60:]:
            self.assertEqual(f.present(x), g.present(x))
        np.testing.assert_array_equal(f.weights, g.weights)

    def test_invalid_parameters_and_inputs(self):
        for kw in ({'alpha': 0}, {'beta': 0}, {'beta': 1.5}, {'rho': 1.1}, {'rho': -0.1},
                   {'max_categories': 0}):
            with self.assertRaises(ValueError):
                FuzzyART(2, **kw)
        with self.assertRaises(ValueError):
            FuzzyART(2).present([0.1])
        with self.assertRaises(ValueError):
            FuzzyART(2).present([0.1, float('nan')])


class ART1Tests(unittest.TestCase):
    @staticmethod
    def binary(seed, n, m):
        X = rng(seed).integers(0, 2, (n, m))
        return X[X.sum(axis=1) > 0]

    def test_templates_only_shrink_and_are_subsets_of_their_members(self):
        net = ART1(8, rho=0.6)
        members = {}
        prev = {}
        for x in self.binary(6, 300, 8):
            r = net.present(x)
            members.setdefault(r.category, []).append(x)
            j = r.category
            if j in prev:
                self.assertTrue(np.all(net.weights[j] <= prev[j]))
            prev[j] = net.weights[j].copy()
        for j, xs in members.items():
            np.testing.assert_array_equal(net.weights[j], np.min(xs, axis=0))

    def test_subset_template_with_larger_support_is_tried_first(self):
        # [CG87] direct access: among templates that are subsets of I, the most
        # specific (largest) wins the choice competition.
        net = ART1.from_dict({'kind': 'art1', 'input_dim': 6, 'L': 2.0, 'rho': 0.5,
                              'max_categories': None,
                              'weights': [[1, 1, 0, 0, 0, 0], [1, 1, 1, 0, 0, 0]]})
        r = net.classify([1, 1, 1, 1, 0, 0])
        self.assertEqual(r.category, 1)
        self.assertEqual(r.resets, 0)

    def test_exact_exemplar_beats_uncommitted_node(self):
        net = ART1(5, rho=1.0)
        net.present([1, 1, 0, 0, 0])
        r = net.classify([1, 1, 0, 0, 0])
        self.assertEqual((r.category, r.resets), (0, 0))

    def test_uncommitted_bottom_up_weight_satisfies_paper_bound(self):
        net = ART1(7, L=3.0)
        self.assertLess(net.z0, 3.0 / (3.0 - 1 + 7))

    def test_same_choice_order_as_fuzzy_art_with_alpha_L_minus_1(self):
        # Independent implementations (z/w templates vs. Weber law) must agree.
        for L, rho in ((2.0, 0.6), (1.5, 0.8), (3.0, 0.3)):
            a = ART1(7, L=L, rho=rho)
            f = FuzzyART(7, alpha=L - 1, beta=1.0, rho=rho, complement_coding=False)
            for x in self.binary(7, 400, 7):
                ra, rf = a.present(x), f.present(x.astype(float))
                self.assertEqual((ra.category, ra.committed_new), (rf.category, rf.committed_new))
            np.testing.assert_array_equal(a.weights, f.weights.astype(int))

    def test_input_validation(self):
        net = ART1(4)
        for bad in ([0, 0, 0, 0], [0, 1, 2, 0], [1, 0, 1]):
            with self.assertRaises(ValueError):
                net.present(bad)
        with self.assertRaises(ValueError):
            ART1(4, L=1.0)

    def test_roundtrip_serialisation(self):
        net = ART1(6, rho=0.5)
        for x in self.binary(8, 80, 6):
            net.present(x)
        other = ART1.from_dict(net.to_dict())
        np.testing.assert_array_equal(net.weights, other.weights)
        np.testing.assert_allclose(net._z[:net.n], other._z[:other.n])


def one_hot(k, n=2):
    return np.eye(n)[k]


class ARTMAPTests(unittest.TestCase):
    def test_learns_consistent_training_set_exactly(self):
        X = rng(9).random((300, 2))
        y = (X[:, 0] + X[:, 1] > 1).astype(int)
        net = FuzzyARTMAP(2, 2, rho_a=0.0)
        for _ in range(3):
            for x, k in zip(X, y):
                net.train(x, one_hot(k))
        pred = [net.predict(x).category_b for x in X]
        self.assertTrue(all(p is not None for p in pred))
        labels = [int(np.argmax(net.art_b.center(p))) for p in pred]
        self.assertEqual(labels, list(y))

    def test_match_tracking_splits_conflicting_neighbours(self):
        net = FuzzyARTMAP(1, 2, rho_a=0.0)
        net.train([0.40], one_hot(0))
        r = net.train([0.45], one_hot(1))      # would be absorbed by category 0 without match tracking
        self.assertEqual(r.reason, 'resonance')
        self.assertTrue(r.committed_new)
        self.assertGreaterEqual(r.match_tracking_resets, 1)
        self.assertEqual(net.art_a.n, 2)
        self.assertEqual(net.map[0] != net.map[1], True)

    def test_vigilance_after_match_tracking_exceeds_failed_match(self):
        net = FuzzyARTMAP(1, 2, rho_a=0.0, epsilon=1e-3)
        net.train([0.40], one_hot(0))
        res = net.art_a.present([0.45], learn=False, rho=0.0,
                                veto=lambda j: True, epsilon=1e-3)
        match0 = float(np.minimum(complement_code([0.45]), net.art_a.weights[0]).sum() / 1.0)
        self.assertGreater(res.rho_final, match0 - 1e-9)

    def test_identical_input_with_conflicting_targets_is_reported_not_corrupting(self):
        net = FuzzyARTMAP(1, 2)
        net.train([0.3], one_hot(0))
        snap_a, snap_map = net.art_a.to_dict(), list(net.map)
        r = net.train([0.3], one_hot(1))
        self.assertEqual(r.reason, 'a_search_exhausted')
        self.assertEqual(net.art_a.to_dict(), snap_a)
        self.assertEqual(net.map, snap_map)

    def test_prediction_reports_novelty_instead_of_guessing(self):
        net = FuzzyARTMAP(1, 2, rho_a=0.9)
        net.train([0.1], one_hot(0))
        self.assertEqual(net.predict([0.9]).reason, 'novel')
        self.assertIsNone(net.predict_vector([0.9]))

    def test_predict_never_changes_state(self):
        net = FuzzyARTMAP(2, 2, rho_a=0.5)
        for x in rng(10).random((50, 2)):
            net.train(x, one_hot(int(x[0] > 0.5)))
        snap = net.to_dict()
        for x in rng(11).random((50, 2)):
            net.predict(x)
        self.assertEqual(net.to_dict(), snap)

    def test_roundtrip_serialisation(self):
        net = FuzzyARTMAP(2, 2, rho_a=0.4)
        X = rng(12).random((80, 2))
        for x in X:
            net.train(x, one_hot(int(x[1] > 0.5)))
        other = FuzzyARTMAP.from_dict(net.to_dict())
        for x in X:
            self.assertEqual(net.predict(x), other.predict(x))


class LifetimeIsolationTests(unittest.TestCase):
    def test_store_gives_fresh_networks_and_forbids_key_reuse(self):
        store = ArtLifetimeStore(lambda: FuzzyART(2))
        a = store.get('1:1')
        a.present([0.1, 0.2])
        self.assertIs(store.get('1:1'), a)
        self.assertEqual(store.get('1:2').n, 0)
        store.retire('1:1')
        with self.assertRaises(KeyError):
            store.get('1:1')
        self.assertEqual(store.sync(['1:2']), [])
        self.assertEqual(store.sync([]), ['1:2'])
        self.assertEqual(len(store), 0)

    def test_no_memory_crosses_lifetimes_inside_cycle_engine(self):
        store = ArtLifetimeStore(lambda: FuzzyART(2, rho=0.8))
        world = ToyWorld(founders=8, max_age=24)
        fresh_on_first_sight, nets = {}, {}

        class ArtObservingPolicy(SilenceAndForage):
            def act(self, observations, memories, lineage_ids):
                store.sync(observations)
                for k, obs in observations.items():
                    net = store.get(k)
                    if k not in fresh_on_first_sight:
                        fresh_on_first_sight[k] = net.n
                        nets[k] = net
                    net.present([min(obs['age'] / 40, 1.0), min(obs['food'] / 2000, 1.0)])
                return super().act(observations, memories, lineage_ids)

        result = CycleEngine(world, ArtObservingPolicy()).run(
            1, 7, (0, 1), CycleConfig(max_ticks=40, training=False))
        self.assertGreater(result.births, 0)
        self.assertGreater(len(fresh_on_first_sight), result.founder_count)
        self.assertEqual(set(fresh_on_first_sight.values()), {0})        # every lifetime started empty
        self.assertEqual(len({id(n) for n in nets.values()}), len(nets))  # no shared network object
        alive = {str(a.id) for a in world.population.living()}
        store.sync(alive)
        self.assertEqual(set(store.keys()), alive & set(nets))           # the dead hold no state


class ArtPerceiverTests(unittest.TestCase):
    @staticmethod
    def step(p, x, reward=None):
        pc = p.observe(x)
        ref = p.learn(pc)
        if reward is not None:
            p.credit(ref, reward)
        return pc, ref

    def test_fixed_dimension_and_bounded_features(self):
        p = ArtPerceiver(3, rho=0.8)
        g = rng(21)
        for x in rng(20).random((200, 3)):
            pc, _ = self.step(p, x, float(g.normal() * 5))
            self.assertEqual(pc.features.shape, (p.feature_dim,))
            self.assertEqual(p.feature_dim, 6 + 3)
            self.assertTrue(np.all(pc.features >= -1.0) and np.all(pc.features <= 1.0))

    def test_novel_then_familiar_and_visit_count_grows(self):
        p = ArtPerceiver(2, rho=0.9)
        a, _ = self.step(p, [0.2, 0.2])
        b, _ = self.step(p, [0.2, 0.2])
        self.assertEqual((a.features[1], b.features[1]), (1.0, 0.0))
        self.assertAlmostEqual(b.features[0], 1.0)
        self.assertAlmostEqual(b.features[3], 1 / 11)     # one earlier visit, not counting this one
        np.testing.assert_allclose(b.features[6:], [0.2, 0.2])

    def test_features_are_computed_before_learning_the_current_input(self):
        p = ArtPerceiver(1, rho=0.0)
        self.step(p, [0.2])
        pc, _ = self.step(p, [0.3])               # absorbed into the same category
        self.assertAlmostEqual(pc.features[6], 0.2)   # centre BEFORE learning 0.3
        self.assertAlmostEqual(p.observe([0.3]).features[6], 0.25)   # centre after

    def test_observe_does_not_change_art_state(self):
        p = ArtPerceiver(2, rho=0.8)
        for x in rng(23).random((20, 2)):
            self.step(p, x, 0.1)
        snap = p.to_dict()
        for x in rng(24).random((20, 2)):
            p.observe(x)
        self.assertEqual(p.to_dict(), snap)

    def test_learn_requires_its_own_fresh_percept(self):
        p = ArtPerceiver(1)
        first = p.observe([0.1])
        p.observe([0.9])
        with self.assertRaises(ValueError):
            p.learn(first)
        pc = p.observe([0.5])
        p.learn(pc)
        with self.assertRaises(ValueError):
            p.learn(pc)

    def test_reward_goes_to_the_stored_category_not_the_latest(self):
        p = ArtPerceiver(1, rho=0.95)
        _, ref_a = self.step(p, [0.1])
        _, ref_b = self.step(p, [0.9])            # "latest" is now b's category
        self.assertTrue(p.credit(ref_a, 1.0))
        self.assertTrue(p.credit(ref_b, -1.0))
        self.assertAlmostEqual(p.observe([0.1]).features[4], 1.0)
        self.assertAlmostEqual(p.observe([0.9]).features[4], -1.0)

    def test_unrewarded_visits_do_not_dilute_the_mean(self):
        p = ArtPerceiver(1, rho=0.95)
        _, ref = self.step(p, [0.1])
        p.credit(ref, 1.0)
        self.step(p, [0.1])                       # visited again, no reward yet
        self.assertAlmostEqual(p.observe([0.1]).features[4], 1.0)

    def test_saturation_flag_instead_of_overwriting(self):
        p = ArtPerceiver(1, rho=1.0, max_categories=1)
        self.step(p, [0.1])
        snap = p.to_dict()
        pc = p.observe([0.9])
        self.assertEqual((pc.features[1], pc.features[5]), (1.0, 1.0))
        ref = p.learn(pc)
        self.assertIsNone(ref.category)
        self.assertFalse(p.credit(ref, 1.0))
        self.assertEqual(p.to_dict(), snap)

    def test_roundtrip_and_lifetime_isolation(self):
        store = ArtLifetimeStore(lambda: ArtPerceiver(2, rho=0.8))
        a = store.get('1:1')
        for x in rng(22).random((30, 2)):
            self.step(a, x, 0.5)
        b = ArtPerceiver.from_dict(a.to_dict())
        x = [0.3, 0.6]
        np.testing.assert_array_equal(a.observe(x).features, b.observe(x).features)
        self.assertEqual(store.get('1:2').art.n, 0)
        self.assertEqual(store.get('1:2').visits, [])


if __name__ == '__main__':
    unittest.main()
