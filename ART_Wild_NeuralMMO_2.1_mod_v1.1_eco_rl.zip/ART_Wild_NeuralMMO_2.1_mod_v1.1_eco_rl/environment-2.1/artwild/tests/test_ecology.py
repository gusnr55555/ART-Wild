"""Tests for basic ecosystem and EcoSurvivalWorld (EcologyEngine v1.0) integration."""
import unittest
import numpy as np
from artwild.art.encoder import MAT_GRASS
from artwild.cycle import CycleConfig, CycleEngine
from artwild.ecology import EcoConfig, EcoSurvivalWorld, Ecosystem, EcologyEngine, SpeciesRegistry
from artwild.rl import ArtAdapter, ArtRolloutPolicy


class EcosystemTests(unittest.TestCase):
    def test_plants_grow_and_spread(self):
        grid = np.full((9, 9), MAT_GRASS, dtype=int)
        eco = Ecosystem(grid, seed=1)
        placed = eco.seed_plants('forage_grass', 4, initial_biomass=0.5)
        self.assertEqual(placed, 4)
        initial_biomass = float(np.sum(eco.biomass))
        for _ in range(30):
            eco.step()
        self.assertGreater(float(np.sum(eco.biomass)), initial_biomass)
        self.assertGreater(eco.stats.plant_spreads, 0)
        self.assertGreater(eco.stats.plant_tiles, 4)

    def test_herbivores_forage_plants_and_reproduce(self):
        grid = np.full((9, 9), MAT_GRASS, dtype=int)
        eco = Ecosystem(grid, seed=2)
        eco.seed_plants('berry_bush', 20, initial_biomass=1.2)
        eco.spawn_animal('rabbit', r=4, c=4, energy=60.0)
        eco.spawn_animal('rabbit', r=4, c=5, energy=60.0)
        for _ in range(40):
            eco.step()
        self.assertGreater(eco.stats.animal_births, 0)
        self.assertGreaterEqual(eco.stats.herbivores, 2)

    def test_carnivore_predation_and_starvation_without_prey(self):
        grid = np.full((7, 7), MAT_GRASS, dtype=int)
        eco = Ecosystem(grid, seed=3)
        eco.spawn_animal('rabbit', r=3, c=3, energy=50.0)
        eco.spawn_animal('wolf', r=3, c=3, energy=50.0)
        eco.step()
        self.assertGreaterEqual(eco.stats.predations, 1)
        self.assertEqual(eco.stats.herbivores, 0)

        for _ in range(80):
            eco.step()
        self.assertEqual(eco.stats.carnivores, 0)


class EcoSurvivalWorldTests(unittest.TestCase):
    def test_eco_world_uses_ecology_engine_and_hides_physiological_traits(self):
        cfg = EcoConfig(grid_size=16, chunk_size=8, n_agents=4, max_ticks_per_life=35)
        world = EcoSurvivalWorld(cfg)
        obs = world.reset(10, (0,))
        self.assertIsInstance(world.eco, EcologyEngine)
        # Public observation keys only — no hidden plant/animal physiological traits
        expected_keys = {'health', 'food', 'water', 'age', 'tile_materials', 'entities', 'inventory_count', 'raw_obs'}
        for o in obs.values():
            self.assertEqual(set(o.keys()), expected_keys)
            self.assertEqual(o['raw_obs'].shape, (12,))

        for mode in ('none', 'v0', 'v3'):
            art = ArtAdapter(mode=mode, rho=0.90, view_radius=cfg.view_radius)
            seen_memories = []

            def act_fn(raw_obs, art_feat, h_in):
                seen_memories.append(h_in)
                next_h = np.ones(4, dtype=np.float32) if h_in is None else h_in + 1.0
                return int(abs(raw_obs[0]) * 10) % 5, next_h

            policy = ArtRolloutPolicy(art, act_fn)
            res = CycleEngine(EcoSurvivalWorld(cfg), policy).run(
                1, 10, (0,), CycleConfig(max_ticks=50, training=False)
            )
            self.assertEqual(res.ticks, 50)
            self.assertGreater(res.deaths, 0)
            self.assertGreater(sum(1 for h in seen_memories if h is None), cfg.n_agents)
            stats = res.world_snapshot['eco_stats']
            self.assertGreater(stats['plant_tiles'], 0)
            self.assertGreaterEqual(stats['active_chunks'], 1)

    def test_long_term_standalone_ecology_stability(self):
        """Run EcologyEngine standalone for 600 ticks across 3 seasonal cycles."""
        reg = SpeciesRegistry(seed=21)
        reg.populate(n_plants=6, n_animals=4)
        grid = np.full((24, 24), MAT_GRASS, dtype=int)
        eng = EcologyEngine(grid, reg, chunk_size=8, seed=21)

        pids = list(reg.plants.keys())
        for i in range(40):
            eng.plants.place_plant((i * 3) % 24, (i * 5) % 24, pids[i % len(pids)], mature=True)
        herb_ids = [sid for sid, sp in reg.animals.items() if sp.diet in ('herbivore', 'omnivore')]
        carn_ids = [sid for sid, sp in reg.animals.items() if sp.diet == 'carnivore']
        for i in range(10):
            eng.animals.spawn_active(herb_ids[i % len(herb_ids)], (i * 2) % 24, (i * 3) % 24, energy=65.0)
        for i in range(3):
            eng.animals.spawn_active(carn_ids[i % len(carn_ids)], (i * 7) % 24, (i * 5) % 24, energy=70.0)

        # Alternate active chunks periodically to exercise rehydrate/dehydrate over long runs
        for t in range(600):
            active = {(0, 0), (1, 1)} if (t // 50) % 2 == 0 else {(1, 0), (2, 2)}
            eng.step(active, agent_positions=None)

        total_yield = float(np.sum(eng.plants.yield_biomass))
        self.assertTrue(np.isfinite(total_yield))
        self.assertGreaterEqual(eng.animals.total_count(), 0)
        self.assertGreater(int(np.sum(eng.plants.species_id > 0)), 0)


if __name__ == '__main__':
    unittest.main()
