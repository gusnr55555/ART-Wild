"""Dependency-free contract tests for lifetime-keyed rollout adapter."""
import unittest
from artwild.lifetime import LifetimeDriver, lifetime_key

class FakeEnv:
    def __init__(self):
        self._aw_cycle = 0
        self.slot_to_bio_id = {}
        self._dead_this_tick = {}
        self.tick = 0
    def reset(self):
        self._aw_cycle += 1
        self.tick = 0
        self.slot_to_bio_id = {1: 101, 2: 102}
        return {1: {'state': 1}, 2: {'state': 2}}, {1: {}, 2: {}}
    def step(self, actions):
        self.tick += 1
        if self.tick == 1:
            self._dead_this_tick = {2: object()}
            # Slot 2 is immediately reused by newborn 103
            self.slot_to_bio_id[2] = 103
            return ({1: {'state': 1}, 2: {'newborn': True}},
                    {1: 2.0, 2: 0.0}, {1: False, 2: False},
                    {1: False, 2: False}, {1: {}, 2: {'artwild_newborn': True}})
        self._dead_this_tick = {}
        return ({1: {}, 2: {}}, {}, {1: False, 2: False},
                {1: False, 2: False}, {1: {}, 2: {}})

class TestLifetime(unittest.TestCase):
    def test_distinct_lifetime_keys_when_slot_reused(self):
        driver = LifetimeDriver(FakeEnv())
        obs, _ = driver.reset()
        self.assertEqual(set(obs), {'1:101', '1:102'})
        result = driver.step({'1:101': {'Move': {}}, '1:102': {}})
        self.assertIn('1:103', result.observations)
        self.assertNotIn('1:102', result.observations)
        self.assertTrue(result.terminated['1:102'])
        self.assertFalse(result.terminated['1:103'])
        self.assertEqual(set(driver.active_agents), {'1:101', '1:103'})
    def test_old_identity_cannot_act(self):
        d = LifetimeDriver(FakeEnv()); d.reset(); d.step({})
        with self.assertRaises(ValueError):
            d.step({'1:102': {}})
    def test_reset_makes_new_lifetime_namespace(self):
        d = LifetimeDriver(FakeEnv()); d.reset(); d.reset()
        self.assertEqual(set(d.active_agents), {'2:101', '2:102'})
    def test_no_step_before_reset(self):
        with self.assertRaises(RuntimeError):
            LifetimeDriver(FakeEnv()).step({})
    def test_bad_key(self):
        with self.assertRaises(ValueError):
            lifetime_key(0, 1)
