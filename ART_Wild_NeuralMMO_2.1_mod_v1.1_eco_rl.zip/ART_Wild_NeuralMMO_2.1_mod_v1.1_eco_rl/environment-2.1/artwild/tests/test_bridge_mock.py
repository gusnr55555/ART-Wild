"""Dependency-free bridge contract checks; NOT a real NMMO integration test."""
from dataclasses import replace
import importlib.util
import sys
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))


class FakeObs:
    def reset(self, *args):
        self.reset_called = True

    def to_gym(self):
        return {'ok': True}


class FakeTile:
    habitable = True
    occupied = False


class FakeMap:
    habitable_tiles = None
    def __init__(self):
        self.tiles = {(r, c): FakeTile() for r in range(20) for c in range(20)}


class FakePlayer:
    def __init__(self, pos):
        self.pos = pos


class FakePlayers:
    def __init__(self):
        self.entities = {1: FakePlayer((10, 10)), 2: FakePlayer((10, 12))}

    def __iter__(self):
        return iter(self.entities)

    def __getitem__(self, key):
        return self.entities[key]

    def spawn_artwild(self, slot, pos):
        obj = FakePlayer(pos)
        self.entities[slot] = obj
        return obj


class FakeEnv:
    def __init__(self, config, seed):
        self.config = config
        self.realm = types.SimpleNamespace(players=FakePlayers(), tick=0, map=FakeMap())
        self.possible_agents = [1, 2, 3]
        self._dummy_task_embedding = None
        self.obs = {x: FakeObs() for x in self.possible_agents}
        self._alive_agents = [1, 2]
        self._current_agents = [1, 2]
        self._dead_this_tick = {}
        self._np_random = types.SimpleNamespace(integers=lambda n: 0)

    def reset(self, *args, **kwargs):
        self.realm.players = FakePlayers()
        self.realm.tick = 0
        self._alive_agents = [1, 2]
        self._current_agents = [1, 2]
        return {1: {}, 2: {}}, {1: {}, 2: {}}

    def _compute_observations(self):
        pass

    def step(self, actions):
        self.realm.tick += 1
        dead = actions.get('kill_slot')
        self._dead_this_tick = {dead: object()} if dead else {}
        if dead:
            self.realm.players.entities.pop(dead)
        self._alive_agents = list(self.realm.players)
        self._current_agents = sorted(set(self._alive_agents) | set(self._dead_this_tick))
        return ({x: {} for x in self._current_agents}, {},
                {x: x == dead for x in self._current_agents},
                {x: False for x in self._current_agents},
                {x: {} for x in self._current_agents})


# Load the actual bridge while substituting only the upstream interface.
original_nmmo = sys.modules.get('nmmo')
sys.modules['nmmo'] = types.SimpleNamespace(Env=FakeEnv, config=types.SimpleNamespace(Default=object))
try:
    spec = importlib.util.spec_from_file_location('artwild_test_bridge', ROOT / 'artwild' / 'nmmo_env.py')
    bridge = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bridge)
finally:
    if original_nmmo is None:
        del sys.modules['nmmo']
    else:
        sys.modules['nmmo'] = original_nmmo


class TestBridge(unittest.TestCase):
    def make_env(self):
        config = types.SimpleNamespace(MAP_SIZE=20, HORIZON=30)
        env = bridge.ArtWildEnv(config=config, artwild_seed=8)
        env.reset()
        return env

    def test_founders_have_permanent_ids(self):
        env = self.make_env()
        self.assertEqual(len(env.population.living()), 2)
        self.assertEqual(env.slot_to_bio_id, {1: 1, 2: 2})
        observations = env._augment_observations({1: {}, 2: {}})
        self.assertEqual(observations[1]['ArtWildBody'].shape, (11,))
        self.assertEqual(float(observations[1]['ArtWildBody'][0]), 20.0)

    def test_death_then_newborn_reuses_slot_but_not_identity(self):
        env = self.make_env()
        env.request_birth(1, 2)
        env.step({'kill_slot': 2})
        # The queued reproduction is cancelled if a parent dies before birth.
        self.assertEqual(len(env.population.living()), 1)
        self.assertEqual(env._pending_births, [])
        env = self.make_env()
        # First kill an unrelated agent and then reproduce with the two parents.
        env.population.agents[env.slot_to_bio_id[1]].genome = replace(
            env.population.agents[env.slot_to_bio_id[1]].genome, sex='XX')
        env.population.agents[env.slot_to_bio_id[2]].genome = replace(
            env.population.agents[env.slot_to_bio_id[2]].genome, sex='XY')
        env.realm.players.entities[3] = FakePlayer((11, 11))
        individual = env.population.founder(0, 0)
        env._register(3, individual.id)
        env.step({'kill_slot': 3})
        env.request_birth(1, 2)
        ob, rewards, dones, trunc, info = env.step({})
        self.assertIn(3, ob)
        self.assertEqual(info[3]['artwild_bio_id'], 4)
        self.assertEqual(env.population.agents[4].parent_ids, (1, 2))
        self.assertTrue(env.population.agents[4].alive)
        self.assertIsNone(env.population.agents[4].memory)
        self.assertTrue(dones.get(3) is False)

    def test_mutual_mating_creates_newborn_after_slot_vacates(self):
        env = self.make_env()
        a, b = env.slot_to_bio_id[1], env.slot_to_bio_id[2]
        env.population.agents[a].genome = replace(env.population.agents[a].genome, sex='XX')
        env.population.agents[b].genome = replace(env.population.agents[b].genome, sex='XY')
        # Without a vacant slot, valid mutual requests are queued.
        obs, _, _, _, _ = env.step({1: {'ArtWildMate': {'target': 2}},
                                    2: {'ArtWildMate': {'target': 1}}})
        # Slot 3 is vacant from the start, so the offspring is born.
        self.assertIn(3, obs)
        c = env.slot_to_bio_id[3]
        self.assertEqual(env.population.agents[c].parent_ids, (a, b))
        self.assertEqual(env.population.age(c, env.realm.tick), 0)
        self.assertFalse(env.population.can_reproduce(a, b, env.realm.tick))

    def test_one_sided_mating_is_ignored(self):
        env = self.make_env()
        env.step({1: {'ArtWildMate': {'target': 2}}})
        self.assertEqual(len(env.population.agents), 2)

    def test_immature_pair_cannot_mate(self):
        env = self.make_env()
        a, b = env.slot_to_bio_id[1], env.slot_to_bio_id[2]
        env.population.agents[a].genome = replace(env.population.agents[a].genome, sex='XX')
        env.population.agents[b].genome = replace(env.population.agents[b].genome, sex='XY')
        env.population.agents[a].born_tick = 0
        env.step({1: {'ArtWildMate': {'target': 2}},
                  2: {'ArtWildMate': {'target': 1}}})
        self.assertEqual(len(env.population.agents), 2)

    def test_identical_sex_pair_cannot_mate(self):
        env = self.make_env()
        for slot in (1, 2):
            a = env.population.agents[env.slot_to_bio_id[slot]]
            a.genome = replace(a.genome, sex='XX')
        env.step({1: {'ArtWildMate': {'target': 2}},
                  2: {'ArtWildMate': {'target': 1}}})
        self.assertEqual(len(env.population.agents), 2)

    def test_mating_outside_radius_is_ignored(self):
        env = self.make_env()
        a, b = env.slot_to_bio_id[1], env.slot_to_bio_id[2]
        env.population.agents[a].genome = replace(env.population.agents[a].genome, sex='XX')
        env.population.agents[b].genome = replace(env.population.agents[b].genome, sex='XY')
        env.realm.players.entities[2].pos = (16,16)
        env.step({1: {'ArtWildMate': {'target': 2}},
                  2: {'ArtWildMate': {'target': 1}}})
        self.assertEqual(len(env.population.agents), 2)

    def test_no_mating_when_both_proposals_are_one_sided(self):
        env = self.make_env()
        env.step({1: {'ArtWildMate': {'target': 2}},
                  2: {'ArtWildMate': {'target': 0}}})
        self.assertEqual(len(env.population.agents), 2)

    def test_birth_information_has_body_and_identity(self):
        env = self.make_env()
        a, b = env.slot_to_bio_id[1], env.slot_to_bio_id[2]
        env.population.agents[a].genome = replace(env.population.agents[a].genome, sex='XX')
        env.population.agents[b].genome = replace(env.population.agents[b].genome, sex='XY')
        obs, _, _, _, info = env.step({1: {'ArtWildMate': {'target': 2}},
                                       2: {'ArtWildMate': {'target': 1}}})
        self.assertEqual(float(obs[3]['ArtWildBody'][0]), 0.)
        self.assertEqual(info[3]['artwild_bio_id'], 3)
        self.assertIn(info[3]['artwild_sex'], ('XX', 'XY'))

    def test_no_birth_after_horizon(self):
        env = self.make_env()
        env.config.HORIZON = 1
        env.request_birth(1, 2)
        env.step({})
        self.assertEqual(len(env.population.living()), 2)
        self.assertEqual(len(env._pending_births), 1)


if __name__ == '__main__':
    unittest.main()
