"""Tests for Ecology v1.0: SpeciesRegistry, fruit-tree regrowth, hybrid conservation, cultivation, and SIR disease."""
import unittest
import numpy as np
from artwild.art.encoder import MAT_GRASS
from artwild.ecology import (
    AnimalSpeciesV1,
    ClimateState,
    EcologyEngine,
    PlantSpeciesV1,
    SpeciesRegistry,
)


class SpeciesRegistryTests(unittest.TestCase):
    def test_generates_16_trait_species_without_magic_flags(self):
        reg = SpeciesRegistry(seed=10)
        reg.populate(n_plants=8, n_animals=6)
        self.assertEqual(len(reg.plants), 8)
        self.assertEqual(len(reg.animals), 6)
        for p in reg.plants.values():
            self.assertFalse(hasattr(p, 'cultivable'))
            self.assertFalse(hasattr(p, 'is_fruit_tree'))
            self.assertGreater(p.max_biomass, 0.0)
            self.assertGreaterEqual(p.regrowth_rate, 0.0)
        for a in reg.animals.values():
            self.assertFalse(hasattr(a, 'domesticable'))
            self.assertGreater(a.body_mass, 0.0)
            self.assertGreaterEqual(a.offspring_dependency, 0)


class FruitTreeAndCultivationTests(unittest.TestCase):
    def test_fruit_tree_non_destructive_harvest_vs_annual_consumption(self):
        reg = SpeciesRegistry(seed=1)
        fruit_tree = reg.add_plant(PlantSpeciesV1(
            species_id=1, name='apple_tree',
            growth_rate=0.10, max_biomass=4.0, water_need=0.3, temp_opt=20.0, temp_tol=15.0,
            nutrition=30.0, edible_fraction=0.25, toxicity=0.0, hardness=0.1,
            maturation_ticks=10, seed_output=3, dispersal_range=2, seed_dormancy=0.8,
            soil_need=0.2, storage_decay=0.05, regrowth_rate=0.15,
        ))
        annual = reg.add_plant(PlantSpeciesV1(
            species_id=2, name='wild_tuber',
            growth_rate=0.12, max_biomass=1.0, water_need=0.3, temp_opt=20.0, temp_tol=15.0,
            nutrition=25.0, edible_fraction=0.80, toxicity=0.0, hardness=0.1,
            maturation_ticks=5, seed_output=4, dispersal_range=1, seed_dormancy=0.8,
            soil_need=0.2, storage_decay=0.02, regrowth_rate=0.0,
        ))

        grid = np.full((8, 8), MAT_GRASS, dtype=int)
        eng = EcologyEngine(grid, reg, seed=1)
        eng.plants.place_plant(2, 2, fruit_tree.species_id, mature=True)
        eng.plants.place_plant(4, 4, annual.species_id, mature=True)

        # Harvest fruit tree yield -> structural biomass remains and yield regrows
        net_tree, _ = eng.plants.harvest(2, 2, amount=5.0)
        self.assertGreater(net_tree, 0.0)
        self.assertEqual(eng.plants.species_id[2, 2], fruit_tree.species_id)
        self.assertGreater(eng.plants.structural_biomass[2, 2], 0.0)

        # Harvest annual completely -> plant is consumed and leaves seeds
        net_ann, _ = eng.plants.harvest(4, 4, amount=5.0)
        self.assertGreater(net_ann, 0.0)
        self.assertEqual(eng.plants.species_id[4, 4], 0)
        self.assertIn((4, 4), eng.plants.seed_bank)

        # After 10 ticks, fruit tree yield regrows
        for _ in range(10):
            eng.plants.step(ClimateState(tick=0))
        self.assertGreater(eng.plants.yield_biomass[2, 2], 0.0)

    def test_primitive_drop_seed_germinates_under_suitable_conditions(self):
        reg = SpeciesRegistry(seed=2)
        sp = reg.add_plant(PlantSpeciesV1(
            species_id=1, name='grain',
            growth_rate=0.1, max_biomass=1.0, water_need=0.3, temp_opt=20.0, temp_tol=15.0,
            nutrition=20.0, edible_fraction=0.7, toxicity=0.0, hardness=0.1,
            maturation_ticks=5, seed_output=3, dispersal_range=1, seed_dormancy=0.9,
            soil_need=0.3, storage_decay=0.02, regrowth_rate=0.0,
        ))
        grid = np.full((6, 6), MAT_GRASS, dtype=int)
        eng = EcologyEngine(grid, reg, seed=2)
        self.assertTrue(eng.plants.drop_seed(3, 3, sp.species_id, count=2))
        germs = eng.plants.step(ClimateState(tick=0))
        self.assertEqual(germs, 1)
        self.assertEqual(eng.plants.species_id[3, 3], sp.species_id)


class HybridConservationAndDiseaseTests(unittest.TestCase):
    def _make_herbivore(self, reg: SpeciesRegistry) -> AnimalSpeciesV1:
        return reg.add_animal(AnimalSpeciesV1(
            species_id=1, name='deer',
            body_mass=20.0, diet='herbivore', energy_decay=1.0, sense_radius=4, max_age=150,
            maturity_age=10, repro_cooldown=10, litter_size=1, repro_threshold=75.0,
            flight_distance=3, aggression=0.1, attack_damage=2.0, sociality=0.6,
            panic_tendency=0.4, movement_speed=1, food_efficiency=0.8, offspring_dependency=3,
        ))

    def test_hybrid_rehydrate_dehydrate_conserves_exact_count_and_energy_tiers(self):
        reg = SpeciesRegistry(seed=3)
        sp = self._make_herbivore(reg)
        grid = np.full((16, 16), MAT_GRASS, dtype=int)
        eng = EcologyEngine(grid, reg, chunk_size=8, seed=3)

        # Spawn 3 animals in chunk (1, 1) with distinct energy tiers + 1 persistent animal
        eng.animals.spawn_active(sp.species_id, 10, 10, energy=20.0)  # low
        eng.animals.spawn_active(sp.species_id, 11, 11, energy=55.0)  # mid
        eng.animals.spawn_active(sp.species_id, 12, 12, energy=85.0)  # high
        eng.animals.spawn_active(sp.species_id, 13, 13, energy=60.0, persistent=True)
        self.assertEqual(eng.animals.total_count(sp.species_id), 4)

        # Deactivate chunk (1, 1): 3 animals dehydrated into 3-tier summary, persistent stays active
        eng.animals.sync_active_chunks({(0, 0)})
        self.assertEqual(eng.animals.total_count(sp.species_id), 4)
        self.assertEqual(len(eng.animals.active_animals), 1)
        summ = eng.animals.inactive_summaries[(1, 1)][sp.species_id]
        self.assertEqual((summ.low_n, summ.mid_n, summ.high_n), (1, 1, 1))

        # Rehydrate chunk (1, 1): exact 4 active animals restored
        eng.animals.sync_active_chunks({(1, 1)})
        self.assertEqual(eng.animals.total_count(sp.species_id), 4)
        self.assertEqual(len(eng.animals.active_animals), 4)

    def test_inactive_chunk_grazing_consumes_plant_yield_biomass(self):
        reg = SpeciesRegistry(seed=4)
        sp = self._make_herbivore(reg)
        plant = reg.add_plant()
        grid = np.full((16, 16), MAT_GRASS, dtype=int)
        eng = EcologyEngine(grid, reg, chunk_size=8, seed=4)
        for r in range(8, 12):
            for c in range(8, 12):
                eng.plants.place_plant(r, c, plant.species_id, mature=True)
        eng.animals.spawn_active(sp.species_id, 9, 9, energy=60.0)
        eng.animals.sync_active_chunks(set())  # deactivate all
        before = float(np.sum(eng.plants.yield_biomass[8:16, 8:16]))
        eng.animals.step_inactive(eng.plants)
        after = float(np.sum(eng.plants.yield_biomass[8:16, 8:16]))
        self.assertLess(after, before)

    def test_sir_infectious_disease_spreads_and_recovers(self):
        reg = SpeciesRegistry(seed=5)
        sp = self._make_herbivore(reg)
        grid = np.full((6, 6), MAT_GRASS, dtype=int)
        eng = EcologyEngine(grid, reg, chunk_size=6, seed=5)
        a1 = eng.animals.spawn_active(sp.species_id, 2, 2, energy=90.0, disease_state='I')
        a1.disease_timer = 10
        for _ in range(6):
            eng.animals.spawn_active(sp.species_id, 2, 2, energy=90.0, disease_state='S')

        for _ in range(12):
            eng.step({(0, 0)})
        self.assertGreater(eng.animals.infections, 0)
        self.assertEqual(a1.disease_state, 'R')


if __name__ == '__main__':
    unittest.main()
