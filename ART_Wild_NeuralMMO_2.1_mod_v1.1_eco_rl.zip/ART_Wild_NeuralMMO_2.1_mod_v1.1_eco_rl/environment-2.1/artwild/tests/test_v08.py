"""Tests for v0.8: SmallSurvivalWorld + CycleEngine, ArtAdapter, RolloutBuffer, and symmetric benchmark."""
import unittest
import numpy as np
from artwild.cycle import CycleConfig, CycleEngine
from artwild.art.vigilance_benchmark import generate_stream, run_benchmark
from artwild.rl import ArtAdapter, ArtRolloutPolicy, RolloutBuffer, SmallSurvivalWorld, SurvivalConfig
from artwild.rl.ppo_gru import HAS_TORCH, TransitionRecord


class SurvivalWorldAndCycleTests(unittest.TestCase):
    def test_survival_world_runs_inside_cycle_engine_and_resets_memory_on_death(self):
        cfg = SurvivalConfig(n_agents=4, max_ticks_per_life=25, food_decay=5.0, water_decay=5.0)
        world = SmallSurvivalWorld(cfg)
        art = ArtAdapter(mode='v0', rho=0.90, view_radius=cfg.view_radius)
        seen_memories = []

        def act_fn(raw_obs, art_feat, h_in):
            seen_memories.append(h_in)
            next_h = np.ones(4, dtype=np.float32) if h_in is None else h_in + 1.0
            return 0, next_h

        policy = ArtRolloutPolicy(art, act_fn)
        res = CycleEngine(world, policy).run(1, 42, (0,), CycleConfig(max_ticks=40, training=False))
        self.assertEqual(res.ticks, 40)
        self.assertGreater(res.deaths, 0)
        self.assertGreater(res.births, 0)
        # Newborns must have received h_in=None after founder deaths
        self.assertGreater(sum(1 for h in seen_memories if h is None), cfg.n_agents)

    def test_art_adapter_modes_and_collection_time_feature_storage(self):
        for mode, expected_dim in (('none', 0), ('v0', 34), ('v3', 46)):
            art = ArtAdapter(mode=mode, rho=0.90, view_radius=3)
            self.assertEqual(art.feature_dim, expected_dim)
            world = SmallSurvivalWorld(SurvivalConfig(n_agents=2))
            obs = world.reset(7, (0,))
            art.sync(obs.keys())
            f0, pc0 = art.observe('1', obs['1'])
            self.assertEqual(f0.shape, (expected_dim,))
            snapshot = f0.copy()
            ref0 = art.learn('1', pc0)
            # Subsequent observation changes ART state, but stored snapshot stays immutable
            art.learn('1', art.observe('1', obs['1'])[1])
            np.testing.assert_array_equal(f0, snapshot)
            if mode != 'none':
                self.assertTrue(art.credit('1', ref0, 1.0))
                self.assertFalse(art.credit('1', ref0, 1.0))

    def test_rollout_buffer_gae_respects_done_boundary(self):
        buf = RolloutBuffer()
        for t, (rew, done) in enumerate(((1.0, False), (2.0, True), (5.0, False))):
            buf.add(TransitionRecord(
                agent_id='1',
                raw_obs=np.zeros(12, dtype=np.float32),
                art_features=np.zeros(34, dtype=np.float32),
                action=0,
                log_prob=-1.0,
                value=0.0,
                reward=rew,
                done=done,
                h_in=np.zeros(8, dtype=np.float32),
            ))
        adv, ret = buf.compute_gae({'1': 0.0}, gamma=0.9, lam=0.95)
        # Step 1 (done=True) must NOT bootstrap from Step 2 (reward=5.0)
        self.assertAlmostEqual(float(ret[1]), 2.0, places=5)
        self.assertAlmostEqual(float(ret[2]), 5.0, places=5)


class SymmetricBenchmarkTests(unittest.TestCase):
    def test_isolated_streams_and_symmetric_metrics(self):
        Xp, _, _ = generate_stream(0, ticks=50, mode='phys_only')
        Xs, _, _ = generate_stream(0, ticks=50, mode='social_only')
        self.assertEqual(Xp.shape, (50, 28))
        self.assertEqual(Xs.shape, (50, 28))
        # In phys_only, social dims [22:27] stay constant; in social_only, phys [0:7] stay constant
        np.testing.assert_allclose(Xp[:, 22:27], np.broadcast_to(Xp[0:1, 22:27], (50, 5)))
        np.testing.assert_allclose(Xs[:, :3], np.broadcast_to(Xs[0:1, :3], (50, 3)))
        res = run_benchmark(seeds=(0,), ticks=60, mode='combined')
        self.assertIn('V3_repl5x_rho0.90', res)
        self.assertIn('danger_new_cat_rate', res['V0_rho0.90'])
        self.assertIn('benign_switch_rate', res['V0_rho0.90'])


@unittest.skipUnless(HAS_TORCH, 'PyTorch not installed in this environment')
class TorchPPOGruTests(unittest.TestCase):
    def test_run_condition_smoke(self):
        from artwild.rl.run_v08 import run_condition
        out = run_condition('v0', 0, budget_steps=256, rollout_ticks=16, eval_seeds=(100,))
        self.assertIn('post_reward', out)
        self.assertGreater(out['steps_per_sec'], 0.0)


if __name__ == '__main__':
    unittest.main()
