"""Tests for v0.7.3: reference integrity, 28-d sensory encoder, and experimental multi-channel ART."""
import unittest
import numpy as np
from artwild.art import (
    ArtLifetimeStore,
    ArtPerceiver,
    ExperienceRef,
    SensoryEncoder28,
    EncoderConfig,
    encode_28d,
    FEATURE_NAMES_28,
)
from artwild.art.encoder import MAT_FOILAGE, MAT_GRASS, MAT_STONE, MAT_WATER
from artwild.art.multichannel_fuzzy_art import MultiChannelFuzzyART


class ReferenceIntegrityTests(unittest.TestCase):
    def test_credit_is_one_time_only(self):
        p = ArtPerceiver(2, rho=0.9)
        pc = p.observe([0.2, 0.2])
        ref = p.learn(pc)
        self.assertEqual(p.pending_credit_count, 1)
        self.assertTrue(p.credit(ref, 1.0))
        self.assertEqual(p.pending_credit_count, 0)
        # Duplicate credit with the same ExperienceRef must be rejected
        self.assertFalse(p.credit(ref, 1.0))
        self.assertEqual(p.reward_n[ref.category], 1)
        self.assertAlmostEqual(p.reward_sum[ref.category], 1.0)

    def test_credit_rejects_foreign_owner_ref(self):
        p1 = ArtPerceiver(2, rho=0.9)
        p2 = ArtPerceiver(2, rho=0.9)
        ref1 = p1.learn(p1.observe([0.2, 0.2]))
        p2.learn(p2.observe([0.2, 0.2]))
        # Cross-agent credit must fail even if category & seq match
        self.assertFalse(p2.credit(ref1, 1.0))
        self.assertEqual(p2.reward_n[0], 0)
        self.assertTrue(p1.credit(ref1, 0.5))

    def test_retire_discards_uncredited_refs_and_blocks_future_calls(self):
        store = ArtLifetimeStore(lambda: ArtPerceiver(2, rho=0.9))
        p = store.get('agent:1')
        ref_a = p.learn(p.observe([0.1, 0.1]))
        ref_b = p.learn(p.observe([0.9, 0.9]))
        self.assertTrue(p.credit(ref_a, 1.0))
        self.assertEqual(p.pending_credit_count, 1)

        store.retire('agent:1')
        self.assertTrue(p.retired)
        self.assertEqual(p.pending_credit_count, 0)
        self.assertFalse(p.credit(ref_b, 1.0))
        with self.assertRaises(RuntimeError):
            p.observe([0.5, 0.5])

    def test_roundtrip_preserves_uncredited_seqs_and_owner(self):
        p = ArtPerceiver(2, rho=0.9)
        ref = p.learn(p.observe([0.3, 0.3]))
        p2 = ArtPerceiver.from_dict(p.to_dict())
        self.assertTrue(p2.credit(ref, 0.75))
        self.assertFalse(p2.credit(ref, 0.75))


class SensoryEncoder28Tests(unittest.TestCase):
    def test_output_shape_and_bounds(self):
        self.assertEqual(len(FEATURE_NAMES_28), 28)
        tiles = np.full((15, 15), MAT_GRASS, dtype=int)
        tiles[2, 7] = MAT_WATER   # North
        tiles[7, 12] = MAT_FOILAGE  # East
        tiles[12, 7] = MAT_STONE  # South (blocked)
        enc = SensoryEncoder28(EncoderConfig(view_radius=7))
        v1 = enc.encode({
            'health': 100.0, 'food': 80.0, 'water': 60.0,
            'age': 9.0, 'tile_materials': tiles,
            'entities': [(-2, 0, False), (0, 3, True)],
            'inventory_count': 6,
        })
        self.assertEqual(v1.shape, (28,))
        self.assertTrue(np.all(v1 >= 0.0) and np.all(v1 <= 1.0))
        # Check North water > 0, East food > 0, South blocked > 0
        self.assertGreater(v1[8], 0.0)   # terrain_N_water
        self.assertGreater(v1[12], 0.0)  # terrain_E_food
        self.assertGreater(v1[16], 0.0)  # terrain_S_blocked
        self.assertGreater(v1[20], 0.0)  # nearest_water_prox
        self.assertGreater(v1[21], 0.0)  # nearest_food_prox
        self.assertAlmostEqual(v1[27], 0.5)  # inventory_fill

        # Next tick: health drops by 25 -> delta_health=0.0, recent_damage > 0
        v2 = enc.encode({'health': 75.0, 'food': 79.0, 'water': 59.0, 'age': 9.1})
        self.assertAlmostEqual(v2[3], 0.0)
        self.assertGreater(v2[6], 0.0)


class MultiChannelFuzzyARTTests(unittest.TestCase):
    def test_dual_channel_detects_physiological_drop_without_splitting_noise(self):
        mc = MultiChannelFuzzyART([([0, 1, 2], 0.85), (list(range(3, 28)), 0.90)])
        base = np.full(28, 0.5)
        base[:3] = [1.0, 1.0, 1.0]
        r0 = mc.present(base)
        self.assertEqual(r0.category, 0)

        # Small noise in remaining 25 dims: should resonate in category 0
        noisy = base.copy()
        noisy[8:12] = 0.55
        r1 = mc.present(noisy)
        self.assertEqual(r1.category, 0)

        # Drop in physiological 3 dims (0.5 each -> match = 1 - 1.5/3 = 0.5 < 0.85): must split
        danger = base.copy()
        danger[:3] = [0.5, 0.5, 0.5]
        r2 = mc.present(danger)
        self.assertNotEqual(r2.category, 0)


if __name__ == '__main__':
    unittest.main()
