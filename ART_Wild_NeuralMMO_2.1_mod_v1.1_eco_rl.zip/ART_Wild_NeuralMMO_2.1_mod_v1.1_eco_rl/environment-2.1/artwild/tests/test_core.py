from random import Random
import unittest
from artwild import Genome, Population

class TestGenome(unittest.TestCase):
    def test_reproducible(self):
        self.assertEqual(Genome.random(Random(42)), Genome.random(Random(42)))

    def test_recessive_carrier_and_expression(self):
        a = [0] * 32
        b = [0] * 32
        # D01 position 6. Heterozygote does not express; homozygote does.
        a[6] = 1
        carrier = Genome(tuple(a), tuple(b))
        self.assertEqual(carrier.diseases(0), ())
        b[6] = 1
        affected = Genome(tuple(a), tuple(b))
        self.assertEqual([x.code for x in affected.diseases(0)], ['D01'])
        self.assertEqual(affected.phenotype(0)['STR'], carrier.phenotype(0)['STR'] - 3)

    def test_gamete_and_mutations(self):
        g = Genome((0,) * 32, (0,) * 32)
        self.assertEqual(g.gamete(Random(1), mutation_rate=0.0), (0,) * 32)
        self.assertEqual(g.gamete(Random(1), mutation_rate=1.0), (1,) * 32)

    def test_sex_marker_uses_two_values(self):
        for i in range(40):
            self.assertIn(Genome.random(Random(i)).sex, ('XX', 'XY'))

    def test_inheritance_from_two_parents(self):
        a = Genome((0,) * 32, (0,) * 32)
        b = Genome((1,) * 32, (1,) * 32)
        child = Genome.inherit(a, b, Random(123), mutation_rate=0)
        self.assertEqual(child.homolog_a, (0,) * 32)
        self.assertEqual(child.homolog_b, (1,) * 32)

class TestPopulation(unittest.TestCase):
    def setUp(self):
        self.p = Population(seed=12)
        self.p.add_lineage(10)
        self.p.add_lineage(20)
        self.a = self.p.founder(0, 10)
        self.b = self.p.founder(0, 20)

    def test_birth_genealogy_policy_individual_memory(self):
        self.a.memory = {'private': 10}
        self.b.memory = {'private': 20}
        c = self.p.birth(self.a.id, self.b.id, 100)
        self.assertEqual(c.parent_ids, (self.a.id, self.b.id))
        self.assertIn(c.id, self.a.children)
        self.assertIn(c.id, self.b.children)
        self.assertIn(c.lineage_id, (10, 20))
        self.assertIsNone(c.memory)
        self.assertEqual(len(self.p.living()), 3)

    def test_death_no_resurrection_id_monotonic(self):
        self.p.death(self.a.id, 200, 'test')
        self.assertFalse(self.a.alive)
        self.assertEqual(len(self.p.living()), 1)
        with self.assertRaises(ValueError):
            self.p.death(self.a.id, 201)
        new_founder = self.p.founder(202, 10)
        self.assertNotEqual(new_founder.id, self.a.id)
        self.assertEqual(self.p.age(self.b.id, 100), 1.0)

    def test_dead_parent_cannot_reproduce(self):
        self.p.death(self.a.id, 20)
        with self.assertRaises(ValueError):
            self.p.birth(self.a.id, self.b.id, 30)

if __name__ == '__main__':
    unittest.main()
