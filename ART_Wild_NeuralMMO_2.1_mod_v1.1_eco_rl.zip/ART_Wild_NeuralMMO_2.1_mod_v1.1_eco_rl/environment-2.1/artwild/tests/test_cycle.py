import unittest
from artwild.cycle import CycleEngine,CycleConfig,CyclePlanner,WorldStep
from artwild.toy_world import ToyWorld,SilenceAndForage,CountingLearner

class CycleTests(unittest.TestCase):
 def test_observation_cycle_no_learner(self):
  result=CycleEngine(ToyWorld(),SilenceAndForage()).run(1,3,(0,1),CycleConfig(max_ticks=8,training=False))
  self.assertEqual(result.ticks,8)
  self.assertIsNone(result.learner_report)
  self.assertGreaterEqual(result.births,1)
  self.assertTrue(any(e['type']=='birth' for e in result.event_log))
 def test_training_requires_actual_learner(self):
  with self.assertRaises(ValueError): CycleEngine(ToyWorld(),SilenceAndForage()).run(1,3,(0,),CycleConfig(training=True))
 def test_learner_is_only_counter(self):
  learner=CountingLearner()
  r=CycleEngine(ToyWorld(),SilenceAndForage(),learner=learner).run(2,4,(1,2),CycleConfig(max_ticks=5,training=True))
  self.assertGreater(r.learner_report['transitions_collected'],0)
  self.assertFalse(r.learner_report['weights_updated'])
 def test_stable_determinism(self):
  c=CycleConfig(max_ticks=25,training=False)
  a=CycleEngine(ToyWorld(),SilenceAndForage()).run(3,12,(1,2),c)
  b=CycleEngine(ToyWorld(),SilenceAndForage()).run(3,12,(1,2),c)
  self.assertEqual(a.event_log,b.event_log)
  self.assertEqual(a.world_snapshot,b.world_snapshot)
 def test_no_policy_learning_claim(self):
  r=CycleEngine(ToyWorld(),SilenceAndForage()).run(1,4,(0,1),CycleConfig(max_ticks=30,training=False))
  plan=CyclePlanner().plan(r,use_distillation=True,request_mutations=True)
  self.assertTrue(plan.distilled)
  self.assertIn('requests only',plan.note)
 def test_no_identity_reuse(self):
  class NeverMate(SilenceAndForage):
   def act(self, observations, memories, lineage_ids):
    actions,updated=super().act(observations,memories,lineage_ids)
    for action in actions.values(): action['mate']=None
    return actions,updated
  r=CycleEngine(ToyWorld(max_age=21,founder_age=20),NeverMate()).run(1,4,(0,1),CycleConfig(max_ticks=10,training=False))
  self.assertEqual(r.end_reason,'extinction')
  self.assertEqual(r.alive,0)
 def test_empty_lineage_rejected(self):
  with self.assertRaises(ValueError): CycleEngine(ToyWorld(),SilenceAndForage()).run(1,4,(),CycleConfig(training=False))
 def test_config_invalid(self):
  with self.assertRaises(ValueError): CycleConfig(0)
if __name__=='__main__': unittest.main()
