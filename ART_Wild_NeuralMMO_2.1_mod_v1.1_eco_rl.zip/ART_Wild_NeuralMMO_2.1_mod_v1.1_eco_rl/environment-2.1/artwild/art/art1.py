"""ART 1 for binary inputs, in the fast-learning algorithmic form of [CG87].

Written separately from FuzzyART, with the paper's own bottom-up (z) and
top-down (w) templates, so the two can be cross-checked:

  choice      T_j = I . z_j,  z_j = L w_j / (L - 1 + |w_j|)  (committed node)
              z_ij(0) < L / (L - 1 + M)  for the uncommitted node
  vigilance   |I ^ w_j| / |I| >= rho
  learning    w_j <- I ^ w_j   (fast learning; z_j recomputed from w_j)

Not implemented: the F1/F2 on-line differential equations, the 2/3 rule as a
dynamical gate, and slow learning. Fuzzy ART with binary input, no complement
coding, beta = 1 and alpha = L - 1 gives the same choice order [see tests].
"""
from __future__ import annotations
import numpy as np
from artwild.art.common import ArtBase, grow


class ART1(ArtBase):
    kind = 'art1'

    def __init__(self, input_dim: int, *, L: float = 2.0, rho: float = 0.75,
                 max_categories: int | None = None):
        super().__init__(max_categories)
        if input_dim < 1:
            raise ValueError('input_dim must be positive')
        if not L > 1:
            raise ValueError('L must be > 1')
        if not 0 <= rho <= 1:
            raise ValueError('rho must lie in [0, 1]')
        self.M, self.L, self.rho = input_dim, float(L), float(rho)
        # strict inequality z(0) < L/(L-1+M) required by [CG87]
        self.z0 = self.L / (self.L - 1 + self.M) * (1 - 1e-9)
        self._w = np.ones((8, self.M), dtype=np.uint8)
        self._z = np.full((8, self.M), self.z0)

    @property
    def weights(self) -> np.ndarray:
        return self._w[:self.n]

    def _encode(self, x) -> np.ndarray:
        I = np.asarray(x)
        if I.shape != (self.M,) or not np.all((I == 0) | (I == 1)):
            raise ValueError(f'ART1 input must be a binary vector of length {self.M}')
        I = I.astype(np.uint8)
        if I.sum() < 1:
            raise ValueError('ART1 input must contain at least one 1')
        return I

    def _scores(self, I):
        overlap = (I & self._w[:self.n]).sum(axis=1).astype(float)
        T = self._z[:self.n] @ I.astype(float)
        nI = float(I.sum())
        return overlap, T, self.z0 * nI, nI

    def _z_of(self, w: np.ndarray) -> np.ndarray:
        return self.L * w / (self.L - 1 + float(w.sum()))

    def _learn(self, I, j: int) -> None:
        if j == self.n:
            if self.n == self._w.shape[0]:
                self._w, self._z = grow(self._w, 1), grow(self._z, self.z0)
            self._w[j] = I
            self.n += 1
        else:
            self._w[j] = I & self._w[j]
        self._z[j] = self._z_of(self._w[j].astype(float))

    def to_dict(self) -> dict:
        return {'kind': self.kind, 'input_dim': self.M, 'L': self.L, 'rho': self.rho,
                'max_categories': self.max_categories, 'weights': self.weights.tolist()}

    @classmethod
    def from_dict(cls, d: dict) -> 'ART1':
        if d.get('kind') != cls.kind:
            raise ValueError('not an ART1 state')
        net = cls(d['input_dim'], L=d['L'], rho=d['rho'], max_categories=d['max_categories'])
        for row in d['weights']:
            net._learn(np.asarray(row, dtype=np.uint8), net.n)
        return net
