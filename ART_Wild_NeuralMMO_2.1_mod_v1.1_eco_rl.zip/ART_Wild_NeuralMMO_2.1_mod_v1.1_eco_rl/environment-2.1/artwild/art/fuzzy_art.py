"""Fuzzy ART [CGR91].

Category choice   T_j = |I ^ w_j| / (alpha + |w_j|)         (Weber law form)
Vigilance test    |I ^ w_j| / |I| >= rho                     (else reset j)
Learning          w_j <- beta (I ^ w_j) + (1 - beta) w_j     (beta=1: fast)
Uncommitted node  w = (1,...,1); a new node is "fast-committed" (w = I) and
                  only recoded slowly afterwards when fast_commit=True.
'^' is the component-wise minimum, |.| the L1 norm.

With complement coding each category is the hyperbox [u, v] where
w = (u, 1 - v); under fast learning u/v are the min/max of its members, and
vigilance bounds the box's summed side lengths by M (1 - rho).
"""
from __future__ import annotations
import numpy as np
from artwild.art.common import ArtBase, check_unit_vector, complement_code, grow


class FuzzyART(ArtBase):
    kind = 'fuzzy_art'

    def __init__(self, input_dim: int, *, alpha: float = 1e-3, beta: float = 1.0,
                 rho: float = 0.75, complement_coding: bool = True,
                 fast_commit: bool = True, max_categories: int | None = None):
        super().__init__(max_categories)
        if input_dim < 1:
            raise ValueError('input_dim must be positive')
        if not alpha > 0:
            raise ValueError('alpha must be > 0')
        if not 0 < beta <= 1:
            raise ValueError('beta must lie in (0, 1]')
        if not 0 <= rho <= 1:
            raise ValueError('rho must lie in [0, 1]')
        self.M, self.alpha, self.beta, self.rho = input_dim, float(alpha), float(beta), float(rho)
        self.complement_coding, self.fast_commit = bool(complement_coding), bool(fast_commit)
        self.D = 2 * input_dim if complement_coding else input_dim
        self._w = np.ones((8, self.D))

    @property
    def weights(self) -> np.ndarray:
        return self._w[:self.n]

    def _encode(self, x) -> np.ndarray:
        if self.complement_coding:
            check_unit_vector(x, self.M)
            return complement_code(x)
        I = check_unit_vector(x, self.M)
        if I.sum() <= 0:
            raise ValueError('without complement coding |I| must be > 0')
        return I

    def encode(self, x) -> np.ndarray:
        return self._encode(x)

    def _scores(self, I):
        W = self._w[:self.n]
        overlap = np.minimum(I, W).sum(axis=1)
        T = overlap / (self.alpha + W.sum(axis=1))
        nI = float(I.sum())
        return overlap, T, nI / (self.alpha + self.D), nI  # uncommitted: w=1, |w|=D

    def _learn(self, I, j: int) -> None:
        if j == self.n:
            if self.n == self._w.shape[0]:
                self._w = grow(self._w, 1.0)
            self._w[j] = I if self.fast_commit else self.beta * I + (1 - self.beta)
            self.n += 1
        else:
            w = self._w[j]
            self._w[j] = self.beta * np.minimum(I, w) + (1 - self.beta) * w

    # --- hyperbox view (complement coding only) --------------------------
    def box(self, j: int):
        if not self.complement_coding:
            raise ValueError('hyperbox view requires complement coding')
        w = self._w[j]
        return w[:self.M].copy(), 1.0 - w[self.M:]

    def center(self, j: int) -> np.ndarray:
        if not self.complement_coding:
            return self._w[j].copy()
        u, v = self.box(j)
        return (u + v) / 2.0

    # --- persistence ------------------------------------------------------
    def to_dict(self) -> dict:
        return {'kind': self.kind, 'input_dim': self.M, 'alpha': self.alpha, 'beta': self.beta,
                'rho': self.rho, 'complement_coding': self.complement_coding,
                'fast_commit': self.fast_commit, 'max_categories': self.max_categories,
                'weights': self.weights.tolist()}

    @classmethod
    def from_dict(cls, d: dict) -> 'FuzzyART':
        if d.get('kind') != cls.kind:
            raise ValueError('not a FuzzyART state')
        net = cls(d['input_dim'], alpha=d['alpha'], beta=d['beta'], rho=d['rho'],
                  complement_coding=d['complement_coding'], fast_commit=d['fast_commit'],
                  max_categories=d['max_categories'])
        W = np.asarray(d['weights'], dtype=float).reshape(-1, net.D)
        while net._w.shape[0] < len(W):
            net._w = grow(net._w, 1.0)
        net._w[:len(W)] = W
        net.n = len(W)
        return net
