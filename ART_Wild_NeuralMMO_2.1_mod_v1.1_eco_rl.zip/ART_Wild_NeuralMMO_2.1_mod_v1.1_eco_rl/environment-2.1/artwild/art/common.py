"""Shared machinery for the ART modules: result type, input coding, and the
single search cycle (choice -> vigilance test -> reset -> resonance) used by
every network in this package.

References (algorithmic level only; the STM/LTM differential equations of the
papers are NOT simulated here):
  [CG87]  Carpenter & Grossberg (1987) A massively parallel architecture for a
          self-organizing neural pattern recognition machine. CVGIP 37:54-115.
  [CGR91] Carpenter, Grossberg & Rosen (1991) Fuzzy ART. Neural Networks 4:759-771.
  [CG+92] Carpenter, Grossberg, Markuzon, Reynolds & Rosen (1992) Fuzzy ARTMAP.
          IEEE Trans. Neural Networks 3:698-713.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

TOL = 1e-12  # float guard for the vigilance comparison only


class ArtError(Exception):
    """Base class for ART-specific errors."""


@dataclass(frozen=True)
class SearchResult:
    """Outcome of one presentation.

    reason is one of:
      'resonance'          a category accepted the input (category is its index)
      'novel'              (inference only) an uncommitted node won the choice
                           competition, i.e. the input is not coded by any
                           learned category; nothing was created
      'search_exhausted'   every node was reset (only possible when vigilance
                           exceeds 1, e.g. after match tracking)
      'capacity_exhausted' like search_exhausted, but a new category would have
                           been allowed had max_categories not been reached
    """
    category: int | None
    reason: str
    committed_new: bool = False
    resets: int = 0
    choice: float = float('nan')
    match: float = float('nan')
    rho_final: float = float('nan')

    @property
    def resonated(self) -> bool:
        return self.reason == 'resonance'


def check_unit_vector(a, dim: int, name: str = 'input') -> np.ndarray:
    a = np.asarray(a, dtype=float)
    if a.shape != (dim,):
        raise ValueError(f'{name} must have shape ({dim},), got {a.shape}')
    if not np.all(np.isfinite(a)) or a.min() < 0.0 or a.max() > 1.0:
        raise ValueError(f'{name} components must lie in [0, 1]')
    return a


def complement_code(a) -> np.ndarray:
    """I = (a, 1 - a). Keeps |I| = M for every input [CGR91, Sec. 'Complement
    coding'], which prevents category proliferation and makes categories
    hyperboxes."""
    a = np.asarray(a, dtype=float)
    if a.ndim != 1 or a.size == 0:
        raise ValueError('input must be a non-empty 1-D vector')
    if not np.all(np.isfinite(a)) or a.min() < 0.0 or a.max() > 1.0:
        raise ValueError('input components must lie in [0, 1]')
    return np.concatenate([a, 1.0 - a])


def grow(arr: np.ndarray, fill) -> np.ndarray:
    """Double the first axis of arr, filling new rows with fill."""
    out = np.full((max(8, arr.shape[0] * 2),) + arr.shape[1:], fill, dtype=arr.dtype)
    out[:arr.shape[0]] = arr
    return out


class ArtBase:
    """One-layer ART search shared by ART 1 and Fuzzy ART.

    Subclasses define how a node scores an input and how it learns. The
    uncommitted node is virtual: it is never stored, it competes with the
    committed nodes under its own choice value, and it always passes the
    vigilance test (match = |I ^ 1| / |I| = 1) unless vigilance exceeds 1.
    Ties in the choice value go to the lowest index, and the uncommitted node
    has the highest index [CGR91].
    """

    def __init__(self, max_categories: int | None):
        if max_categories is not None and max_categories < 1:
            raise ValueError('max_categories must be positive or None')
        self.max_categories = max_categories
        self.n = 0  # number of committed categories

    # --- subclass hooks -------------------------------------------------
    def _scores(self, I):
        """Return (overlap[n], choice[n], choice_uncommitted, |I|)."""
        raise NotImplementedError

    def _learn(self, I, j: int) -> None:
        """Apply learning to category j (j == self.n means: commit a new one)."""
        raise NotImplementedError

    # --- search ---------------------------------------------------------
    def _search(self, I, rho: float, *, allow_commit: bool, veto=None,
                epsilon: float = 0.0) -> SearchResult:
        n = self.n
        overlap, T, T_unc, nI = self._scores(I)
        capacity_left = self.max_categories is None or n < self.max_categories
        all_T = np.concatenate([T, [T_unc]])
        order = np.lexsort((np.arange(n + 1), -all_T))  # primary: -T, then index
        resets = 0
        for j in order:
            j = int(j)
            if j == n:  # the uncommitted node
                if not capacity_left:
                    continue
                if 1.0 < rho - TOL:
                    resets += 1
                    continue
                if not allow_commit:
                    return SearchResult(None, 'novel', False, resets, float(T_unc), 1.0, rho)
                return SearchResult(n, 'resonance', True, resets, float(T_unc), 1.0, rho)
            match = float(overlap[j] / nI)
            if match < rho - TOL:
                resets += 1
                continue
            if veto is not None and veto(j):
                # match tracking [CG+92]: raise vigilance just above this match
                rho = max(rho, match + epsilon)
                resets += 1
                continue
            return SearchResult(j, 'resonance', False, resets, float(T[j]), match, rho)
        reason = 'search_exhausted' if capacity_left else 'capacity_exhausted'
        return SearchResult(None, reason, False, resets, rho_final=rho)

    def present(self, x, *, learn: bool = True, rho: float | None = None,
                veto=None, epsilon: float = 0.0) -> SearchResult:
        """Present one input. With learn=True a resonant category learns (or is
        committed); with learn=False nothing changes and an input that would
        recruit an uncommitted node is reported as 'novel'."""
        I = self._encode(x)
        r = self.rho if rho is None else float(rho)
        res = self._search(I, r, allow_commit=learn, veto=veto, epsilon=epsilon)
        if learn and res.resonated:
            self._learn(I, res.category)
        return res

    def classify(self, x, *, rho: float | None = None) -> SearchResult:
        return self.present(x, learn=False, rho=rho)
