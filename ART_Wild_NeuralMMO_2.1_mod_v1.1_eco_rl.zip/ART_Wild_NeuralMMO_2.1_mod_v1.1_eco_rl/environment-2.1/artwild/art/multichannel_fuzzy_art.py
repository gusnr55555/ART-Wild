"""Experimental Multi-Channel Fuzzy ART (NOT the default architecture).

Each channel k has its own feature indices and vigilance threshold rho_k.
A category node j passes vigilance only if EVERY channel passes its rho_k.
Kept separate from FuzzyART until V0-V4 experiments validate its trade-offs.
"""
from __future__ import annotations
from typing import Sequence
import numpy as np
from artwild.art.common import TOL, SearchResult, check_unit_vector, complement_code, grow


class MultiChannelFuzzyART:
    kind = 'multichannel_fuzzy_art_experimental'

    def __init__(
        self,
        channels: Sequence[tuple[Sequence[int], float]],
        *,
        alpha: float = 1e-3,
        beta: float = 1.0,
        complement_coding: bool = True,
        fast_commit: bool = True,
        max_categories: int | None = None,
    ):
        if not channels:
            raise ValueError('at least one channel is required')
        if not complement_coding:
            raise ValueError('MultiChannelFuzzyART requires complement_coding=True')
        if not alpha > 0:
            raise ValueError('alpha must be > 0')
        if not 0 < beta <= 1:
            raise ValueError('beta must lie in (0, 1]')
        if max_categories is not None and max_categories < 1:
            raise ValueError('max_categories must be positive or None')

        self.channels: list[tuple[np.ndarray, float]] = []
        all_idx: list[int] = []
        for idxs, rho in channels:
            idx_arr = np.asarray(list(idxs), dtype=int)
            if idx_arr.ndim != 1 or idx_arr.size == 0:
                raise ValueError('each channel must have a non-empty 1-D index list')
            if not 0.0 <= float(rho) <= 1.0:
                raise ValueError('channel rho must lie in [0, 1]')
            self.channels.append((idx_arr, float(rho)))
            all_idx.extend(idx_arr.tolist())

        self.M = max(all_idx) + 1
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.fast_commit = bool(fast_commit)
        self.max_categories = max_categories
        self.n = 0
        self._w_channels: list[np.ndarray] = [
            np.ones((8, 2 * len(idx_arr)), dtype=float)
            for idx_arr, _ in self.channels
        ]

    @property
    def memory_bytes(self) -> int:
        return sum(w[:self.n].nbytes for w in self._w_channels)

    def _encode_channels(self, x) -> list[np.ndarray]:
        vec = check_unit_vector(x, self.M)
        return [complement_code(vec[idx_arr]) for idx_arr, _ in self.channels]

    def _search(self, I_list: list[np.ndarray], *, allow_commit: bool) -> SearchResult:
        n = self.n
        k_count = len(self.channels)
        gamma = 1.0 / k_count
        capacity_left = self.max_categories is None or n < self.max_categories

        T_total = np.zeros(n, dtype=float)
        T_unc = 0.0
        matches_per_ch: list[np.ndarray] = []

        for ch_i, (I_k, (idx_arr, _)) in enumerate(zip(I_list, self.channels)):
            M_k = len(idx_arr)
            D_k = 2 * M_k
            nI_k = float(I_k.sum())
            T_unc += gamma * (nI_k / (self.alpha + D_k))
            if n > 0:
                W_k = self._w_channels[ch_i][:n]
                overlap_k = np.minimum(I_k, W_k).sum(axis=1)
                T_total += gamma * (overlap_k / (self.alpha + W_k.sum(axis=1)))
                matches_per_ch.append(overlap_k / nI_k)
            else:
                matches_per_ch.append(np.empty(0, dtype=float))

        all_T = np.concatenate([T_total, [T_unc]])
        order = np.lexsort((np.arange(n + 1), -all_T))
        resets = 0
        for j in order:
            j = int(j)
            if j == n:
                if not capacity_left:
                    continue
                if not allow_commit:
                    return SearchResult(None, 'novel', False, resets, float(T_unc), 1.0, max(r for _, r in self.channels))
                return SearchResult(n, 'resonance', True, resets, float(T_unc), 1.0, max(r for _, r in self.channels))

            passed = True
            min_match = 1.0
            for ch_i, (_, rho_k) in enumerate(self.channels):
                m_jk = float(matches_per_ch[ch_i][j])
                if m_jk < min_match:
                    min_match = m_jk
                if m_jk < rho_k - TOL:
                    passed = False
                    break
            if not passed:
                resets += 1
                continue
            return SearchResult(j, 'resonance', False, resets, float(T_total[j]), min_match, max(r for _, r in self.channels))

        reason = 'search_exhausted' if capacity_left else 'capacity_exhausted'
        return SearchResult(None, reason, False, resets)

    def _learn(self, I_list: list[np.ndarray], j: int) -> None:
        if j == self.n:
            for ch_i, I_k in enumerate(I_list):
                if self.n == self._w_channels[ch_i].shape[0]:
                    self._w_channels[ch_i] = grow(self._w_channels[ch_i], 1.0)
                self._w_channels[ch_i][j] = (
                    I_k if self.fast_commit else self.beta * I_k + (1.0 - self.beta)
                )
            self.n += 1
        else:
            for ch_i, I_k in enumerate(I_list):
                w = self._w_channels[ch_i][j]
                self._w_channels[ch_i][j] = self.beta * np.minimum(I_k, w) + (1.0 - self.beta) * w

    def present(self, x, *, learn: bool = True) -> SearchResult:
        I_list = self._encode_channels(x)
        res = self._search(I_list, allow_commit=learn)
        if learn and res.resonated:
            self._learn(I_list, res.category)
        return res

    def classify(self, x) -> SearchResult:
        return self.present(x, learn=False)
