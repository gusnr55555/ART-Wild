"""ArtPerceiver: turns an observation vector into a FIXED-SIZE feature vector
for a policy, using a per-agent Fuzzy ART as a non-differentiable preprocessor.
It is a long-term perceptual category memory; it has NO notion of time order,
so it is not an episodic memory.

Three-phase contract per agent and tick (so that features never mix the
pre-learning and post-learning state, and reward lands on the right category):

    percept = p.observe(x)       # classify only; ART is NOT modified
    ... policy uses percept.features and acts; the runner STORES these features
        in the transition (they must not be recomputed at PPO update time) ...
    ref = p.learn(percept)       # now ART learns x; returns where it went
    ... environment steps, reward r arrives ...
    p.credit(ref, r)             # reward goes to that category, not "the last one"

Reference integrity contract (v0.7.3):
  - One-time use: each ExperienceRef.seq can be credited at most once.
  - Per-agent ownership: ExperienceRef carries owner_id; cross-agent credit is rejected.
  - Lifetime retirement: retire() discards all uncredited refs and rejects future calls.

Features (all computed BEFORE learning x), all in [-1, 1]:
  [match, novel, reset_frac, visits_frac, mean_reward, saturated, center(M)...]
  match        match value of the accepted category (0 if none)
  novel        1 if no learned category accepts x (a new one would be created)
  reset_frac   resets / (resets + 1)
  visits_frac  v / (v + 10), v = visits to the winning category so far
  mean_reward  mean of rewards credited to the winning category, clipped
  saturated    1 if max_categories blocks creating a new category
  center       hyperbox centre of the winning category before this x (0 if none)

Whether these features help PPO is UNTESTED; this class fixes the interface only.
"""
from __future__ import annotations
from dataclasses import dataclass
import uuid
import numpy as np
from artwild.art.common import SearchResult
from artwild.art.fuzzy_art import FuzzyART

HEAD = 6


@dataclass(frozen=True)
class Percept:
    features: np.ndarray
    result: SearchResult
    seq: int
    x: np.ndarray


@dataclass(frozen=True)
class ExperienceRef:
    """Where an experience was stored. category is None if nothing was learned."""
    category: int | None
    seq: int
    owner_id: str = ''


class ArtPerceiver:
    def __init__(self, input_dim: int, *, owner_id: str | None = None, **fuzzy_kwargs):
        fuzzy_kwargs.setdefault('complement_coding', True)
        if not fuzzy_kwargs['complement_coding']:
            raise ValueError('ArtPerceiver requires complement coding (hyperbox centres)')
        self.art = FuzzyART(input_dim, **fuzzy_kwargs)
        self.owner_id: str = owner_id if owner_id is not None else uuid.uuid4().hex
        self.visits: list[int] = []
        self.reward_sum: list[float] = []
        self.reward_n: list[int] = []     # rewards received (not visits)
        self._seq = 0
        self._pending: Percept | None = None
        self._uncredited_seqs: set[int] = set()
        self._retired: bool = False

    @property
    def retired(self) -> bool:
        return self._retired

    @property
    def pending_credit_count(self) -> int:
        return len(self._uncredited_seqs)

    @property
    def feature_dim(self) -> int:
        return HEAD + self.art.M

    def observe(self, x) -> Percept:
        if self._retired:
            raise RuntimeError('perceiver is retired')
        r = self.art.classify(x)
        f = np.zeros(self.feature_dim)
        f[2] = r.resets / (r.resets + 1.0)
        if r.category is None:
            f[1] = 1.0
            f[5] = 1.0 if r.reason == 'capacity_exhausted' else 0.0
        else:
            j, n = r.category, self.reward_n[r.category]
            f[0] = r.match
            f[3] = self.visits[j] / (self.visits[j] + 10.0)
            f[4] = float(np.clip(self.reward_sum[j] / n, -1.0, 1.0)) if n else 0.0
            f[HEAD:] = self.art.center(j)
        self._pending = Percept(f, r, self._seq + 1, np.array(x, dtype=float))
        return self._pending

    def learn(self, percept: Percept) -> ExperienceRef:
        if self._retired:
            raise RuntimeError('perceiver is retired')
        if percept is not self._pending:
            raise ValueError('stale percept: learn() must follow its own observe()')
        self._pending = None
        r = self.art.present(percept.x, learn=True)
        if r.category is None:                       # capacity exhausted: nothing stored
            return ExperienceRef(None, percept.seq, self.owner_id)
        want = percept.result.category
        if want is not None and r.category != want:
            raise RuntimeError('classification changed between observe() and learn()')
        while len(self.visits) <= r.category:
            self.visits.append(0)
            self.reward_sum.append(0.0)
            self.reward_n.append(0)
        self.visits[r.category] += 1
        self._seq += 1
        seq = self._seq
        self._uncredited_seqs.add(seq)
        return ExperienceRef(r.category, seq, self.owner_id)

    def credit(self, ref: ExperienceRef, reward: float) -> bool:
        """Credit reward to the category the experience was stored in.

        Enforces one-time consumption per seq, owner_id match, and non-retired state.
        """
        if self._retired:
            return False
        if ref.owner_id != self.owner_id:
            return False
        if ref.seq not in self._uncredited_seqs:
            return False
        self._uncredited_seqs.remove(ref.seq)
        if ref.category is None or ref.category < 0 or ref.category >= len(self.visits):
            return False
        self.reward_sum[ref.category] += float(reward)
        self.reward_n[ref.category] += 1
        return True

    def retire(self) -> int:
        """Mark perceiver as retired and discard all uncredited references.

        Returns the number of discarded uncredited references.
        """
        discarded = len(self._uncredited_seqs)
        self._uncredited_seqs.clear()
        self._pending = None
        self._retired = True
        return discarded

    def to_dict(self) -> dict:
        return {
            'art': self.art.to_dict(),
            'owner_id': self.owner_id,
            'visits': list(self.visits),
            'reward_sum': list(self.reward_sum),
            'reward_n': list(self.reward_n),
            'seq': self._seq,
            'uncredited_seqs': sorted(self._uncredited_seqs),
            'retired': self._retired,
        }

    @classmethod
    def from_dict(cls, d: dict) -> 'ArtPerceiver':
        a = d['art']
        p = cls(a['input_dim'], owner_id=d.get('owner_id'),
                alpha=a['alpha'], beta=a['beta'], rho=a['rho'],
                fast_commit=a['fast_commit'], max_categories=a['max_categories'])
        p.art = FuzzyART.from_dict(a)
        p.visits, p.reward_sum, p.reward_n = (list(d['visits']), list(d['reward_sum']),
                                              list(d['reward_n']))
        p._seq = int(d.get('seq', 0))
        p._uncredited_seqs = set(d.get('uncredited_seqs', ()))
        p._retired = bool(d.get('retired', False))
        if not (len(p.visits) == len(p.reward_sum) == len(p.reward_n) == p.art.n):
            raise ValueError('inconsistent perceiver state')
        return p
