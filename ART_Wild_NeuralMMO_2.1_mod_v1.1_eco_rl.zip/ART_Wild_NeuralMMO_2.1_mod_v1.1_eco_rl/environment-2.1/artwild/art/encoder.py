"""28-dimensional ART sensory encoder (pure numpy, no Neural MMO / torch import).

Implements Design Decision 5 from ARTWILD_ART_SPEC.md:
  - Interoception (7): health, food, water, 1-tick deltas (health, food, water), recent_damage
  - Maturity (1): age / maturity_age clipped to [0, 1]
  - Terrain (12): water / food_source / blocked fractions in 4 map-axis quadrants (N, E, S, W)
  - Nearest resources (2): proximity to nearest water and nearest plain food source
  - Social (5): nearby player count, nearby NPC count, nearest entity proximity,
                and relative (dr, dc) direction to nearest entity
  - Inventory (1): inventory fill fraction

All 28 components lie in [0.0, 1.0]. No persistent facing direction is assumed
(Neural MMO moves are N/S/E/W), so map-axis cardinal sectors are used.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping, Sequence
import numpy as np

# Neural MMO 2.1 material IDs (nmmo.lib.material)
MAT_VOID = 0
MAT_WATER = 1
MAT_GRASS = 2
MAT_SCRUB = 3
MAT_FOILAGE = 4
MAT_STONE = 5
MAT_SLAG = 6
MAT_ORE = 7
MAT_STUMP = 8
MAT_TREE = 9
MAT_FRAGMENT = 10
MAT_CRYSTAL = 11
MAT_WEEDS = 12
MAT_HERB = 13
MAT_OCEAN = 14
MAT_FISH = 15

IMPASSIBLE_MATERIALS = frozenset({MAT_VOID, MAT_WATER, MAT_STONE, MAT_OCEAN, MAT_FISH})
PLAIN_FOOD_MATERIALS = frozenset({MAT_FOILAGE})
WATER_MATERIALS = frozenset({MAT_WATER})

FEATURE_NAMES_28: tuple[str, ...] = (
    'health', 'food', 'water',
    'delta_health', 'delta_food', 'delta_water', 'recent_damage',
    'maturity',
    'terrain_N_water', 'terrain_N_food', 'terrain_N_blocked',
    'terrain_E_water', 'terrain_E_food', 'terrain_E_blocked',
    'terrain_S_water', 'terrain_S_food', 'terrain_S_blocked',
    'terrain_W_water', 'terrain_W_food', 'terrain_W_blocked',
    'nearest_water_prox', 'nearest_food_prox',
    'nearby_players', 'nearby_npcs',
    'nearest_entity_prox', 'nearest_entity_dr', 'nearest_entity_dc',
    'inventory_fill',
)

ENCODER_CONDITION: dict[str, Any] = {
    'dim': 28,
    'quadrant_mode': 'cardinal_sectors_NESW',
    'semantic_grouping': 'nmmo21_plain_food_foilage',
    'distance_metric': 'manhattan',
    'impassible_materials': sorted(IMPASSIBLE_MATERIALS),
    'plain_food_materials': sorted(PLAIN_FOOD_MATERIALS),
    'water_materials': sorted(WATER_MATERIALS),
}


def _clip01(val: float) -> float:
    return float(np.clip(val, 0.0, 1.0))


def _encode_signed(val: float, scale: float) -> float:
    if scale <= 0:
        return 0.5
    return _clip01(0.5 + 0.5 * (val / scale))


@dataclass
class EncoderConfig:
    max_health: float = 100.0
    max_food: float = 100.0
    max_water: float = 100.0
    delta_scale: float = 25.0
    damage_scale: float = 50.0
    damage_decay: float = 0.5
    maturity_age: float = 18.0
    view_radius: int = 7
    social_cap: int = 8
    inventory_capacity: int = 12


def _quadrant_masks(h: int, w: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return boolean masks for N, E, S, W cardinal sectors around center (h//2, w//2)."""
    cr, cc = h // 2, w // 2
    rr, cc_grid = np.ogrid[:h, :w]
    dr = rr - cr
    dc = cc_grid - cc
    not_center = (dr != 0) | (dc != 0)
    north = not_center & (dr < 0) & (np.abs(dr) >= np.abs(dc))
    south = not_center & (dr > 0) & (np.abs(dr) >= np.abs(dc))
    east = not_center & (dc > 0) & (np.abs(dc) > np.abs(dr))
    west = not_center & (dc < 0) & (np.abs(dc) > np.abs(dr))
    return north, east, south, west


def encode_28d(
    *,
    health: float,
    food: float,
    water: float,
    delta_health: float = 0.0,
    delta_food: float = 0.0,
    delta_water: float = 0.0,
    recent_damage: float = 0.0,
    age: float = 0.0,
    tile_materials: np.ndarray | None = None,
    entities: Sequence[tuple[int, int, bool]] = (),
    inventory_count: int = 0,
    config: EncoderConfig | None = None,
) -> np.ndarray:
    """Encode a single agent's observation into a 28-d vector in [0, 1]^28.

    Parameters
    ----------
    tile_materials : (H, W) int array of material IDs centered on the agent.
        If None, terrain and resource proximities default to 0.
    entities : sequence of (dr, dc, is_npc) relative to agent position.
        (dr=0, dc=0) is ignored if present (self).
    """
    cfg = config or EncoderConfig()
    out = np.zeros(28, dtype=float)

    # 1. Interoception (7)
    out[0] = _clip01(health / cfg.max_health)
    out[1] = _clip01(food / cfg.max_food)
    out[2] = _clip01(water / cfg.max_water)
    out[3] = _encode_signed(delta_health, cfg.delta_scale)
    out[4] = _encode_signed(delta_food, cfg.delta_scale)
    out[5] = _encode_signed(delta_water, cfg.delta_scale)
    out[6] = _clip01(recent_damage / cfg.damage_scale)

    # 2. Maturity (1)
    out[7] = _clip01(age / cfg.maturity_age) if cfg.maturity_age > 0 else 1.0

    # 3 & 4. Terrain quadrants (12) + Nearest water/food proximity (2)
    if tile_materials is not None:
        mats = np.asarray(tile_materials)
        if mats.ndim != 2 or mats.size == 0:
            raise ValueError('tile_materials must be a non-empty 2-D array')
        h, w = mats.shape
        cr, cc = h // 2, w // 2
        is_water = np.isin(mats, tuple(WATER_MATERIALS))
        is_food = np.isin(mats, tuple(PLAIN_FOOD_MATERIALS))
        is_blocked = np.isin(mats, tuple(IMPASSIBLE_MATERIALS))

        for qi, qmask in enumerate(_quadrant_masks(h, w)):
            denom = float(qmask.sum())
            if denom > 0:
                base = 8 + qi * 3
                out[base] = float((is_water & qmask).sum()) / denom
                out[base + 1] = float((is_food & qmask).sum()) / denom
                out[base + 2] = float((is_blocked & qmask).sum()) / denom

        max_dist = float(max(1, cfg.view_radius * 2))
        rr, cc_grid = np.ogrid[:h, :w]
        dist = np.abs(rr - cr) + np.abs(cc_grid - cc)
        if np.any(is_water):
            d_w = float(dist[is_water].min())
            out[20] = _clip01(1.0 - d_w / max_dist)
        if np.any(is_food):
            d_f = float(dist[is_food].min())
            out[21] = _clip01(1.0 - d_f / max_dist)

    # 5. Social (5)
    n_players = 0
    n_npcs = 0
    best_dist = None
    best_dr = 0
    best_dc = 0
    for dr, dc, is_npc in entities:
        if dr == 0 and dc == 0:
            continue
        if is_npc:
            n_npcs += 1
        else:
            n_players += 1
        d = abs(int(dr)) + abs(int(dc))
        if best_dist is None or d < best_dist:
            best_dist = d
            best_dr = int(dr)
            best_dc = int(dc)

    out[22] = _clip01(n_players / max(1, cfg.social_cap))
    out[23] = _clip01(n_npcs / max(1, cfg.social_cap))
    if best_dist is not None:
        max_ent_dist = float(max(1, cfg.view_radius * 2))
        out[24] = _clip01(1.0 - best_dist / max_ent_dist)
        out[25] = _encode_signed(float(best_dr), float(max(1, cfg.view_radius)))
        out[26] = _encode_signed(float(best_dc), float(max(1, cfg.view_radius)))
    else:
        out[24] = 0.0
        out[25] = 0.5
        out[26] = 0.5

    # 6. Inventory fill (1)
    out[27] = _clip01(inventory_count / max(1, cfg.inventory_capacity))
    return out


class SensoryEncoder28:
    """Per-agent stateful wrapper that tracks 1-tick interoceptive deltas & damage."""

    def __init__(self, config: EncoderConfig | None = None):
        self.config = config or EncoderConfig()
        self._prev: tuple[float, float, float] | None = None
        self._recent_damage: float = 0.0

    def reset(self) -> None:
        self._prev = None
        self._recent_damage = 0.0

    def encode(self, obs: Mapping[str, Any]) -> np.ndarray:
        """Encode a dict-like observation into a 28-d vector in [0, 1]^28."""
        health = float(obs['health'])
        food = float(obs['food'])
        water = float(obs['water'])
        if self._prev is None:
            dh = df = dw = 0.0
        else:
            ph, pf, pw = self._prev
            dh = health - ph
            df = food - pf
            dw = water - pw
        self._prev = (health, food, water)
        dmg = max(0.0, -dh)
        self._recent_damage = self._recent_damage * self.config.damage_decay + dmg
        return encode_28d(
            health=health,
            food=food,
            water=water,
            delta_health=dh,
            delta_food=df,
            delta_water=dw,
            recent_damage=self._recent_damage,
            age=float(obs.get('age', 0.0)),
            tile_materials=obs.get('tile_materials'),
            entities=obs.get('entities', ()),
            inventory_count=int(obs.get('inventory_count', 0)),
            config=self.config,
        )
