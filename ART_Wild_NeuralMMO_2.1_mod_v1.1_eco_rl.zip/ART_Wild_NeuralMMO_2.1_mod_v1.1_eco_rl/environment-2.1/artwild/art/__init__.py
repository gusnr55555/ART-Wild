"""Adaptive Resonance Theory modules for ART-Wild (Carpenter & Grossberg).

Independent of Neural MMO and of torch; numpy only. See ARTWILD_ART_SPEC.md for
the paper-to-code map, what is and is not implemented, and open design choices.
"""
from artwild.art.common import SearchResult, ArtError, complement_code
from artwild.art.fuzzy_art import FuzzyART
from artwild.art.art1 import ART1
from artwild.art.artmap import FuzzyARTMAP, MapResult
from artwild.art.lifetime_store import ArtLifetimeStore
from artwild.art.perceiver import ArtPerceiver, Percept, ExperienceRef
from artwild.art.encoder import (
    SensoryEncoder28,
    EncoderConfig,
    encode_28d,
    FEATURE_NAMES_28,
    ENCODER_CONDITION,
)

__all__ = [
    'SearchResult', 'ArtError', 'complement_code', 'FuzzyART', 'ART1',
    'FuzzyARTMAP', 'MapResult', 'ArtLifetimeStore', 'ArtPerceiver', 'Percept', 'ExperienceRef',
    'SensoryEncoder28', 'EncoderConfig', 'encode_28d', 'FEATURE_NAMES_28', 'ENCODER_CONDITION',
]
