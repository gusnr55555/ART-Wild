"""Fuzzy ARTMAP [CG+92]: two Fuzzy ART modules joined by a map field.

ART_a codes the input A, ART_b codes the target B. Because ART_b is a
winner-take-all field, its output y^b is one-hot, and under the map field's
fast learning (x^ab = y^b ^ w^ab_J) every committed ART_a node maps to exactly
one ART_b category. The map field is therefore stored as one integer per
ART_a node; this is exactly equivalent, and the literal test
|y^b ^ w^ab_J| / |y^b| >= rho_ab is evaluated on that representation. (For the
same reason rho_ab has no effect beyond validation here.)

Match tracking: if node J of ART_a predicts the wrong ART_b category, J is
reset and ART_a vigilance rises to |A ^ w_J| / |A| + epsilon, so the search
continues among strictly better-matching nodes (or a new one). ART_a vigilance
returns to its baseline rho_a at the start of every training trial.

Not implemented: the (optional) F0 normalization of the original paper beyond
complement coding, ARTMAP-IC, distributed (dART) coding, and multi-epoch
shuffling helpers (callers loop over train()).
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from artwild.art.fuzzy_art import FuzzyART


@dataclass(frozen=True)
class MapResult:
    category_a: int | None
    category_b: int | None
    reason: str          # 'resonance', 'novel', or 'a_'/'b_' + SearchResult.reason
    match_tracking_resets: int = 0
    committed_new: bool = False


class FuzzyARTMAP:
    kind = 'fuzzy_artmap'

    def __init__(self, input_dim_a: int, input_dim_b: int, *, rho_a: float = 0.0,
                 rho_b: float = 1.0, rho_ab: float = 1.0, epsilon: float = 1e-6,
                 a_params: dict | None = None, b_params: dict | None = None):
        if not 0 < rho_ab <= 1:
            raise ValueError('rho_ab must lie in (0, 1]')
        a = dict(alpha=1e-3, beta=1.0, max_categories=None)
        a.update(a_params or {})
        b = dict(alpha=1e-3, beta=1.0, max_categories=None)
        b.update(b_params or {})
        self.art_a = FuzzyART(input_dim_a, rho=rho_a, **a)
        self.art_b = FuzzyART(input_dim_b, rho=rho_b, **b)
        self.rho_a, self.rho_ab, self.epsilon = float(rho_a), float(rho_ab), float(epsilon)
        self.map: list[int] = []   # ART_a category -> ART_b category

    def _consistent(self, j: int, k: int) -> bool:
        return (1.0 if self.map[j] == k else 0.0) >= self.rho_ab  # |y^b ^ w^ab_j| / |y^b|

    def train(self, a, b) -> MapResult:
        rb = self.art_b.present(b, learn=True)
        if not rb.resonated:
            return MapResult(None, None, 'b_' + rb.reason)
        k = rb.category
        ra = self.art_a.present(a, learn=True, rho=self.rho_a,
                                veto=lambda j: not self._consistent(j, k),
                                epsilon=self.epsilon)
        if not ra.resonated:
            return MapResult(None, k, 'a_' + ra.reason, ra.resets)
        if ra.committed_new:
            self.map.append(k)
        mt = ra.resets
        return MapResult(ra.category, k, 'resonance', mt, ra.committed_new)

    def predict(self, a) -> MapResult:
        """Inference: no learning, no new categories. An input no ART_a category
        accepts at baseline vigilance is reported as 'novel' (no guess)."""
        ra = self.art_a.classify(a, rho=self.rho_a)
        if not ra.resonated:
            return MapResult(None, None, ra.reason)
        return MapResult(ra.category, self.map[ra.category], 'resonance')

    def predict_vector(self, a) -> np.ndarray | None:
        r = self.predict(a)
        return None if r.category_b is None else self.art_b.center(r.category_b)

    def to_dict(self) -> dict:
        return {'kind': self.kind, 'rho_a': self.rho_a, 'rho_ab': self.rho_ab,
                'epsilon': self.epsilon, 'art_a': self.art_a.to_dict(),
                'art_b': self.art_b.to_dict(), 'map': list(self.map)}

    @classmethod
    def from_dict(cls, d: dict) -> 'FuzzyARTMAP':
        if d.get('kind') != cls.kind:
            raise ValueError('not a FuzzyARTMAP state')
        net = cls(d['art_a']['input_dim'], d['art_b']['input_dim'], rho_a=d['rho_a'],
                  rho_b=d['art_b']['rho'], rho_ab=d['rho_ab'], epsilon=d['epsilon'])
        net.art_a, net.art_b = FuzzyART.from_dict(d['art_a']), FuzzyART.from_dict(d['art_b'])
        net.map = list(d['map'])
        if len(net.map) != net.art_a.n:
            raise ValueError('map field size does not match ART_a')
        return net
