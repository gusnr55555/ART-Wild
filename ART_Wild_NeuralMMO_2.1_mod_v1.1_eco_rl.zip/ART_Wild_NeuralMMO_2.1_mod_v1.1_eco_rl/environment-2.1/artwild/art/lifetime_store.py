"""Per-lifetime ART state with no cross-lifetime leakage.

Matches the CycleEngine contract: lifetime keys are never recycled, a newborn
starts with a fresh network, and a departed key's network is destroyed. Whether
a newborn should instead inherit anything (from a parent, a mother net, or a
previous cycle) is a design decision NOT made here.
"""
from __future__ import annotations
from typing import Callable, Iterable


class ArtLifetimeStore:
    def __init__(self, factory: Callable[[], object]):
        self._factory = factory
        self._live: dict[str, object] = {}
        self._retired: set[str] = set()

    def get(self, key: str):
        if key in self._retired:
            raise KeyError(f'lifetime key {key!r} was retired; keys must not be reused')
        if key not in self._live:
            self._live[key] = self._factory()   # always a brand-new network
        return self._live[key]

    def retire(self, key: str) -> None:
        obj = self._live.pop(key, None)
        if obj is not None and callable(getattr(obj, 'retire', None)):
            obj.retire()
        self._retired.add(key)

    def sync(self, alive: Iterable[str]) -> list[str]:
        """Retire every held key not in alive; return the retired keys."""
        alive = set(alive)
        gone = sorted(k for k in self._live if k not in alive)
        for k in gone:
            self.retire(k)
        return gone

    def keys(self) -> tuple[str, ...]:
        return tuple(self._live)

    def __len__(self) -> int:
        return len(self._live)
