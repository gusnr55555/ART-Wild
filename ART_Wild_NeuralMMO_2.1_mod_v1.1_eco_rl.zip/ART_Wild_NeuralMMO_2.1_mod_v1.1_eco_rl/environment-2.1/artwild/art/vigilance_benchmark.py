"""V0-V4 Vigilance Comparison Experiment (v0.8 symmetric + isolated streams).

Conditions (identical 28-d input stream per seed):
  V0: Single FuzzyART(28, rho=0.90)
  V1: Single FuzzyART(28, rho=0.95)
  V2: Single FuzzyART(28, rho=0.99)
  V3: Physiological 3-d [health, food, water] replicated 5x (40-d), FuzzyART(40, rho=0.90)
  V4: Experimental Dual-channel MultiChannelFuzzyART: phys 3-d (rho=0.85) + rest 25-d (rho=0.90)

Symmetric Metrics (separating new category creation vs. existing category switch):
  - danger_new_cat_rate:  fraction of danger-onset ticks that commit a NEW category
  - danger_switch_rate:   fraction of danger-onset ticks that switch to a DIFFERENT existing category
  - benign_new_cat_rate:  fraction of benign ticks that commit a NEW category
  - benign_switch_rate:   fraction of benign ticks that switch to a DIFFERENT existing category
  - categories:           final number of committed categories
  - classify_us:          mean classify() latency in microseconds per tick
  - memory_kb:            committed weight storage in KB

Stream Modes:
  - 'combined':    simultaneous physiology, terrain, and social changes
  - 'phys_only':   only physiological state changes (terrain/social held constant)
  - 'social_only': only social state changes (physiology/terrain held constant)
"""
from __future__ import annotations
import time
import numpy as np
from artwild.art.encoder import (
    MAT_FOILAGE,
    MAT_GRASS,
    MAT_STONE,
    MAT_WATER,
    EncoderConfig,
    SensoryEncoder28,
)
from artwild.art.fuzzy_art import FuzzyART
from artwild.art.multichannel_fuzzy_art import MultiChannelFuzzyART


def generate_stream(
    seed: int, ticks: int = 2000, mode: str = 'combined'
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    if mode not in ('combined', 'phys_only', 'social_only'):
        raise ValueError(f'unknown stream mode: {mode}')

    rng = np.random.default_rng(seed)
    enc = SensoryEncoder28(EncoderConfig(view_radius=7))
    X = np.zeros((ticks, 28), dtype=float)
    is_danger_onset = np.zeros(ticks, dtype=bool)
    is_benign = np.zeros(ticks, dtype=bool)

    health, food, water = 95.0, 90.0, 90.0
    age = 5.0
    inv = 3
    base_tiles = np.full((15, 15), MAT_GRASS, dtype=int)
    base_tiles[2, 3] = MAT_WATER
    base_tiles[3, 11] = MAT_FOILAGE
    base_tiles[11, 4] = MAT_STONE
    base_tiles[12, 10] = MAT_STONE

    regime = 'safe_forage'
    regime_timer = 0
    for t in range(ticks):
        regime_timer -= 1
        if regime_timer <= 0:
            r = rng.random()
            if r < 0.72:
                regime = 'safe_forage'
                regime_timer = int(rng.integers(15, 45))
            elif r < 0.86:
                regime = 'combat_damage'
                regime_timer = int(rng.integers(2, 5))
                is_danger_onset[t] = True
            else:
                regime = 'starvation_dehydration'
                regime_timer = int(rng.integers(4, 10))
                is_danger_onset[t] = True

        if mode == 'social_only':
            # Physiology & terrain stay completely constant; only social entities vary.
            health, food, water = 95.0, 90.0, 90.0
            tiles = base_tiles
            if regime == 'safe_forage':
                if t > 0 and not is_danger_onset[t - 1]:
                    is_benign[t] = True
                entities = (
                    [(int(rng.integers(-6, 7)), int(rng.integers(-6, 7)), False)]
                    if rng.random() < 0.25 else []
                )
            else:
                # Sudden close NPC/hostile cluster
                entities = [
                    (int(rng.integers(-1, 2)), int(rng.integers(-1, 2)), True),
                    (int(rng.integers(-2, 3)), int(rng.integers(-2, 3)), True),
                ]
        else:
            if regime == 'safe_forage':
                health = float(np.clip(health + rng.normal(0.3, 0.5), 75.0, 100.0))
                food = float(np.clip(food + rng.normal(0.0, 1.2), 65.0, 100.0))
                water = float(np.clip(water + rng.normal(0.0, 1.2), 65.0, 100.0))
                if t > 0 and not is_danger_onset[t - 1]:
                    is_benign[t] = True
            elif regime == 'combat_damage':
                health = float(np.clip(health - rng.uniform(22.0, 40.0), 5.0, 100.0))
                food = float(np.clip(food - rng.uniform(0.5, 2.0), 10.0, 100.0))
                water = float(np.clip(water - rng.uniform(0.5, 2.0), 10.0, 100.0))
            else:
                health = float(np.clip(health - rng.uniform(8.0, 15.0), 10.0, 100.0))
                food = float(np.clip(food - rng.uniform(15.0, 28.0), 5.0, 100.0))
                water = float(np.clip(water - rng.uniform(15.0, 28.0), 5.0, 100.0))

            if mode == 'phys_only':
                tiles = base_tiles
                entities = []
            else:
                tiles = base_tiles.copy()
                if rng.random() < 0.3:
                    rr, cc = int(rng.integers(0, 15)), int(rng.integers(0, 15))
                    tiles[rr, cc] = int(rng.choice([MAT_GRASS, MAT_STONE, MAT_FOILAGE, MAT_WATER]))
                entities = []
                if regime == 'combat_damage':
                    entities.append((int(rng.integers(-2, 3)), int(rng.integers(-2, 3)), True))
                elif rng.random() < 0.25:
                    entities.append((int(rng.integers(-6, 7)), int(rng.integers(-6, 7)), False))

        if mode == 'combined':
            age += 0.01
            inv = int(np.clip(inv + rng.integers(-1, 2), 0, 12))

        X[t] = enc.encode({
            'health': health,
            'food': food,
            'water': water,
            'age': age,
            'tile_materials': tiles,
            'entities': entities,
            'inventory_count': inv,
        })
    return X, is_danger_onset, is_benign


def _replicate_phys(X: np.ndarray, copies: int = 5) -> np.ndarray:
    phys = X[:, :3]
    extra = np.tile(phys, (1, copies - 1))
    return np.concatenate([X, extra], axis=1)


def run_benchmark(
    seeds: tuple[int, ...] = (0, 1, 2, 3, 4),
    ticks: int = 2000,
    mode: str = 'combined',
) -> dict[str, dict[str, float]]:
    conditions = ('V0_rho0.90', 'V1_rho0.95', 'V2_rho0.99', 'V3_repl5x_rho0.90', 'V4_dual_0.85_0.90')
    acc: dict[str, list[dict[str, float]]] = {c: [] for c in conditions}

    for seed in seeds:
        X28, danger_onset, benign = generate_stream(seed, ticks=ticks, mode=mode)
        X40 = _replicate_phys(X28, copies=5)

        models = {
            'V0_rho0.90': (FuzzyART(28, rho=0.90), X28),
            'V1_rho0.95': (FuzzyART(28, rho=0.95), X28),
            'V2_rho0.99': (FuzzyART(28, rho=0.99), X28),
            'V3_repl5x_rho0.90': (FuzzyART(40, rho=0.90), X40),
            'V4_dual_0.85_0.90': (MultiChannelFuzzyART([([0, 1, 2], 0.85), (list(range(3, 28)), 0.90)]), X28),
        }

        for name, (model, X) in models.items():
            prev_cat = None
            danger_total = danger_new = danger_switch = 0
            benign_total = benign_new = benign_switch = 0
            t_cls = 0.0

            for t in range(ticks):
                x = X[t]
                t0 = time.perf_counter()
                model.classify(x)
                t_cls += time.perf_counter() - t0

                res = model.present(x, learn=True)
                switched = (not res.committed_new) and (prev_cat is not None) and (res.category != prev_cat)
                if danger_onset[t]:
                    danger_total += 1
                    if res.committed_new:
                        danger_new += 1
                    elif switched:
                        danger_switch += 1
                if benign[t]:
                    benign_total += 1
                    if res.committed_new:
                        benign_new += 1
                    elif switched:
                        benign_switch += 1
                prev_cat = res.category

            mem_bytes = model.memory_bytes if isinstance(model, MultiChannelFuzzyART) else model.weights.nbytes
            acc[name].append({
                'danger_new_cat_rate': danger_new / max(1, danger_total),
                'danger_switch_rate': danger_switch / max(1, danger_total),
                'benign_new_cat_rate': benign_new / max(1, benign_total),
                'benign_switch_rate': benign_switch / max(1, benign_total),
                'categories': float(model.n),
                'classify_us': (t_cls / ticks) * 1e6,
                'memory_kb': mem_bytes / 1024.0,
            })

    return {
        name: {k: float(np.mean([r[k] for r in rows])) for k in rows[0]}
        for name, rows in acc.items()
    }


if __name__ == '__main__':
    for mode in ('combined', 'phys_only', 'social_only'):
        print(f"\n=== Stream Mode: {mode} ===")
        res = run_benchmark(mode=mode)
        print(
            f"{'Condition':<20} | {'DngNew%':>7} | {'DngSw%':>7} | "
            f"{'BngNew%':>7} | {'BngSw%':>7} | {'Cats':>7} | {'Cls(us)':>7} | {'Mem(KB)':>7}"
        )
        print('-' * 92)
        for name, m in res.items():
            print(
                f"{name:<20} | {m['danger_new_cat_rate']*100:6.1f}% | {m['danger_switch_rate']*100:6.1f}% | "
                f"{m['benign_new_cat_rate']*100:6.2f}% | {m['benign_switch_rate']*100:6.2f}% | "
                f"{m['categories']:7.1f} | {m['classify_us']:7.1f} | {m['memory_kb']:7.2f}"
            )
