"""Lifetime-safe policy adapter for ART-Wild.

Unlike PettingZoo's slot IDs, the keys in this adapter are never reused
within a run. This is an alternative policy-runner API, NOT PettingZoo.
It prevents actions and hidden state from crossing biological lifetimes.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any


def lifetime_key(cycle: int, bio_id: int) -> str:
    if cycle < 1 or bio_id < 1:
        raise ValueError('cycle and bio_id must be positive')
    return f'{cycle}:{bio_id}'


@dataclass
class LifetimeStep:
    observations: dict[str, Any]
    rewards: dict[str, float]
    terminated: dict[str, bool]
    truncated: dict[str, bool]
    infos: dict[str, dict]
    # Deaths that share a slot with a newborn are returned as terminal-only
    # records. A separate observation is not fabricated for the dead agent.


class LifetimeDriver:
    """Translate non-reusable lifetime IDs to reusable NMMO slots.

    Call reset(), then step({lifetime_key: action, ...}). GRU hidden states
    should be keyed by these lifetime keys and cleared when terminated.
    """
    def __init__(self, env):
        self.env = env
        self._active: dict[str, int] = {}
        self._ready = False

    def reset(self, *args, **kwargs):
        observations, infos = self.env.reset(*args, **kwargs)
        self._active = {}
        mapped_obs, mapped_infos = {}, {}
        for slot, obs in observations.items():
            bio = self.env.slot_to_bio_id.get(slot)
            if bio is None:
                continue
            key = lifetime_key(self.env._aw_cycle, bio)
            self._active[key] = slot
            mapped_obs[key] = obs
            mapped_infos[key] = dict(infos.get(slot, {}), artwild_bio_id=bio,
                                     artwild_slot_id=slot)
        self._ready = True
        return mapped_obs, mapped_infos

    @property
    def active_agents(self):
        return tuple(self._active)

    def step(self, actions: dict[str, Any]) -> LifetimeStep:
        if not self._ready:
            raise RuntimeError('Call reset() before step()')
        if set(actions) - set(self._active):
            raise ValueError('Actions for unknown/dead lifetime IDs')
        old = dict(self._active)
        slot_actions = {old[key]: action for key, action in actions.items()}
        obs, rewards, terminated, truncated, infos = self.env.step(slot_actions)
        current = {}
        result = LifetimeStep({}, {}, {}, {}, {})
        for slot, observation in obs.items():
            bio = self.env.slot_to_bio_id.get(slot)
            if bio is None:
                continue
            key = lifetime_key(self.env._aw_cycle, bio)
            current[key] = slot
            result.observations[key] = observation
            result.rewards[key] = rewards.get(slot, 0.)
            result.terminated[key] = bool(terminated.get(slot, False))
            result.truncated[key] = bool(truncated.get(slot, False))
            result.infos[key] = dict(infos.get(slot, {}), artwild_bio_id=bio,
                                     artwild_slot_id=slot)
        # Ensure every dead identity gets a terminal flag even if its slot has
        # already been recycled and is now used by a newborn this very tick.
        for key, slot in old.items():
            if key not in current:
                result.rewards[key] = rewards.get(slot, 0.) if slot not in current.values() else 0.
                result.terminated[key] = bool(terminated.get(slot, False)) or (slot in self.env._dead_this_tick)
                result.truncated[key] = bool(truncated.get(slot, False))
                result.infos[key] = {'artwild_bio_id': int(key.split(':')[1]),
                                     'artwild_slot_id': slot,
                                     'artwild_departed': True}
        self._active = {key: slot for key, slot in current.items()
                        if not (result.terminated.get(key) or result.truncated.get(key))}
        # Env-level truncation can return terminal-only keys; none may be reused.
        return result
