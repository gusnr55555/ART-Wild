"""ART-Wild v0.1: minimal diploid genome, birth, death, hereditary policy lineages.

This is an add-on core, NOT a patch already applied to Neural MMO 2.1.
It does not implement PPO, a sound system or a full world simulation.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from random import Random
from typing import Dict, Optional

TRAITS = ('STR', 'CON', 'MAT', 'REP', 'PAR', 'SEN')

@dataclass(frozen=True)
class Disease:
    code: str
    stat: str
    additive: float = 0.0
    multiplier: float = 1.0
    onset_age: float = 0.0

DEFAULT_DISEASES = (
    Disease('D01', 'STR', additive=-3),
    Disease('D02', 'CON', additive=-3),
    Disease('D03', 'energy_cost', multiplier=1.25),
    Disease('D04', 'growth_rate', multiplier=0.8),
    Disease('D05', 'infection_risk', multiplier=1.5),
    Disease('D06', 'sensory_range', multiplier=0.75),
    Disease('D07', 'fertility', multiplier=0.6, onset_age=15),
    Disease('D08', 'aging_rate', multiplier=1.3, onset_age=20),
)

@dataclass(frozen=True)
class Genome:
    """Two homologs. Alleles are 0/1 for simple trait-affecting loci and diseases.

    Not a biologically calibrated human genome. One diploid locus per trait is
    used as an intentionally small executable prototype; can be expanded later.
    """
    homolog_a: tuple[int, ...]
    homolog_b: tuple[int, ...]
    sex: str = "XX"  # Prototype XX/XY reproduction marker, not full chromosomes.

    @staticmethod
    def random(rng: Random, loci: int = 32, minor_allele_rate: float = 0.15) -> 'Genome':
        if loci < len(TRAITS) + len(DEFAULT_DISEASES):
            raise ValueError('Insufficient loci for trait and disease map')
        if not (0 <= minor_allele_rate <= 1):
            raise ValueError('minor_allele_rate outside [0, 1]')
        draw = lambda: tuple(int(rng.random() < minor_allele_rate) for _ in range(loci))
        return Genome(draw(), draw(), rng.choice(("XX", "XY")))

    def __post_init__(self):
        if self.sex not in ('XX', 'XY'):
            raise ValueError('Unsupported sex marker')
        if len(self.homolog_a) != len(self.homolog_b):
            raise ValueError('Mismatched chromosome lengths')
        if any(x not in (0, 1) for x in self.homolog_a + self.homolog_b):
            raise ValueError('Alleles must be 0 or 1')
        if len(self.homolog_a) < len(TRAITS) + len(DEFAULT_DISEASES):
            raise ValueError('Too few loci')

    def gamete(self, rng: Random, mutation_rate: float = 0.0001, crossover_rate: float = 0.04) -> tuple[int, ...]:
        """Recombination between loci; mutation after segregation.

        crossover_rate is probability of switching parental homolog between
        adjacent loci, NOT an empirically realistic rate.
        """
        if not 0 <= mutation_rate <= 1 or not 0 <= crossover_rate <= 1:
            raise ValueError('rates must lie in [0, 1]')
        homolog = rng.randrange(2)
        out = []
        for i, (a, b) in enumerate(zip(self.homolog_a, self.homolog_b)):
            if i and rng.random() < crossover_rate:
                homolog ^= 1
            v = (a, b)[homolog]
            if rng.random() < mutation_rate:
                v ^= 1
            out.append(v)
        return tuple(out)

    @staticmethod
    def inherit(parent_a: 'Genome', parent_b: 'Genome', rng: Random, mutation_rate: float = 0.0001) -> 'Genome':
        if len(parent_a.homolog_a) != len(parent_b.homolog_a):
            raise ValueError('Parents have different genome length')
        # All offspring receive an X contribution from XX and either X or Y
        # from XY. Sex markers are not affected by autosomal mutation here.
        return Genome(parent_a.gamete(rng, mutation_rate),
                      parent_b.gamete(rng, mutation_rate),
                      rng.choice(('XX', 'XY')))

    def expressed_traits(self) -> Dict[str, float]:
        return {trait: 10 + 2 * (self.homolog_a[i] + self.homolog_b[i] - 1)
                for i, trait in enumerate(TRAITS)}

    def diseases(self, age: float, definitions=DEFAULT_DISEASES) -> tuple[Disease, ...]:
        offset = len(TRAITS)
        return tuple(d for i, d in enumerate(definitions)
                     if self.homolog_a[offset+i] == self.homolog_b[offset+i] == 1
                     and age >= d.onset_age)

    def phenotype(self, age: float, definitions=DEFAULT_DISEASES) -> dict[str, float]:
        values = self.expressed_traits()
        values.update(energy_cost=1., growth_rate=1., infection_risk=1.,
                      sensory_range=1., fertility=1., aging_rate=1.)
        for d in self.diseases(age, definitions):
            values[d.stat] = (values[d.stat] + d.additive) * d.multiplier
        values['STR'] = max(1., values['STR'])
        values['CON'] = max(1., values['CON'])
        return values

@dataclass
class PolicyLineage:
    id: int
    parent_id: Optional[int] = None
    mutation_generation: int = 0

@dataclass
class AgentRecord:
    id: int
    genome: Genome
    lineage_id: int
    born_tick: int
    parent_ids: Optional[tuple[int, int]] = None
    alive: bool = True
    died_tick: Optional[int] = None
    children: list[int] = field(default_factory=list)
    # Independent per-individual recurrent memory; created by external policy runtime.
    memory: object = None
    last_reproduction_tick: Optional[int] = None

class Population:
    """Persistent entity IDs and genealogy independent of MMO's ephemeral agent slots."""
    def __init__(self, seed: int = 0, ticks_per_year: int = 100, mutation_rate: float = 0.0001):
        if ticks_per_year <= 0:
            raise ValueError('ticks_per_year must be positive')
        self.rng = Random(seed)
        self.ticks_per_year = ticks_per_year
        self.mutation_rate = mutation_rate
        self.next_id = 1
        self.agents: dict[int, AgentRecord] = {}
        self.lineages: dict[int, PolicyLineage] = {}
        self.events: list[dict] = []

    def add_lineage(self, lineage_id: int, parent_id: Optional[int] = None) -> None:
        if lineage_id in self.lineages:
            raise ValueError('Lineage already exists')
        if parent_id is not None and parent_id not in self.lineages:
            raise KeyError('Unknown parent lineage')
        generation = 0 if parent_id is None else self.lineages[parent_id].mutation_generation + 1
        self.lineages[lineage_id] = PolicyLineage(lineage_id, parent_id, generation)

    def founder(self, tick: int, lineage_id: int, genome: Optional[Genome] = None,
                age_years: float = 0.0) -> AgentRecord:
        if lineage_id not in self.lineages:
            raise KeyError('Unknown policy lineage')
        if age_years < 0:
            raise ValueError('age_years must be non-negative')
        born_tick = tick - round(age_years * self.ticks_per_year)
        record = AgentRecord(self.next_id, genome if genome is not None else Genome.random(self.rng),
                             lineage_id, born_tick)
        self.next_id += 1
        self.agents[record.id] = record
        self.events.append({'tick': tick, 'type': 'birth', 'agent_id': record.id, 'founder': True})
        return record

    def birth(self, parent_a_id: int, parent_b_id: int, tick: int) -> AgentRecord:
        if parent_a_id == parent_b_id:
            raise ValueError('A single individual cannot be both parents')
        a, b = self.agents[parent_a_id], self.agents[parent_b_id]
        if not (a.alive and b.alive):
            raise ValueError('Parents must be living at birth')
        if tick < max(a.born_tick, b.born_tick):
            raise ValueError('Birth tick earlier than a parent birth')
        genome = Genome.inherit(a.genome, b.genome, self.rng, self.mutation_rate)
        lineage_id = self.rng.choice((a.lineage_id, b.lineage_id))
        newborn = AgentRecord(self.next_id, genome, lineage_id, tick,
                              parent_ids=(a.id, b.id))
        self.next_id += 1
        self.agents[newborn.id] = newborn
        a.children.append(newborn.id)
        b.children.append(newborn.id)
        self.events.append({'tick': tick, 'type': 'birth', 'agent_id': newborn.id,
                            'parents': [a.id, b.id], 'lineage_id': lineage_id})
        return newborn

    def can_reproduce(self, a_id: int, b_id: int, tick: int,
                      cooldown_ticks: int = 100) -> bool:
        if a_id == b_id or a_id not in self.agents or b_id not in self.agents:
            return False
        a, b = self.agents[a_id], self.agents[b_id]
        if not (a.alive and b.alive) or a.genome.sex == b.genome.sex:
            return False
        for individual in (a, b):
            age = self.age(individual.id, tick)
            if age < individual.genome.phenotype(age)['MAT']:
                return False
            if (individual.last_reproduction_tick is not None and
                    tick - individual.last_reproduction_tick < cooldown_ticks):
                return False
            if individual.genome.phenotype(age)['fertility'] <= 0:
                return False
        return True

    def register_reproduction(self, a_id: int, b_id: int, tick: int) -> None:
        self.agents[a_id].last_reproduction_tick = tick
        self.agents[b_id].last_reproduction_tick = tick

    def death(self, agent_id: int, tick: int, reason: str = 'unspecified') -> None:
        a = self.agents[agent_id]
        if not a.alive:
            raise ValueError('Agent is already dead')
        if tick < a.born_tick:
            raise ValueError('Death earlier than birth')
        a.alive = False
        a.died_tick = tick
        a.memory = None
        self.events.append({'tick': tick, 'type': 'death', 'agent_id': agent_id, 'reason': reason})

    def age(self, agent_id: int, tick: int) -> float:
        return max(0.0, (tick - self.agents[agent_id].born_tick) / self.ticks_per_year)

    def living(self) -> list[AgentRecord]:
        return [a for a in self.agents.values() if a.alive]
