# ART-Wild × Neural MMO 2.1 — research mod v0.5

This archive is the **Neural MMO 2.1 source tree** with the separate `artwild/`
package and a small extension to `nmmo/entity/entity_manager.py`.
Default `nmmo.Env` remains unchanged. The ART-Wild extension is **not yet a
fully integrated or validated Neural MMO runtime**.


## Changes in v0.5 — physiological consequences in the NMMO combat/resource loop

- NMMO `Player.update()` now conditionally calls `artwild.physiology.apply_lifecycle()` when a player has a biological record. More costly metabolic phenotypes consume extra food over time (fractional accumulators). `D03` changes this cost, and `D08` changes senescence cost after age 65.
- NMMO `Player.receive_damage()` conditionally applies CON-dependent damage modification, including the `D02` penalty. No change to the global entity health maximum.
- NMMO `combat.attack()` applies a small STR-based outgoing bonus **only to melee**, including `D01` effect. Does not alter default game or NPCs.
- Adult founders and newborns receive independent physiology state at ART-Wild registration. Unmodified `nmmo.Env` retains upstream behavior.
- Added pure unit tests for physiological calculations and simulated player integration; **not a real NMMO runtime test**.
- Important: metabolic and aging values are deliberately simplified game rules, not tuned for realistic decades or populations; food depletion is additive to upstream NMMO food consumption.

## Changes in v0.4 — lifetime-safe training API

- Added `artwild.lifetime.LifetimeDriver`, a **non-PettingZoo** adapter whose
  agent keys are `cycle:biological_id`, not recyclable NMMO slots.
- A newborn reusing a deceased slot in the same step generates a **different**
  lifetime key. The deceased lifetime receives a distinct terminal record,
  and the policy runner should clear its GRU state immediately.
- Stale actions addressed to deceased lifetime keys are rejected.
- Added optional `episode_horizon` to `ArtWildEnv(...)` to extend the original
  finite NMMO horizon up to `config.MAX_HORIZON - 1`. This is **NOT** an
  indefinite persistent world, nor does it rewrite NMMO's reward/game-end rules.
- Added five lifetime driver tests. All current tests are run with the NMMO
  interface mocked because this build environment lacks upstream dependencies.

```python
import nmmo
from artwild.nmmo_env import ArtWildEnv
from artwild.lifetime import LifetimeDriver

config = nmmo.config.Default()
driver = LifetimeDriver(ArtWildEnv(config, episode_horizon=10000))
obs, infos = driver.reset(seed=23)
# obs keys: '1:1', '1:2', etc., NOT Neural MMO player slots.
result = driver.step({key: {} for key in obs})
# For each key with result.terminated[key], clear its RNN hidden state.
# result.observations only contains current living agents.
```

**Important trainer contract:** `LifetimeDriver` is for a custom runner. Do
not pass its output as though it were a native PettingZoo environment; it uses
nonstandard lifetime IDs, and a death may have a terminal record without an
observation. Existing policies must support the augmented action and body
spaces before they can run with the ART-Wild bridge.

**Persistent world remains unfinished:** after the extended horizon, an
external `reset()` still destroys the active world and the biological registry.
Saving/loading the full world, removing NMMO task-based termination, and
indefinite year ticks require a dedicated replacement game loop.

## Changes since v0.2

- Added two sex markers (`XX`, `XY`) for the deliberately simplified reproductive model.
- Initial founders are physiologically adult (`founder_age_years=20` by default).
- Added a **reciprocal mating proposal** action: both nearby living, physiologically
  mature agents must select each other's slot. One-sided proposals are ignored.
- Fertility, maturity and reproduction cooldown are evaluated before birth.
- Existing genes and 8 recessive disorders are inherited in newborns.
- Added `ArtWildMate` to the **wrapper** `action_space`, and `ArtWildBody` to the
  **wrapper** `observation_space`. Body features are age, expressed STR/CON,
  MAT/REP/PAR/SEN, fertility, energy cost, aging rate and sex marker. It does
  not expose genetic alleles, parent IDs, or a world map to the agent.
- Continued to reuse vacant NMMO player slots while preserving the permanent
  ART-Wild biological identity in `info` and the `Population` registry.
- Added more mock bridge tests.

## Example: opt-in wrapper

Python 3.10 plus upstream Neural MMO dependencies / compiled extensions are
required for **real gameplay**; these are NOT bundled in the archive.

```python
import nmmo
from artwild.nmmo_env import ArtWildEnv

config = nmmo.config.Default()
env = ArtWildEnv(config, artwild_seed=5, founder_age_years=20,
                 ticks_per_year=100, reproduction_cooldown_ticks=100)
observations, info = env.reset(seed=5)

# To request mating, BOTH agents must select each other in the same tick.
# The pair must be adult, biologically compatible, and nearby, with a
# vacant player slot and a habitable tile near the first partner.
act = {
    1: {'ArtWildMate': {'target': 2}},
    2: {'ArtWildMate': {'target': 1}},
}
observations, rewards, terminated, truncated, infos = env.step(act)
```

If all `PLAYER_N` slots are occupied, conception requests remain queued and
may produce a birth only after a vacant slot opens; there is **no pregnancy
simulation**. A policy must use observable nearby player IDs to propose a
partner; the action space's global slot index is not a magical range finder.

## Tests

```bash
python -m unittest discover -s artwild/tests -v
python -m compileall -q artwild nmmo
```

The `test_bridge_mock.py` tests mock the upstream Neural MMO interface and
cannot prove that real Neural MMO 2.1 will run with these changes.

## Still missing — important

- **Real NMMO runtime integration not tested** in the build environment:
  upstream Python dependencies and Cython extension are unavailable.
- **Neural MMO `HORIZON` (optionally extended) still ends an episode**, and default tasks/game
  logic remain untouched. The world does not live indefinitely.
- `PLAYER_N` remains a **hard capacity limit**, not a dynamic population size.
- **PettingZoo incompatibility:** Dead slot IDs can reappear in an episode.
  Standard PettingZoo/RL code may assume terminated agent IDs never return.
  Trainers MUST key individual GRU states by `artwild_bio_id` rather than slot.
  A dedicated lifetime-safe training driver is required.
- The `ArtWildMate` and `ArtWildBody` extensions change the wrapper spaces;
  existing Neural MMO policies require adaptation/retraining.
- Newborns don't automatically get upstream game tasks or agent-specific
  policy assignments. Adding an agent to the world does **not** implement
  policy training or complete support for NMMO's reward system.
- Gestation, birth costs, parenting behavior, physical application of STR/CON
  and disease penalties to base NMMO combat/health, genetically driven aging
  death, pregnancy, and lifecycle events are NOT yet implemented.
- `ArtWildBody` is a numeric *state observation*, not a guarantee that the
  underlying NMMO player mechanics use these values.

## Next priority

1. Run integration tests using a compatible Python 3.10 Neural MMO environment.
2. Introduce a lifecycle-safe rollout interface not reusing agent identifiers.
3. Replace original episode task/reward/horizon rules to support persistent
   worlds, then implement gestation, birth and pediatric survival mechanics.
