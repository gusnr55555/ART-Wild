# ART-Wild: Adaptive Resonance Theory layer (v0.7.2-art)

Adds `artwild/art/` (numpy only; no torch, no Neural MMO import). It is **not
wired into** `CycleEngine`, `ToyWorld`, the NMMO bridge, or any PPO/GRU code.
Nothing here shows that ART improves agent behaviour in the ART-Wild world.

## What exists, and how it was checked

| Paper concept | Code | Test (executed, no mocks) |
|---|---|---|
| ART 1 choice via bottom-up `z`, `L`; `z(0) < L/(L-1+M)` [CG87] | `art1.ART1` | `test_uncommitted_bottom_up_weight_satisfies_paper_bound` |
| ART 1 fast learning `w <- I ^ w`, templates only shrink | `art1.ART1._learn` | `test_templates_only_shrink_and_are_subsets_of_their_members` |
| Direct access: most specific subset template wins [CG87] | `ART1` | `test_subset_template_with_larger_support_is_tried_first`, `test_exact_exemplar_beats_uncommitted_node` |
| Fuzzy ART choice / vigilance / learning [CGR91] | `fuzzy_art.FuzzyART` | `test_first_input_commits...`, `test_rho_one_separates...`, `test_slow_recode_after_fast_commit` |
| Complement coding, `|I| = M` | `common.complement_code` | `test_complement_coding_has_constant_norm` |
| Weights non-increasing | `FuzzyART._learn` | `test_weights_never_increase` (beta = 1 and 0.4) |
| Categories are hyperboxes (min/max of members) | `FuzzyART.box` | `test_fast_learning_box_is_min_max_of_members` |
| Vigilance bounds box size: sum of sides <= M(1-rho) | `common.ArtBase._search` | `test_vigilance_bounds_box_size` |
| Finite learning, then direct access without reset | `FuzzyART` | `test_learning_stabilises_in_finite_epochs...` |
| Uncommitted node competes; ties -> lowest index | `ArtBase._search` | `test_ties_go_to_lowest_index` |
| ART 1 == Fuzzy ART (binary, no complement, beta=1, alpha=L-1) | both | `test_same_choice_order_as_fuzzy_art_with_alpha_L_minus_1` |
| Fuzzy ARTMAP map field + match tracking [CG+92] | `artmap.FuzzyARTMAP` | `test_match_tracking_splits_conflicting_neighbours`, `test_learns_consistent_training_set_exactly` |
| Novelty instead of a forced guess at inference | `classify`, `predict` | `test_classify_does_not_change_network...`, `test_prediction_reports_novelty...` |
| Fixed-size policy features from ART (decision 3) | `perceiver.ArtPerceiver` | `ArtPerceiverTests` (9 tests) |
| No state crosses lifetimes (CycleEngine contract) | `lifetime_store.ArtLifetimeStore` | `test_store_gives_fresh_networks...`, `test_no_memory_crosses_lifetimes_inside_cycle_engine` |

Nine deliberate code mutations (no match tracking, ties to highest index,
growing weights, ignored vigilance, no fast commit, loose `z(0)`, no map check,
reusable retired keys, ignored capacity) were each caught by at least one test.

## Choices and deviations (all deliberate)

- **Algorithmic ART only.** The STM/LTM differential equations, the 2/3 rule as
  a dynamical gate, and orienting-subsystem dynamics are not simulated.
- ART 1 fast learning only. Fuzzy ART supports slow learning (`beta < 1`) with
  fast-commit (`fast_commit=True`, as in [CGR91]).
- The uncommitted node is virtual (weights = 1, never stored).
- `max_categories` is optional. At capacity an unmatched input returns
  `capacity_exhausted`; no category is overwritten and nothing is learned.
- Vigilance comparison uses a `1e-12` float guard.
- ART 1 `z(0)` is `L/(L-1+M) * (1 - 1e-9)` to realise the paper's strict inequality.
- ARTMAP: map field stored as one ART_b index per ART_a node (exactly
  equivalent for winner-take-all ART_b with fast map learning), so `rho_ab`
  only validates. ART_b learns before the ART_a search, so a failed ART_a search
  leaves ART_b updated. `epsilon` defaults to `+1e-6` (original match tracking).
- Identical A with different B cannot be encoded: vigilance climbs above 1 and
  `train` returns `a_search_exhausted` with the network unchanged.

## Not implemented

`ArtPerceiver` fixes the feature interface only; it is not yet called by any policy,
and its benefit to PPO is untested. The 28-d sensory encoder (item 5) is not
implemented. 
ART 2 / ART 2-A, dART, ARTMAP-IC, Gaussian/Bayesian ART variants, TopoART,
fusion/hierarchical ART, any use of ART inside the PPO policy, the batched
multi-lineage inference structure, mutation and distillation.

## Not verified

- Theoretical epoch bounds for finite learning were not checked; the test only
  confirms stabilisation within 39 epochs on one seeded data set.
- The citations were written from memory of the papers. Check volume/page
  numbers against the PDFs before quoting them externally.
- Speed (single thread, numpy, worst case: 4,000 categories because random
  inputs at rho=0.9 never merge): about 0.5 ms (M=16) to 0.7 ms (M=32) per
  `classify`. At 1,000 agents that is on the order of 0.5-0.7 s per tick if every
  agent classifies every tick with such a large network. Realistic category
  counts will be far lower; this was not measured on real ART-Wild data.

## Design decisions

1. **Role of ART: DECIDED by the project owner** - per-agent perceptual/episodic
   categoriser whose output feeds the policy.
2. **Inheritance: ACCEPTED by the project owner (2026-11-14)** - Darwinian default.
   A newborn's ART starts empty. What a lineage passes on is ART
   *hyperparameters* (vigilance, alpha, beta), kept at lineage level, not in the
   frozen genome. Copying a parent's learned categories (Lamarckian) is left as
   a later switch for an ablation.
   Evidence: Lamarckian inheritance sped up and improved evolving robots in one
   static environment, with the authors speculating it may over-fit when the
   environment changes (untested) [Lamarck's Revenge, arXiv:2309.13099]; the
   Baldwin effect arises under purely Darwinian inheritance when lifetime
   learning is present [DERL, arXiv:2102.02202; Ackley & Littman 1992]. ART-Wild
   also wants cultural transmission to be an *observed* outcome, which direct
   inheritance of learned categories would pre-empt.
3. **Coupling to PPO: ACCEPTED by the project owner (2026-11-14)** - ART runs as a
   non-differentiable preprocessor inside the observation path; PPO never
   backpropagates through it. Feed fixed-size, stable-meaning features only
   (winner match value, reset count / novelty flag, winner's prototype centre,
   per-category visit and mean-reward statistics). Do NOT feed raw category
   indices or one-hot ids: with shared policy weights, "category 3" means a
   different thing in every agent and shifts as categories are created.
   Evidence and its limits: TD-FALCON couples ART with temporal-difference
   learning, but there ART *is* the value approximator (one-step Q), tested on
   teams of up to 8 agents on a 16x16 field, and it reported very poor results
   without well-chosen sensors [Tan et al., IEEE TNN 2008]. No paper found
   that uses ART categories as input to PPO, so item 3 is an extrapolation from
   ART's novelty/match mechanism, not an established result; it still needs a
   small-environment ablation (with vs. without ART features) before anyone
   claims it helps.
4. **Per-tick contract (v0.7.2, from the GPT review; verified in code).**
   `observe(x)` classifies without modifying ART and computes features from the
   PRE-learning state; the policy acts; `learn(percept)` then stores x and returns
   an `ExperienceRef`; after the environment step `credit(ref, reward)` credits
   that exact category. The runner must store the features in the transition:
   PPO must never recompute them at update time, because ART changes.
   (v0.7.1 learned first and used "the last category" for reward; both fixed.)
5. **Sensory input for ART (PROPOSED, 28-d, first-experiment default).**
   Interoception 7 (health, food, water; their one-tick changes; recent damage),
   maturity 1, terrain 12 (water / food source / blocked in 4 axis-aligned
   quadrants), nearest water and food 2, social 5, inventory fill 1. The policy
   keeps its full raw observation; ART's 28-d input does not restrict the policy.
   Verified in this source: there is no persistent facing direction (actions are
   N/S/E/W moves), so "front/back/left/right" must NOT be used; use map-axis
   quadrants relative to the agent. `material.py`: Impassible = Void, Water,
   Stone, Ocean, Fish; Harvestable = Water, Foilage, Ore, Tree, Crystal, Herb,
   Fish. "Harvestable" is not "food": Foilage is the plain food source; Fish
   needs a Rod. Still missing and recommended: the relative direction of the
   nearest agent/NPC, and walking distance instead of straight-line distance.
   Which semantic groupings are used must be recorded as an experiment condition.
6. **Vigilance and the size of a "novel" change (MEASURED).** For a point
   category with complement coding, match = 1 - L1distance / M, so a reset needs
   an L1 change above M(1 - rho). With M = 28 that is 7.0 (rho 0.75), 2.8 (0.9),
   1.4 (0.95). A health drop of 0.5 gives match 0.982 and is NOT novel even at
   rho = 0.9; health, food and water all dropping by 0.5 is novel only at 0.95.
   Plain Fuzzy ART treats all inputs equally, so a survival-critical change in
   one or three features is invisible to its novelty signal. Options (OPEN):
   (i) very high rho; (ii) replicate important features; (iii) separate channels
   with per-channel vigilance, as TD-FALCON does (rho 0.5/0.2/0.5 across its
   channels); a node must pass every channel. Not implemented.
7. **Experiment design (PROPOSED).** Groups: A PPO+GRU; B PPO+GRU+param-matched
   auxiliary encoder; C +ART novelty/match; D +ART visit/reward statistics;
   E +all ART features; E' = E without prototype centres; F ablation without
   GRU. Same seeds, interaction budget, update budget, reward, action space.
   At least 5 seeds to start, more if effects are small or unstable. Report per
   seed with intervals. A short ToyWorld without revisits or environment change
   cannot refute an ART memory benefit: the test needs revisited situations
   and a changing environment. Hypotheses, all UNTESTED: H1 ART agents separate
   long-unseen states better than GRU-only; H2 ART reward statistics help in
   repeated structure; H3 any ART benefit grows with lifespan and change.
   If ART gives no gain, run it as an observer only; the project must not be
   bent to fit the theory.
8. **Cost gate (PROPOSED, engineering rule of thumb, not from a paper).** Measure
   category counts by age (median, p95), creation rate, and ART's share of tick
   time first. ART < 10% of tick time: keep; 10-25%: profile and optimise;
   > 25%: consider batched classification (hard, since categories differ per
   agent). Newborn survival: use birth near parents and age-appropriate needs as
   biological rules; do not guarantee survival or hand over parent memory.

## Run

```bash
python -m unittest discover -s artwild/tests -v      # 41 existing + 38 ART tests
python -m unittest discover -s artwild/tests -p 'test_art.py' -v
```

[CG87] Carpenter & Grossberg 1987, CVGIP 37:54-115.
[CGR91] Carpenter, Grossberg & Rosen 1991, Neural Networks 4:759-771.
[CG+92] Carpenter, Grossberg, Markuzon, Reynolds & Rosen 1992, IEEE TNN 3:698-713.

## v0.7.3 Updates (2026-11-14)
- **Reference integrity (, )**:  now carries  and  is consumed one-time on ;  (called automatically by  / ) discards uncredited references and blocks further // calls.
- **28-d sensory encoder ()**: Adopted  /  (pure numpy). Recorded experiment condition: , , .
- **Experimental multi-channel Fuzzy ART ()**: Implemented for V0-V4 vigilance comparison (); NOT set as default pending further PPO ablation.

## v0.8 Updates (2026-11-14)
- **Symmetric V0-V4 benchmark & isolated streams (`artwild/art/vigilance_benchmark.py`)**: Added symmetric new-category vs. existing-category-switch rates (`danger_new_cat_rate`, `danger_switch_rate`, `benign_new_cat_rate`, `benign_switch_rate`) and isolated `phys_only` / `social_only` streams. `MultiChannelFuzzyART` remains experimental.
- **v0.8 PPO+GRU vs. ART comparison environment (`artwild/rl/`)**:
  - `SmallSurvivalWorld` (`artwild/rl/survival_env.py`): `CycleEngine`-compatible 11x11 survival grid with food/water foraging, moving hazard NPCs, and fresh-ID respawns on death.
  - `ArtAdapter`, `RolloutBuffer`, `GruActorCritic`, `PPOGruTrainer` (`artwild/rl/ppo_gru.py`): Compares `'none'`, `'v0'`, and `'v3'` under identical budgets and common eval seeds (`artwild/rl/run_v08.py`), storing collection-time ART features in rollouts and resetting GRU + ART memory on death.

## v0.9 Updates (2026-11-14)
- **Basic Rule-Based Ecosystem (`artwild/ecology/`)**:
  - `Ecosystem` (`artwild/ecology/ecosystem.py`): Multi-species plant growth and spatial reproduction (`forage_grass`, `berry_bush`), rule-based herbivores (`rabbit`) and carnivores (`wolf`), and food-chain predation/starvation/reproduction bookkeeping.
  - `EcoSurvivalWorld` (`artwild/ecology/eco_world.py`): `CycleEngine`-compatible survival world connecting `Ecosystem` to intelligent agents and `SensoryEncoder28` / `ArtAdapter`.

## Ecology v1.0 Updates (2026-11-14)
- **Constrained Procedural Species (`artwild/ecology/species.py`)**: `SpeciesRegistry` generates 16-trait `PlantSpeciesV1` and `AnimalSpeciesV1` with loose physiological trade-offs and no magic `cultivable`/`domesticable`/`is_fruit_tree` flags.
- **Hybrid-Resolution Engine (`artwild/ecology/engine.py`)**:
  - `PlantPatch`: separates `structural_biomass` and `yield_biomass` so perennial/fruit-tree species (`regrowth_rate > 0`) survive non-destructive harvests and regrow, plus `drop_seed()` and soil/climate-gated germination.
  - `AnimalPopulation`: active individual entities vs. inactive 3-tier energy chunk summaries (`ChunkSpeciesSummary`) enforcing exact integer count conservation, energy/plant consumption conservation, spatial chunk continuity, and `persistent` individual tracking.
  - `ClimateState` & SIR infectious disease (`S -> I -> R -> S`, separate from `core.py` genetic diseases).

## v1.1 EcologyEngine-PPO Integration (2026-11-14)
- `EcoSurvivalWorld` (`artwild/ecology/eco_world.py`) now runs on `EcologyEngine` v1.0 (`SpeciesRegistry`, `PlantPatch`, `AnimalPopulation`) with dynamic per-agent `active_chunks` and public-only observations (no hidden plant/animal physiological traits exposed).
- `artwild/rl/run_v08.py` supports `--world survival|eco` for `none` / `v0` / `v3` PPO+GRU comparison under identical budgets and common eval seeds.
